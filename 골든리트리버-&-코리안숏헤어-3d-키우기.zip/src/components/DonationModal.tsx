import React, {useState} from 'react';
import {CheckCircle2, CreditCard, Gift, Heart, Lock, X} from 'lucide-react';
import {petAudio} from '../audio/petAudio';
import {DonationRecord, WARDROBE_CATALOG} from '../types/pet';

interface DonationModalProps {
  bonusScore: number;
  donations: DonationRecord[];
  unlockedItemIds: string[];
  onCompleteDonation: (record: DonationRecord, bonusBoost: number) => void;
  onClose: () => void;
}

const SPONSOR_TIERS = [
  {points: 100, krw: 1000, label: '기본 후원 (100점 = 1,000원)'},
  {points: 200, krw: 2000, label: '사랑 후원 (200점 = 2,000원)'},
  {points: 300, krw: 3000, label: '프리미엄 후원 (300점 = 3,000원)'},
  {points: 500, krw: 5000, label: '명예 후원 (500점 = 5,000원)'},
];

export const DonationModal: React.FC<DonationModalProps> = ({
  bonusScore,
  donations,
  unlockedItemIds,
  onCompleteDonation,
  onClose,
}) => {
  const earnedDonationUnits = Math.floor(bonusScore / 100);
  const earnedDonationKrw = earnedDonationUnits * 1000;

  const [selectedTierPoints, setSelectedTierPoints] = useState<number>(
    earnedDonationUnits >= 1 ? earnedDonationUnits * 100 : 100,
  );
  const [cardCompany, setCardCompany] = useState('신한카드');
  const [cardNumber, setCardNumber] = useState('4532 - 8910 - 2245 - 7801');
  const [expiry, setExpiry] = useState('08 / 29');
  const [cvc, setCvc] = useState('427');
  const [holder, setHolder] = useState('김사랑');
  const [pin2, setPin2] = useState('12');
  const [agreed, setAgreed] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [receipt, setReceipt] = useState<DonationRecord | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const amountKrw = Math.max(1000, Math.round((selectedTierPoints / 100) * 1000));

  const formatCardInput = (raw: string) => {
    const digits = raw.replace(/\D/g, '').slice(0, 16);
    return digits.replace(/(\d{4})(?=\d)/g, '$1 - ');
  };

  const formatExpiryInput = (raw: string) => {
    const digits = raw.replace(/\D/g, '').slice(0, 4);
    if (digits.length <= 2) return digits;
    return `${digits.slice(0, 2)} / ${digits.slice(2)}`;
  };

  const handlePay = (e: React.FormEvent) => {
    e.preventDefault();
    const digits = cardNumber.replace(/\D/g, '');
    if (digits.length < 16) {
      setErrorMsg('카드 번호 16자리를 정확히 입력해 주세요.');
      return;
    }
    if (expiry.replace(/\D/g, '').length < 4 || cvc.length < 3 || pin2.length < 2) {
      setErrorMsg('유효기간, CVC, 비밀번호 앞 2자리를 확인해 주세요.');
      return;
    }
    if (!agreed) {
      setErrorMsg('후원 결제 약관에 동의해 주세요.');
      return;
    }

    setErrorMsg(null);
    setProcessing(true);

    window.setTimeout(() => {
      const nextLocked = WARDROBE_CATALOG.find(
        (item) => !unlockedItemIds.includes(item.id),
      );
      const record: DonationRecord = {
        id: `DON-${Date.now().toString().slice(-6)}`,
        amountKrw,
        bonusPointsUsed: selectedTierPoints,
        cardLast4: digits.slice(-4),
        timestamp: Date.now(),
        unlockedItemName: nextLocked?.name,
      };
      setProcessing(false);
      setReceipt(record);
      petAudio.playCelebrationFanfare();
      onCompleteDonation(record, selectedTierPoints >= 100 ? 100 : 50);
    }, 750);
  };

  const totalDonatedKrw = donations.reduce((acc, d) => acc + d.amountKrw, 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/65 p-4">
      <div className="w-full max-w-xl rounded-3xl bg-white border border-stone-200 shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-100">
          <div className="flex items-center gap-2.5">
            <Heart className="w-5 h-5 text-rose-500" />
            <div>
              <h2 className="font-display text-lg font-bold text-stone-900">
                유기동물 사랑 후원 · 신용카드 결제
              </h2>
              <p className="text-xs text-stone-500">
                보너스 점수 100점당 1,000원씩 후원하고 특별 옷·목걸이를 받으세요
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="닫기"
            className="p-2 rounded-xl text-stone-500 hover:bg-stone-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {receipt ? (
          <div className="p-7 text-center space-y-5">
            <div className="w-14 h-14 mx-auto rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <div>
              <h3 className="font-display text-xl font-bold text-stone-900">
                신용카드 후원이 완료되었습니다
              </h3>
              <p className="text-sm text-stone-600 mt-1">
                따뜻한 후원금{' '}
                <span className="font-mono-num font-bold text-stone-900">
                  {receipt.amountKrw.toLocaleString()}원
                </span>
                이 정상 결제되었습니다.
              </p>
            </div>
            <div className="rounded-2xl bg-stone-50 border border-stone-200 p-4 text-left space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-stone-500">승인 번호</span>
                <span className="font-mono-num font-semibold text-stone-900">
                  {receipt.id}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500">결제 카드</span>
                <span className="font-mono-num font-semibold text-stone-900">
                  {cardCompany} (****-{receipt.cardLast4})
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500">후원 환산 기준</span>
                <span className="font-semibold text-stone-900">
                  보너스 {receipt.bonusPointsUsed}점 (100점 = 1,000원)
                </span>
              </div>
              {receipt.unlockedItemName && (
                <div className="flex justify-between text-rose-700 font-semibold pt-1 border-t border-stone-200">
                  <span className="flex items-center gap-1">
                    <Gift className="w-3.5 h-3.5" />
                    옷장 특별 선물 해금
                  </span>
                  <span>{receipt.unlockedItemName}</span>
                </div>
              )}
            </div>
            <button
              type="button"
              onClick={onClose}
              className="w-full py-3 rounded-xl bg-stone-900 hover:bg-stone-800 text-white font-semibold text-sm cursor-pointer"
            >
              옷장에서 선물 확인하기
            </button>
          </div>
        ) : (
          <form onSubmit={handlePay} className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
            {/* Current Bonus Summary */}
            <div className="rounded-2xl bg-amber-50 border border-amber-200 p-4 flex items-center justify-between gap-4">
              <div>
                <div className="text-xs font-semibold text-amber-800">
                  현재 보유 보너스 점수
                </div>
                <div className="font-mono-num text-xl font-bold text-stone-900 mt-0.5">
                  {bonusScore}점
                  <span className="text-xs font-normal text-stone-600 ml-2">
                    (후원 가능 환산액 {earnedDonationKrw.toLocaleString()}원)
                  </span>
                </div>
              </div>
              {totalDonatedKrw > 0 && (
                <div className="text-right">
                  <div className="text-[11px] text-stone-500">누적 후원</div>
                  <div className="font-mono-num text-sm font-bold text-emerald-700">
                    {totalDonatedKrw.toLocaleString()}원
                  </div>
                </div>
              )}
            </div>

            {/* Donation Tier Selection (100점당 1,000원) */}
            <div className="space-y-2">
              <div className="text-xs font-bold text-stone-700">
                후원 금액 선택 (100점당 1,000원 · 후원 시 예쁜 옷·목걸이 해금)
              </div>
              <div className="grid grid-cols-2 gap-2">
                {SPONSOR_TIERS.map((tier) => (
                  <button
                    key={tier.points}
                    type="button"
                    onClick={() => setSelectedTierPoints(tier.points)}
                    className={`px-3.5 py-2.5 rounded-xl border text-left transition-colors cursor-pointer ${
                      selectedTierPoints === tier.points
                        ? 'border-rose-500 bg-rose-50 text-rose-950'
                        : 'border-stone-200 bg-white text-stone-700 hover:bg-stone-50'
                    }`}
                  >
                    <div className="font-mono-num text-sm font-bold">
                      {tier.krw.toLocaleString()}원
                    </div>
                    <div className="text-[11px] text-stone-500">
                      {tier.label}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Credit Card Fields */}
            <div className="space-y-3 rounded-2xl border border-stone-200 p-4 bg-stone-50/70">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-bold text-stone-800">
                  <CreditCard className="w-4 h-4 text-stone-700" />
                  <span>신용카드 정보 입력</span>
                </div>
                <span className="flex items-center gap-1 text-[11px] text-stone-500">
                  <Lock className="w-3 h-3" /> 보안 결제
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <label className="block">
                  <span className="block text-[11px] font-medium text-stone-500 mb-1">
                    카드사
                  </span>
                  <select
                    value={cardCompany}
                    onChange={(e) => setCardCompany(e.target.value)}
                    className="w-full rounded-xl border border-stone-200 bg-white px-3 py-2 text-xs font-medium text-stone-900"
                  >
                    <option>신한카드</option>
                    <option>삼성카드</option>
                    <option>현대카드</option>
                    <option>KB국민카드</option>
                    <option>비씨카드</option>
                  </select>
                </label>
                <label className="block">
                  <span className="block text-[11px] font-medium text-stone-500 mb-1">
                    카드 소유자명
                  </span>
                  <input
                    type="text"
                    value={holder}
                    onChange={(e) => setHolder(e.target.value)}
                    className="w-full rounded-xl border border-stone-200 bg-white px-3 py-2 text-xs font-medium text-stone-900"
                  />
                </label>
              </div>

              <label className="block">
                <span className="block text-[11px] font-medium text-stone-500 mb-1">
                  카드 번호 (16자리)
                </span>
                <input
                  type="text"
                  inputMode="numeric"
                  value={cardNumber}
                  onChange={(e) => setCardNumber(formatCardInput(e.target.value))}
                  className="w-full rounded-xl border border-stone-200 bg-white px-3 py-2 text-sm font-mono-num text-stone-900"
                />
              </label>

              <div className="grid grid-cols-3 gap-3">
                <label className="block">
                  <span className="block text-[11px] font-medium text-stone-500 mb-1">
                    유효기간 (MM/YY)
                  </span>
                  <input
                    type="text"
                    inputMode="numeric"
                    value={expiry}
                    onChange={(e) => setExpiry(formatExpiryInput(e.target.value))}
                    className="w-full rounded-xl border border-stone-200 bg-white px-3 py-2 text-xs font-mono-num text-stone-900"
                  />
                </label>
                <label className="block">
                  <span className="block text-[11px] font-medium text-stone-500 mb-1">
                    CVC (3자리)
                  </span>
                  <input
                    type="password"
                    inputMode="numeric"
                    maxLength={3}
                    value={cvc}
                    onChange={(e) => setCvc(e.target.value.replace(/\D/g, ''))}
                    className="w-full rounded-xl border border-stone-200 bg-white px-3 py-2 text-xs font-mono-num text-stone-900"
                  />
                </label>
                <label className="block">
                  <span className="block text-[11px] font-medium text-stone-500 mb-1">
                    비밀번호 앞 2자리
                  </span>
                  <input
                    type="password"
                    inputMode="numeric"
                    maxLength={2}
                    value={pin2}
                    onChange={(e) => setPin2(e.target.value.replace(/\D/g, ''))}
                    className="w-full rounded-xl border border-stone-200 bg-white px-3 py-2 text-xs font-mono-num text-stone-900"
                  />
                </label>
              </div>
            </div>

            <label className="flex items-center gap-2 text-xs text-stone-600 cursor-pointer">
              <input
                type="checkbox"
                checked={agreed}
                onChange={(e) => setAgreed(e.target.checked)}
                className="rounded border-stone-300 text-rose-600"
              />
              <span>전자금융거래 이용약관 및 유기동물 보호 후원 결제에 동의합니다.</span>
            </label>

            {errorMsg && (
              <div className="text-xs font-medium text-rose-600 bg-rose-50 border border-rose-200 rounded-xl px-3.5 py-2">
                {errorMsg}
              </div>
            )}

            <button
              type="submit"
              disabled={processing}
              className="w-full py-3.5 rounded-2xl bg-rose-600 hover:bg-rose-700 disabled:bg-stone-300 text-white font-display font-bold text-sm shadow-md transition-colors cursor-pointer"
            >
              {processing
                ? '신용카드 승인 처리 중...'
                : `${amountKrw.toLocaleString()}원 신용카드 후원 결제하기`}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
