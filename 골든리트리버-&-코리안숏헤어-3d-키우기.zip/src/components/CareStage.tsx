import React, {useEffect, useRef, useState} from 'react';
import * as THREE from 'three';
import {
  ArrowLeft,
  Footprints,
  Gift,
  Heart,
  Music,
  Play,
  Settings,
  Shirt,
  Sparkles,
  Utensils,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import {petAudio} from '../audio/petAudio';
import {
  afterDraw,
  buildCareEnvironment,
  CareEnvironmentHandles,
  createConfiguredRenderer,
  detectSoftwareGl,
  setupStudioLighting,
} from '../three/environmentScene';
import {createProceduralTextureSet} from '../three/furTextures';
import {
  applyWardrobeToPet,
  createGoldenRetrieverRig,
  createKoreanShorthairRig,
  PetPlayMotion,
  PetRig,
  updatePetGrowthAndPose,
} from '../three/petModels';
import {
  CareSchedule,
  getLifeStageLabel,
  getSpeechForMood,
  PET_DISPLAY_INFO,
  PetExpressionMood,
  PetSpecies,
  SpeechBubbleState,
  WARDROBE_CATALOG,
  WardrobeItem,
} from '../types/pet';

interface CareStageProps {
  species: PetSpecies;
  started: boolean;
  bonusScore: number;
  baseScore: number;
  maturity: number;
  hunger: number;      // 0..100 (100 = full)
  pottyNeed: number;   // 0..100 (100 = urgent)
  vitality: number;    // 0..100 (health / energy)
  schedule: CareSchedule;
  timeScaleMode: 'realtime' | 'fast';
  unlockedItemIds: string[];
  equippedClothesId: string | null;
  equippedAccessoryId: string | null;
  pendingGiftItem: WardrobeItem | null;
  giftReadyInSky: boolean;
  muted: boolean;
  bgmEnabled: boolean;
  onToggleMute: () => void;
  onToggleBgm: () => void;
  onStartCare: () => void;
  onOpenSettings: () => void;
  onOpenDonation: () => void;
  onStartWalk: () => void;
  onFeed: () => {onTime: boolean; pointsAdded: number};
  onCleanPotty: () => void;
  onPlayBall: () => void;
  onTouchPet: () => void;
  onOpenSkyGift: () => void;
  onStorePendingGift: () => void;
  onEquipItem: (item: WardrobeItem) => void;
  onUnequipSlot: (slot: 'clothes' | 'accessory') => void;
  onBackToShowcase: () => void;
}

const _projVec = new THREE.Vector3();
const _fwOrigin = new THREE.Vector3(0, 1.8, 0.2);

export const CareStage: React.FC<CareStageProps> = ({
  species,
  started,
  bonusScore,
  baseScore,
  maturity,
  hunger,
  pottyNeed,
  vitality,
  schedule,
  timeScaleMode,
  unlockedItemIds,
  equippedClothesId,
  equippedAccessoryId,
  pendingGiftItem,
  giftReadyInSky,
  muted,
  bgmEnabled,
  onToggleMute,
  onToggleBgm,
  onStartCare,
  onOpenSettings,
  onOpenDonation,
  onStartWalk,
  onFeed,
  onCleanPotty,
  onPlayBall,
  onTouchPet,
  onOpenSkyGift,
  onStorePendingGift,
  onEquipItem,
  onUnequipSlot,
  onBackToShowcase,
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const rigRef = useRef<PetRig | null>(null);
  const envRef = useRef<CareEnvironmentHandles | null>(null);

  const maturityRef = useRef(maturity);
  const healthRef = useRef(vitality / 100);
  const moodRef = useRef<PetExpressionMood>('idle');
  const rollRef = useRef(0);
  const touchGreetRef = useRef(0);
  const eatTimerRef = useRef(0);
  const ballPlayTimerRef = useRef(0);
  const giftReadyRef = useRef(giftReadyInSky);
  const pottyRef = useRef(pottyNeed);

  const [wardrobeOpen, setWardrobeOpen] = useState(false);
  const [bubbles, setBubbles] = useState<SpeechBubbleState[]>([]);
  const [draggingItem, setDraggingItem] = useState<{
    item: WardrobeItem;
    x: number;
    y: number;
  } | null>(null);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const bubbleIdRef = useRef(1);

  // Sync latest React props into refs for the Three.js loop without re-creating WebGL context
  useEffect(() => {
    maturityRef.current = maturity;
  }, [maturity]);

  useEffect(() => {
    healthRef.current = THREE.MathUtils.clamp(vitality / 100, 0.3, 1.0);
  }, [vitality]);

  useEffect(() => {
    giftReadyRef.current = giftReadyInSky;
  }, [giftReadyInSky]);

  useEffect(() => {
    pottyRef.current = pottyNeed;
    if (envRef.current) {
      envRef.current.poopMarker.visible = pottyNeed >= 65;
    }
  }, [pottyNeed]);

  useEffect(() => {
    if (eatTimerRef.current > 0) return;
    if (hunger <= 32) {
      moodRef.current = 'hungry';
    } else if (pottyNeed >= 70) {
      moodRef.current = 'potty';
    } else if (moodRef.current === 'hungry' || moodRef.current === 'potty') {
      moodRef.current = 'idle';
    }
  }, [hunger, pottyNeed]);

  // Apply 3D wardrobe changes directly onto the active pet rig
  useEffect(() => {
    if (rigRef.current) {
      applyWardrobeToPet(rigRef.current, equippedClothesId, equippedAccessoryId);
    }
  }, [equippedClothesId, equippedAccessoryId]);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    window.setTimeout(() => {
      setToastMsg((prev) => (prev === msg ? null : prev));
    }, 2800);
  };

  // Callback refs for Three.js pointer handlers
  const onOpenSkyGiftRef = useRef(onOpenSkyGift);
  const onTouchPetRef = useRef(onTouchPet);
  onOpenSkyGiftRef.current = onOpenSkyGift;
  onTouchPetRef.current = onTouchPet;

  const triggerPetExpressionRef = useRef<(m: PetExpressionMood) => void>(() => {});

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = detectSoftwareGl();
    const renderer = createConfiguredRenderer(container, isSoftwareGl, false);
    const scene = new THREE.Scene();
    setupStudioLighting(scene, renderer, 0xfaf3e8);

    const camera = new THREE.PerspectiveCamera(
      40,
      (container.clientWidth || window.innerWidth) /
        (container.clientHeight || window.innerHeight),
      0.1,
      100,
    );
    camera.position.set(0, 1.65, 4.4);
    camera.lookAt(0, 0.5, 0);

    const textures = createProceduralTextureSet(
      renderer.capabilities.getMaxAnisotropy(),
    );
    const envHandles = buildCareEnvironment(scene, textures);
    envRef.current = envHandles;

    const rig =
      species === 'golden_retriever'
        ? createGoldenRetrieverRig(textures, isSoftwareGl)
        : createKoreanShorthairRig(textures, isSoftwareGl);
    applyWardrobeToPet(rig, equippedClothesId, equippedAccessoryId);
    rig.root.position.set(0, 0, 0.2);
    scene.add(rig.root);
    rigRef.current = rig;

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();

    const spawnBubble = (mood: PetExpressionMood) => {
      const {text, subLabel} = getSpeechForMood(species, mood);
      _projVec.copy(rig.root.position);
      _projVec.y += species === 'golden_retriever' ? 1.15 : 0.92;
      _projVec.project(camera);

      const rect = renderer.domElement.getBoundingClientRect();
      const sx = ((_projVec.x + 1) / 2) * rect.width;
      const sy = ((-_projVec.y + 1) / 2) * rect.height;

      const b: SpeechBubbleState = {
        id: bubbleIdRef.current++,
        species,
        mood,
        text,
        subLabel,
        screenX: Math.min(Math.max(sx, 120), rect.width - 120),
        screenY: Math.max(sy, 86),
        expiresAt: Date.now() + 3600,
      };
      setBubbles([b]);
    };

    triggerPetExpressionRef.current = (m: PetExpressionMood) => {
      moodRef.current = m;
      if (m === 'rolling') rollRef.current = 0.001;
      if (m === 'eating') eatTimerRef.current = 2.6;
      petAudio.playVocal(species, m);
      spawnBubble(m);
    };

    const handlePointerDown = (ev: PointerEvent) => {
      petAudio.startBgm();
      const rect = renderer.domElement.getBoundingClientRect();
      pointer.x = ((ev.clientX - rect.left) / rect.width) * 2 - 1;
      pointer.y = -((ev.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(pointer, camera);

      const targets: THREE.Object3D[] = [rig.hitProxy];
      if (envHandles.giftBox.group.visible) {
        targets.push(envHandles.giftBox.hitProxy);
      }

      const hits = raycaster.intersectObjects(targets, false);
      if (hits.length === 0) return;

      if (hits[0].object.userData.isGiftBox) {
        envHandles.fireworks.burst(_fwOrigin);
        petAudio.playCelebrationFanfare();
        onOpenSkyGiftRef.current();
        return;
      }

      if (hits[0].object.userData.petSpecies) {
        // Touching the pet with finger/mouse -> barks/meows, rolls playfully, then shows happy welcoming pose!
        rollRef.current = 0.001;
        touchGreetRef.current = 3.6;
        const expressMood: PetExpressionMood =
          pottyRef.current >= 70
            ? 'potty'
            : moodRef.current === 'hungry'
              ? 'hungry'
              : 'rolling';
        const vocalMood: PetExpressionMood = expressMood === 'rolling' ? 'happy' : expressMood;
        if (expressMood === 'rolling') {
          moodRef.current = 'happy';
        }
        petAudio.playVocal(species, vocalMood);
        spawnBubble(expressMood);
        onTouchPetRef.current();
      }
    };

    renderer.domElement.addEventListener('pointerdown', handlePointerDown);

    const handleResize = () => {
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || window.innerHeight;
      camera.aspect = w / h;
      camera.position.z = w / h < 0.85 ? 5.6 : 4.4;
      camera.lookAt(0, 0.5, 0);
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    handleResize();
    window.addEventListener('resize', handleResize);

    const clock = new THREE.Clock();
    let frameId = 0;
    let disposed = false;
    let bubblePruneAcc = 0;
    let giftY = 4.6;

    // Free-roaming left/right playful state for the adopted pet
    type RoomPlayState = 'roam_lr' | 'trick' | 'jump_arc' | 'pose_front';
    let roomState: RoomPlayState = 'roam_lr';
    let roomTimer = 0;
    let roomDuration = 2.6;
    let roamTargetX = species === 'golden_retriever' ? -0.95 : 0.95;
    let roamTargetZ = 0.28;
    let roamHeading = 0.2;
    let jumpT = 0;
    let ballX = -0.82;
    let ballZ = 0.85;
    let ballVx = 0;
    let ballVz = 0;

    const shortestAngleLerp = (a: number, b: number, t: number) => {
      let d = ((b - a + Math.PI) % (Math.PI * 2)) - Math.PI;
      if (d < -Math.PI) d += Math.PI * 2;
      return a + d * t;
    };

    const tick = () => {
      if (disposed) return;
      const dt = Math.min(clock.getDelta(), 0.1);
      const elapsed = clock.getElapsedTime();

      // Interactive bouncing ball physics around the living room
      if (ballPlayTimerRef.current > 0) {
        ballPlayTimerRef.current = Math.max(0, ballPlayTimerRef.current - dt);
        if (Math.hypot(ballVx, ballVz) < 0.25) {
          ballVx = (Math.random() > 0.5 ? 1 : -1) * 1.45;
          ballVz = (Math.random() - 0.5) * 0.9;
        }
        ballX += ballVx * dt;
        ballZ += ballVz * dt;
        if (ballX > 1.25 || ballX < -1.25) {
          ballVx *= -0.92;
          ballX = THREE.MathUtils.clamp(ballX, -1.25, 1.25);
        }
        if (ballZ > 1.05 || ballZ < -0.15) {
          ballVz *= -0.92;
          ballZ = THREE.MathUtils.clamp(ballZ, -0.15, 1.05);
        }
        envHandles.ballMesh.position.set(
          ballX,
          0.16 + Math.abs(Math.sin(elapsed * 8.5)) * 0.26,
          ballZ,
        );
        envHandles.ballMesh.rotation.z -= ballVx * dt * 3;
      } else {
        ballX = THREE.MathUtils.damp(ballX, -0.82, 2.5, dt);
        ballZ = THREE.MathUtils.damp(ballZ, 0.85, 2.5, dt);
        ballVx = 0;
        ballVz = 0;
        envHandles.ballMesh.position.set(
          ballX,
          0.16 + Math.abs(Math.sin(elapsed * 2.1)) * 0.05,
          ballZ,
        );
      }

      // Sky Gift Box descent when 100 points reached (Req 8)
      if (giftReadyRef.current) {
        envHandles.giftBox.group.visible = true;
        giftY = THREE.MathUtils.damp(giftY, 0.02, 2.2, dt);
        envHandles.giftBox.group.position.y = giftY;
        envHandles.giftBox.group.position.x = 0.72 + Math.sin(elapsed * 2) * 0.06;
        envHandles.giftBox.group.rotation.y = Math.sin(elapsed * 1.4) * 0.25;
        envHandles.giftBox.parachute.visible = giftY > 0.25;
      } else {
        giftY = 4.6;
        envHandles.giftBox.group.visible = false;
      }

      envHandles.fireworks.update(dt);

      let gaitSpeed = 0;
      const extraMotion: PetPlayMotion = {};

      // Eating move toward food bowl
      if (eatTimerRef.current > 0) {
        eatTimerRef.current = Math.max(0, eatTimerRef.current - dt);
        const dx = 0.78 - rig.root.position.x;
        const dz = 0.52 - rig.root.position.z;
        rig.root.position.x = THREE.MathUtils.damp(rig.root.position.x, 0.78, 5, dt);
        rig.root.position.z = THREE.MathUtils.damp(rig.root.position.z, 0.52, 5, dt);
        rig.root.rotation.y = shortestAngleLerp(rig.root.rotation.y, 0.85, Math.min(1, dt * 6));
        gaitSpeed = Math.hypot(dx, dz) > 0.14 ? 0.75 : 0;
        if (eatTimerRef.current === 0) {
          moodRef.current = 'happy';
        }
      } else if (moodRef.current === 'potty') {
        const dx = -0.9 - rig.root.position.x;
        const dz = 0.2 - rig.root.position.z;
        rig.root.position.x = THREE.MathUtils.damp(rig.root.position.x, -0.9, 4, dt);
        rig.root.position.z = THREE.MathUtils.damp(rig.root.position.z, 0.2, 4, dt);
        rig.root.rotation.y = shortestAngleLerp(rig.root.rotation.y, -0.8, Math.min(1, dt * 6));
        gaitSpeed = Math.hypot(dx, dz) > 0.12 ? 0.65 : 0;
      } else if (ballPlayTimerRef.current > 0) {
        // Chase the bouncing ball excitedly!
        const dx = ballX - rig.root.position.x;
        const dz = ballZ - rig.root.position.z;
        const dist = Math.hypot(dx, dz);
        if (dist > 0.34) {
          const speed = 2.05;
          rig.root.position.x += (dx / dist) * speed * dt;
          rig.root.position.z += (dz / dist) * speed * dt;
          roamHeading = shortestAngleLerp(rig.root.rotation.y, Math.atan2(dx, dz), Math.min(1, dt * 10));
          rig.root.rotation.y = roamHeading;
          gaitSpeed = 1.25;
        }
        extraMotion.jumpY = Math.abs(Math.sin(elapsed * 6.5)) * (species === 'korean_shorthair' ? 0.38 : 0.28);
      } else if (touchGreetRef.current > 0) {
        // Turned happily toward user with welcoming bounce & play-bow / paw-wave!
        touchGreetRef.current = Math.max(0, touchGreetRef.current - dt);
        rig.root.position.x = THREE.MathUtils.damp(rig.root.position.x, 0, 4, dt);
        rig.root.position.z = THREE.MathUtils.damp(rig.root.position.z, 0.42, 4, dt);
        rig.root.rotation.y = shortestAngleLerp(rig.root.rotation.y, 0.05, Math.min(1, dt * 10));
        if (rollRef.current === 0) {
          extraMotion.jumpY = Math.abs(Math.sin(elapsed * 6.2)) * 0.2;
          if (species === 'golden_retriever') {
            extraMotion.playBow = Math.max(0, Math.sin(elapsed * 3.4)) * 0.65;
          } else {
            extraMotion.pawBat = 0.72;
          }
          extraMotion.lookYaw = Math.sin(elapsed * 4.2) * 0.14;
        }
      } else if (moodRef.current === 'hungry') {
        // Hungry pet stays near center-front looking gently pleading
        const dx = 0 - rig.root.position.x;
        const dz = 0.35 - rig.root.position.z;
        rig.root.position.x = THREE.MathUtils.damp(rig.root.position.x, 0, 3.5, dt);
        rig.root.position.z = THREE.MathUtils.damp(rig.root.position.z, 0.35, 3.5, dt);
        rig.root.rotation.y = shortestAngleLerp(rig.root.rotation.y, 0.08, Math.min(1, dt * 5));
        gaitSpeed = Math.hypot(dx, dz) > 0.12 ? 0.45 : 0;
      } else {
        // Lively Free-Play Left-Right Bounding & Species-Distinct Tricks!
        roomTimer += dt;
        if (roomTimer >= roomDuration) {
          roomTimer = 0;
          if (roomState === 'roam_lr') {
            roomState = 'trick';
            roomDuration = species === 'golden_retriever' ? 1.85 : 1.55;
          } else if (roomState === 'trick') {
            roomState = 'jump_arc';
            roomDuration = 1.5;
            roamTargetX = rig.root.position.x > 0 ? -1.15 : 1.15;
            roamTargetZ = 0.05 + Math.random() * 0.45;
            jumpT = 0.001;
          } else if (roomState === 'jump_arc') {
            roomState = 'pose_front';
            roomDuration = 1.4;
          } else {
            roomState = 'roam_lr';
            roomDuration = 2.8;
            roamTargetX = rig.root.position.x > 0 ? -1.15 : 1.15;
            roamTargetZ = -0.1 + Math.random() * 0.65;
            jumpT = 0.001;
          }
        }

        if (roomState === 'roam_lr' || roomState === 'jump_arc') {
          const dx = roamTargetX - rig.root.position.x;
          const dz = roamTargetZ - rig.root.position.z;
          const dist = Math.hypot(dx, dz);
          if (dist < 0.16) {
            roamTargetX = rig.root.position.x > 0 ? -1.2 : 1.2;
            roamTargetZ = -0.15 + Math.random() * 0.7;
            jumpT = 0.001;
          } else {
            const speed = roomState === 'jump_arc' ? 1.85 : 1.35;
            rig.root.position.x += (dx / dist) * speed * dt;
            rig.root.position.z += (dz / dist) * speed * dt;
            rig.root.rotation.y = shortestAngleLerp(
              rig.root.rotation.y,
              Math.atan2(dx, dz),
              Math.min(1, dt * 8),
            );
            gaitSpeed = roomState === 'jump_arc' ? 1.15 : 0.85;
          }

          if (jumpT > 0) {
            const dur = species === 'korean_shorthair' ? 0.56 : 0.48;
            jumpT += dt / dur;
            if (jumpT >= 1) jumpT = 0;
            else {
              const peak = species === 'korean_shorthair' ? 0.46 : 0.34;
              extraMotion.jumpY = Math.sin(jumpT * Math.PI) * peak;
            }
          } else if (roomState === 'jump_arc') {
            jumpT = 0.001;
          }
        } else if (roomState === 'trick') {
          rig.root.rotation.y = shortestAngleLerp(rig.root.rotation.y, 0.15, Math.min(1, dt * 6));
          const fade = Math.sin((roomTimer / roomDuration) * Math.PI);
          if (species === 'golden_retriever') {
            extraMotion.playBow = Math.min(1, fade * 1.4);
          } else {
            if (roomTimer < roomDuration * 0.45) {
              extraMotion.pounceCrouch = 0.9;
            } else {
              extraMotion.pawBat = Math.min(1, fade * 1.4);
            }
          }
        } else {
          // pose_front
          rig.root.rotation.y = shortestAngleLerp(rig.root.rotation.y, 0.06, Math.min(1, dt * 6));
          extraMotion.lookYaw = Math.sin(elapsed * 2.4) * 0.22;
        }
      }

      if (rollRef.current > 0) {
        rollRef.current += dt * 0.88;
        if (rollRef.current >= 1) {
          rollRef.current = 0;
        }
      }

      const activeMood: PetExpressionMood =
        eatTimerRef.current > 0
          ? 'eating'
          : rollRef.current > 0
            ? 'rolling'
            : moodRef.current;

      updatePetGrowthAndPose(
        rig,
        maturityRef.current,
        gaitSpeed,
        elapsed * 7.4,
        activeMood,
        elapsed,
        rollRef.current,
        healthRef.current,
        extraMotion,
      );

      bubblePruneAcc += dt;
      if (bubblePruneAcc > 0.2) {
        bubblePruneAcc = 0;
        const now = Date.now();
        setBubbles((prev) => {
          const next = prev.filter((b) => b.expiresAt > now);
          return next.length === prev.length ? prev : next;
        });
      }

      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(renderer, tick, (id) => {
          frameId = id;
        });
      } else {
        frameId = requestAnimationFrame(tick);
      }
    };
    tick();

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('resize', handleResize);
      renderer.domElement.removeEventListener('pointerdown', handlePointerDown);
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
      rigRef.current = null;
      envRef.current = null;
    };
  }, [species]);

  // Pointer drag-and-drop from gift/wardrobe item onto the 3D pet (Req 8)
  useEffect(() => {
    if (!draggingItem) return;
    const onMove = (e: PointerEvent) => {
      setDraggingItem((prev) => (prev ? {...prev, x: e.clientX, y: e.clientY} : null));
    };
    const onUp = (e: PointerEvent) => {
      const rect = mountRef.current?.getBoundingClientRect();
      if (rect) {
        const cx = rect.left + rect.width * 0.5;
        const cy = rect.top + rect.height * 0.55;
        const dist = Math.hypot(e.clientX - cx, e.clientY - cy);
        if (dist < Math.min(rect.width, rect.height) * 0.42) {
          onEquipItem(draggingItem.item);
          petAudio.playChime();
          triggerPetExpressionRef.current('happy');
          showToast(`${draggingItem.item.name} 착용 완료!`);
        }
      }
      setDraggingItem(null);
    };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
    return () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
    };
  }, [draggingItem, onEquipItem]);

  const handleFeedClick = () => {
    const res = onFeed();
    triggerPetExpressionRef.current('eating');
    if (res.onTime) {
      showToast(`정시 식사 완료! 보너스 +${res.pointsAdded}점 획득`);
    } else {
      showToast('식사를 챙겨주어 체력이 회복되었습니다!');
    }
  };

  const handlePottyClick = () => {
    onCleanPotty();
    triggerPetExpressionRef.current('happy');
    showToast('배변 패드를 깔끔하게 정리했습니다 (+3점)');
  };

  const handlePlayBallClick = () => {
    ballPlayTimerRef.current = 3.2;
    onPlayBall();
    triggerPetExpressionRef.current('happy');
    showToast('신나는 공놀이로 보너스 +4점 획득!');
  };

  const petInfo = PET_DISPLAY_INFO[species];
  const lifeStage = getLifeStageLabel(species, maturity);
  const nextMilestone = Math.floor(bonusScore / 100) * 100 + 100;

  return (
    <div className="relative w-full h-full overflow-hidden bg-amber-50 select-none">
      {/* 3D Viewport */}
      <div ref={mountRef} className="absolute inset-0 w-full h-full cursor-pointer" />

      {/* Top Status & Score Header */}
      <header className="absolute top-0 left-0 right-0 z-20 p-3 sm:p-4 flex flex-wrap items-start justify-between gap-2 pointer-events-none">
        <div className="pointer-events-auto flex items-center gap-2.5 bg-white/94 border border-stone-200 rounded-2xl px-3.5 py-2 shadow-sm">
          <button
            type="button"
            onClick={onBackToShowcase}
            aria-label="분양 화면으로"
            className="p-1.5 rounded-lg hover:bg-stone-100 text-stone-700 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-display font-bold text-sm sm:text-base text-stone-900">
                {petInfo.koreanName}
              </span>
              <span className="text-xs font-medium text-amber-800">
                · {lifeStage.monthsText} ({lifeStage.stage})
              </span>
            </div>
            <div className="flex items-center gap-3 text-[11px] text-stone-600 mt-0.5 tabular-nums">
              <span>포만감 {Math.round(hunger)}%</span>
              <span>·</span>
              <span>활력 {Math.round(vitality)}%</span>
              <span>·</span>
              <span>배변신호 {Math.round(pottyNeed)}%</span>
            </div>
          </div>
        </div>

        {/* Score & Wardrobe Toggle (Req 7) */}
        <div className="pointer-events-auto flex items-center gap-2">
          <div className="bg-white/94 border border-stone-200 rounded-2xl px-4 py-2 shadow-sm text-right">
            <div className="text-[11px] font-medium text-stone-500">
              {started ? '보너스 점수 (세팅 연동)' : '기본점수'}
            </div>
            <div className="font-mono-num text-lg font-bold text-stone-900 leading-tight">
              {started ? `${bonusScore}점` : `${baseScore}점`}
              {started && (
                <span className="text-[11px] font-normal text-amber-700 ml-1.5">
                  / 선물 {nextMilestone}점
                </span>
              )}
            </div>
          </div>

          <button
            type="button"
            onClick={() => setWardrobeOpen((o) => !o)}
            className={`flex items-center gap-1.5 px-3.5 py-2.5 rounded-2xl border text-xs font-bold shadow-sm transition-colors cursor-pointer ${
              wardrobeOpen
                ? 'bg-stone-900 text-white border-stone-900'
                : 'bg-white/94 text-stone-800 border-stone-200 hover:bg-amber-50'
            }`}
          >
            <Shirt className="w-4 h-4" />
            <span>옷장</span>
          </button>

          <button
            type="button"
            onClick={onToggleBgm}
            aria-label={bgmEnabled ? '배경음악 끄기' : '배경음악 켜기'}
            className={`flex items-center gap-1.5 px-3 py-2.5 rounded-2xl border text-xs font-semibold shadow-sm transition-colors cursor-pointer ${
              bgmEnabled && !muted
                ? 'bg-amber-50 border-amber-300 text-amber-900'
                : 'bg-white/94 border-stone-200 text-stone-500'
            }`}
          >
            <Music className="w-4 h-4" />
            <span className="hidden sm:inline">{bgmEnabled && !muted ? '배경음 ON' : '배경음 OFF'}</span>
          </button>

          <button
            type="button"
            onClick={onToggleMute}
            aria-label={muted ? '소리 켜기' : '소리 끄기'}
            className="p-2.5 rounded-2xl bg-white/94 border border-stone-200 text-stone-800 hover:bg-stone-100 shadow-sm cursor-pointer"
          >
            {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
        </div>
      </header>

      {/* Sky Gift Box Prompt when 100pt Gift arrives */}
      {giftReadyInSky && (
        <div className="absolute top-20 left-1/2 -translate-x-1/2 z-20 animate-float-slow">
          <button
            type="button"
            onClick={() => {
              envRef.current?.fireworks.burst(_fwOrigin);
              petAudio.playCelebrationFanfare();
              onOpenSkyGift();
            }}
            className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-rose-600 hover:bg-rose-700 text-white text-xs sm:text-sm font-bold shadow-lg cursor-pointer"
          >
            <Gift className="w-4 h-4" />
            <span>하늘에서 선물상자가 내려왔어요! 터치해 보세요</span>
          </button>
        </div>
      )}

      {/* Revealed Gift Outfit Card (can store in wardrobe or drag onto pet!) */}
      {pendingGiftItem && (
        <div className="absolute top-24 left-1/2 -translate-x-1/2 z-30 w-[90vw] max-w-sm rounded-3xl bg-white border-2 border-rose-300 p-4 shadow-2xl">
          <div className="flex items-center gap-3">
            <div
              className="w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 border border-stone-200 cursor-grab active:cursor-grabbing"
              style={{backgroundColor: pendingGiftItem.primaryColor}}
              onPointerDown={(e) => {
                e.preventDefault();
                setDraggingItem({item: pendingGiftItem, x: e.clientX, y: e.clientY});
              }}
            >
              <Shirt className="w-7 h-7 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-[11px] font-bold text-rose-600 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5" /> 100점 달성 축하 선물!
              </div>
              <div className="font-display font-bold text-base text-stone-900 truncate">
                {pendingGiftItem.name}
              </div>
              <div className="text-[11px] text-stone-500">
                아이콘을 손가락으로 끌어 입히거나 옷장에 보관하세요
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 mt-3">
            <button
              type="button"
              onClick={() => {
                onStorePendingGift();
                setWardrobeOpen(true);
                showToast(`${pendingGiftItem.name}이(가) 옷장에 보관되었습니다.`);
              }}
              className="flex-1 py-2 rounded-xl border border-stone-200 bg-stone-50 hover:bg-stone-100 text-xs font-semibold text-stone-800 cursor-pointer"
            >
              옷장에 보관
            </button>
            <button
              type="button"
              onClick={() => {
                onEquipItem(pendingGiftItem);
                petAudio.playChime();
                triggerPetExpressionRef.current('happy');
                showToast(`${pendingGiftItem.name}을(를) 바로 입혔어요!`);
              }}
              className="flex-1 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold cursor-pointer"
            >
              바로 입히기
            </button>
          </div>
        </div>
      )}

      {/* Side Wardrobe Drawer (옆에 옷장 - Req 8 & Req 9) */}
      {wardrobeOpen && (
        <aside className="absolute top-20 right-3 sm:right-4 bottom-28 z-30 w-72 sm:w-80 rounded-3xl bg-white/96 border border-stone-200 shadow-2xl flex flex-col overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3 border-b border-stone-100">
            <div>
              <h3 className="font-display text-sm font-bold text-stone-900">
                반려동물 옷장 · 액세서리
              </h3>
              <p className="text-[11px] text-stone-500">
                손가락으로 끌어 3D 반려동물에게 입혀보세요
              </p>
            </div>
            <button
              type="button"
              onClick={() => setWardrobeOpen(false)}
              className="p-1.5 rounded-lg text-stone-500 hover:bg-stone-100 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-3 space-y-2">
            {WARDROBE_CATALOG.map((item) => {
              const unlocked =
                unlockedItemIds.includes(item.id) || bonusScore >= item.unlockScore;
              const isEquipped =
                equippedClothesId === item.id || equippedAccessoryId === item.id;

              return (
                <div
                  key={item.id}
                  className={`rounded-2xl border p-3 transition-colors ${
                    isEquipped
                      ? 'border-amber-500 bg-amber-50/70'
                      : unlocked
                        ? 'border-stone-200 bg-white hover:bg-stone-50'
                        : 'border-stone-100 bg-stone-50 opacity-70'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      onPointerDown={(e) => {
                        if (!unlocked) return;
                        e.preventDefault();
                        setDraggingItem({item, x: e.clientX, y: e.clientY});
                      }}
                      className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 border border-stone-200 ${
                        unlocked ? 'cursor-grab active:cursor-grabbing' : ''
                      }`}
                      style={{backgroundColor: item.primaryColor}}
                    >
                      <Shirt className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1">
                        <span className="text-xs font-bold text-stone-900 truncate">
                          {item.name}
                        </span>
                        <span className="text-[10px] font-mono-num text-stone-500 shrink-0">
                          {item.unlockScore}점
                        </span>
                      </div>
                      <p className="text-[11px] text-stone-500 truncate mt-0.5">
                        {item.description}
                      </p>
                    </div>
                  </div>

                  <div className="mt-2 flex items-center justify-between gap-2">
                    <span className="text-[10px] text-stone-500">
                      {item.slot === 'clothes' ? '의상' : '목걸이·장식'}
                    </span>
                    {unlocked ? (
                      isEquipped ? (
                        <button
                          type="button"
                          onClick={() => onUnequipSlot(item.slot)}
                          className="px-2.5 py-1 rounded-lg bg-stone-200 text-stone-800 text-[11px] font-semibold cursor-pointer"
                        >
                          벗기기
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => {
                            onEquipItem(item);
                            petAudio.playChime();
                            triggerPetExpressionRef.current('happy');
                          }}
                          className="px-2.5 py-1 rounded-lg bg-stone-900 hover:bg-stone-800 text-white text-[11px] font-semibold cursor-pointer"
                        >
                          입히기 (또는 드래그)
                        </button>
                      )
                    ) : (
                      <span className="text-[11px] font-medium text-amber-700">
                        보너스 {item.unlockScore}점 필요
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </aside>
      )}

      {/* Floating Drag Ghost when dragging outfit onto 3D pet */}
      {draggingItem && (
        <div
          style={{
            left: `${draggingItem.x}px`,
            top: `${draggingItem.y}px`,
          }}
          className="fixed z-50 -translate-x-1/2 -translate-y-1/2 pointer-events-none"
        >
          <div
            className="w-16 h-16 rounded-2xl shadow-2xl border-2 border-white flex flex-col items-center justify-center text-white"
            style={{backgroundColor: draggingItem.item.primaryColor}}
          >
            <Shirt className="w-7 h-7" />
            <span className="text-[10px] font-bold mt-0.5">입히기</span>
          </div>
        </div>
      )}

      {/* Korean Speech Bubbles projected over 3D pet */}
      {bubbles.map((b) => (
        <div
          key={b.id}
          style={{left: `${b.screenX}px`, top: `${b.screenY}px`}}
          className="absolute z-20 pointer-events-none animate-bubble-pop"
        >
          <div className="relative max-w-[250px] rounded-2xl bg-white border border-amber-200 px-3.5 py-2.5 shadow-lg">
            <div className="text-[11px] font-semibold text-amber-700 mb-0.5">
              {b.subLabel}
            </div>
            <div className="text-xs sm:text-sm font-medium text-stone-900 leading-snug">
              {b.text}
            </div>
            <div className="absolute left-1/2 -bottom-2 -translate-x-1/2 w-3.5 h-3.5 bg-white border-r border-b border-amber-200 rotate-45" />
          </div>
        </div>
      ))}

      {/* Toast Notification */}
      {toastMsg && (
        <div className="absolute top-20 left-1/2 -translate-x-1/2 z-40 rounded-2xl bg-stone-900 text-white px-4 py-2 text-xs font-semibold shadow-xl">
          {toastMsg}
        </div>
      )}

      {/* 4 Expressive Mood Triggers + Schedule Strip just above bottom dock */}
      <div className="absolute bottom-24 left-1/2 -translate-x-1/2 z-20 flex flex-wrap items-center justify-center gap-1.5 max-w-[95vw]">
        <button
          type="button"
          onClick={() => triggerPetExpressionRef.current('hungry')}
          className="px-2.5 py-1 rounded-xl bg-white/90 border border-stone-200 text-[11px] font-medium text-stone-700 hover:bg-amber-50 cursor-pointer"
        >
          배고픔 표현
        </button>
        <button
          type="button"
          onClick={() => triggerPetExpressionRef.current('happy')}
          className="px-2.5 py-1 rounded-xl bg-white/90 border border-stone-200 text-[11px] font-medium text-stone-700 hover:bg-amber-50 cursor-pointer"
        >
          신나서 짖기
        </button>
        <button
          type="button"
          onClick={() => triggerPetExpressionRef.current('potty')}
          className="px-2.5 py-1 rounded-xl bg-white/90 border border-stone-200 text-[11px] font-medium text-stone-700 hover:bg-amber-50 cursor-pointer"
        >
          배변 신호
        </button>
        <button
          type="button"
          onClick={() => triggerPetExpressionRef.current('want_something')}
          className="px-2.5 py-1 rounded-xl bg-white/90 border border-stone-200 text-[11px] font-medium text-stone-700 hover:bg-amber-50 cursor-pointer"
        >
          하고싶은 것
        </button>
      </div>

      {/* Unified Bottom Control Dock (Req 6, 7, 9, 11) */}
      <footer className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 w-[95vw] max-w-4xl rounded-3xl bg-white/95 border border-stone-200 px-3 sm:px-5 py-2.5 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-2">
          {/* Active Care Actions */}
          <div className="flex items-center gap-1.5 sm:gap-2 overflow-x-auto">
            <button
              type="button"
              onClick={handleFeedClick}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Utensils className="w-3.5 h-3.5" />
              <span>밥 주기</span>
            </button>
            <button
              type="button"
              onClick={onStartWalk}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Footprints className="w-3.5 h-3.5" />
              <span>산책 나가기</span>
            </button>
            <button
              type="button"
              onClick={handlePottyClick}
              className={`px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap shrink-0 cursor-pointer ${
                pottyNeed >= 65
                  ? 'bg-sky-600 text-white hover:bg-sky-700'
                  : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
              }`}
            >
              배변 치우기
            </button>
            <button
              type="button"
              onClick={handlePlayBallClick}
              className="px-3 py-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-bold whitespace-nowrap shrink-0 cursor-pointer"
            >
              공놀이 (+4점)
            </button>
          </div>

          {/* Settings, Start, Donate (Req 7 & Req 9) */}
          <div className="flex items-center gap-1.5 sm:gap-2 ml-auto">
            <button
              type="button"
              onClick={onOpenSettings}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-stone-200 bg-white hover:bg-stone-50 text-stone-800 text-xs font-bold whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Settings className="w-3.5 h-3.5" />
              <span>세팅</span>
            </button>

            {!started ? (
              <button
                type="button"
                onClick={() => {
                  onStartCare();
                  petAudio.playChime();
                  triggerPetExpressionRef.current('happy');
                  showToast(
                    `시작! 식사(${schedule.morningMeal}/${schedule.lunchMeal}/${schedule.dinnerMeal})·산책(${schedule.walkTime}) 보너스가 활성화되었습니다.`,
                  );
                }}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Play className="w-3.5 h-3.5 text-amber-400" />
                <span>시작하기</span>
              </button>
            ) : (
              <div className="hidden md:flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-50 border border-amber-200 text-[11px] font-semibold text-amber-900 whitespace-nowrap">
                <span>
                  {timeScaleMode === 'fast' ? '빠른 성장 중' : '실시간 성장 중'}
                </span>
              </div>
            )}

            <button
              type="button"
              onClick={onOpenDonation}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Heart className="w-3.5 h-3.5" />
              <span>후원하기</span>
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
};
