import React, {useEffect, useRef, useState} from 'react';
import * as THREE from 'three';
import {Music, RotateCcw, Volume2, VolumeX} from 'lucide-react';
import {petAudio} from '../audio/petAudio';
import {
  afterDraw,
  buildShowcaseEnvironment,
  createConfiguredRenderer,
  detectSoftwareGl,
  setupStudioLighting,
} from '../three/environmentScene';
import {createProceduralTextureSet} from '../three/furTextures';
import {
  createGoldenRetrieverRig,
  createKoreanShorthairRig,
  PetPlayMotion,
  PetRig,
  updatePetGrowthAndPose,
} from '../three/petModels';
import {getSpeechForMood, PetExpressionMood, PetSpecies, SpeechBubbleState} from '../types/pet';

interface ShowcaseStageProps {
  onAdopt: (species: PetSpecies) => void;
  muted: boolean;
  bgmEnabled: boolean;
  onToggleMute: () => void;
  onToggleBgm: () => void;
}

type DogPlayPhase = 'bound_lr' | 'play_bow' | 'happy_hop' | 'front_greet';
type CatPlayPhase = 'crouch_stalk' | 'pounce_leap' | 'paw_bat' | 'zigzag_dash' | 'front_curious';

interface FreePlayAgent<TPhase extends string> {
  x: number;
  z: number;
  targetX: number;
  targetZ: number;
  headingY: number;
  phase: TPhase;
  phaseTimer: number;
  phaseDuration: number;
  jumpT: number;
  jumpDur: number;
  jumpPeak: number;
  dir: number;
}

const _projVec = new THREE.Vector3();

function shortestAngleLerp(current: number, target: number, factor: number): number {
  let diff = ((target - current + Math.PI) % (Math.PI * 2)) - Math.PI;
  if (diff < -Math.PI) diff += Math.PI * 2;
  return current + diff * factor;
}

export const ShowcaseStage: React.FC<ShowcaseStageProps> = ({
  onAdopt,
  muted,
  bgmEnabled,
  onToggleMute,
  onToggleBgm,
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const progressRef = useRef(0);
  const dogRollRef = useRef(0);
  const catRollRef = useRef(0);
  const dogTouchGreetRef = useRef(0);
  const catTouchGreetRef = useRef(0);
  const dogMoodRef = useRef<PetExpressionMood>('happy');
  const catMoodRef = useRef<PetExpressionMood>('happy');

  const [growthProgress, setGrowthProgress] = useState(0);
  const [bubbles, setBubbles] = useState<SpeechBubbleState[]>([]);
  const bubbleIdRef = useRef(1);

  const replayGrowth = () => {
    progressRef.current = 0;
    setGrowthProgress(0);
    setBubbles([]);
  };

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const isSoftwareGl = detectSoftwareGl();
    const renderer = createConfiguredRenderer(container, isSoftwareGl, false);
    const scene = new THREE.Scene();
    setupStudioLighting(scene, renderer, 0xe8f2fa);

    const camera = new THREE.PerspectiveCamera(
      40,
      (container.clientWidth || window.innerWidth) / (container.clientHeight || window.innerHeight),
      0.1,
      100,
    );
    camera.position.set(0, 1.75, 6.4);
    camera.lookAt(0, 0.55, 0);

    const textures = createProceduralTextureSet(
      renderer.capabilities.getMaxAnisotropy(),
    );
    buildShowcaseEnvironment(scene, textures);

    const dogRig = createGoldenRetrieverRig(textures, isSoftwareGl);
    const catRig = createKoreanShorthairRig(textures, isSoftwareGl);
    scene.add(dogRig.root);
    scene.add(catRig.root);

    dogRig.root.position.set(-3.45, 0, 0.25);
    catRig.root.position.set(0.58, 0, 0.35);

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();
    const clickTargets = [dogRig.hitProxy, catRig.hitProxy];

    const triggerBubble = (rig: PetRig, species: PetSpecies, mood: PetExpressionMood) => {
      const {text, subLabel} = getSpeechForMood(species, mood);
      _projVec.copy(rig.root.position);
      _projVec.y += species === 'golden_retriever' ? 1.15 : 0.92;
      _projVec.project(camera);

      const rect = renderer.domElement.getBoundingClientRect();
      const sx = ((_projVec.x + 1) / 2) * rect.width;
      const sy = ((-_projVec.y + 1) / 2) * rect.height;

      const newBubble: SpeechBubbleState = {
        id: bubbleIdRef.current++,
        species,
        mood,
        text,
        subLabel,
        screenX: Math.min(Math.max(sx, 110), rect.width - 110),
        screenY: Math.max(sy, 76),
        expiresAt: Date.now() + 3400,
      };

      setBubbles((prev) => [
        ...prev.filter((b) => b.species !== species && b.expiresAt > Date.now()),
        newBubble,
      ]);
    };

    const handlePointerDown = (ev: PointerEvent) => {
      petAudio.startBgm();
      const rect = renderer.domElement.getBoundingClientRect();
      pointer.x = ((ev.clientX - rect.left) / rect.width) * 2 - 1;
      pointer.y = -((ev.clientY - rect.top) / rect.height) * 2 + 1;
      raycaster.setFromCamera(pointer, camera);

      const hits = raycaster.intersectObjects(clickTargets, false);
      if (hits.length === 0) return;

      const hitSpecies = hits[0].object.userData.petSpecies as PetSpecies;
      if (hitSpecies === 'golden_retriever') {
        dogRollRef.current = 0.001;
        dogTouchGreetRef.current = 3.8;
        dogMoodRef.current = 'happy';
        // Bark brightly + greet warmly!
        petAudio.playVocal('golden_retriever', 'happy');
        triggerBubble(dogRig, 'golden_retriever', 'rolling');
      } else if (hitSpecies === 'korean_shorthair') {
        catRollRef.current = 0.001;
        catTouchGreetRef.current = 3.8;
        catMoodRef.current = 'happy';
        // Meow cheerfully + greet warmly!
        petAudio.playVocal('korean_shorthair', 'happy');
        triggerBubble(catRig, 'korean_shorthair', 'rolling');
      }
    };

    renderer.domElement.addEventListener('pointerdown', handlePointerDown);

    const handleResize = () => {
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || window.innerHeight;
      camera.aspect = w / h;
      camera.position.z = w / h < 0.85 ? 8.8 : w / h < 1.25 ? 7.4 : 6.4;
      camera.lookAt(0, 0.55, 0);
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    const resizeObs =
      typeof ResizeObserver !== 'undefined'
        ? new ResizeObserver(() => handleResize())
        : null;
    resizeObs?.observe(container);

    // Independent autonomous play state machines for dog (left) & cat (right)
    const dogAgent: FreePlayAgent<DogPlayPhase> = {
      x: -1.25,
      z: 0.25,
      targetX: -2.45,
      targetZ: 0.55,
      headingY: 0.16,
      phase: 'front_greet',
      phaseTimer: 0,
      phaseDuration: 1.6,
      jumpT: 0,
      jumpDur: 0.55,
      jumpPeak: 0.34,
      dir: -1,
    };

    const catAgent: FreePlayAgent<CatPlayPhase> = {
      x: 1.65,
      z: 0.35,
      targetX: 2.35,
      targetZ: 0.65,
      headingY: -0.16,
      phase: 'front_curious',
      phaseTimer: 0,
      phaseDuration: 1.3,
      jumpT: 0,
      jumpDur: 0.48,
      jumpPeak: 0.46,
      dir: 1,
    };

    const pickNextDogPhase = (current: DogPlayPhase) => {
      if (current === 'front_greet') {
        dogAgent.phase = 'bound_lr';
        dogAgent.phaseDuration = 3.2;
        dogAgent.dir = dogAgent.x > -1.7 ? -1 : 1;
        dogAgent.targetX = dogAgent.dir < 0 ? -2.75 : -0.75;
        dogAgent.targetZ = (Math.random() - 0.35) * 0.9;
        dogAgent.jumpT = 0.001;
        dogAgent.jumpDur = 0.52;
        dogAgent.jumpPeak = 0.32;
      } else if (current === 'bound_lr') {
        dogAgent.phase = 'play_bow';
        dogAgent.phaseDuration = 2.0;
      } else if (current === 'play_bow') {
        dogAgent.phase = 'happy_hop';
        dogAgent.phaseDuration = 1.6;
        dogAgent.jumpT = 0.001;
        dogAgent.jumpDur = 0.46;
        dogAgent.jumpPeak = 0.38;
      } else {
        dogAgent.phase = 'front_greet';
        dogAgent.phaseDuration = 1.5;
      }
      dogAgent.phaseTimer = 0;
    };

    const pickNextCatPhase = (current: CatPlayPhase) => {
      if (current === 'front_curious') {
        catAgent.phase = 'zigzag_dash';
        catAgent.phaseDuration = 2.8;
        catAgent.dir = catAgent.x > 1.75 ? -1 : 1;
        catAgent.targetX = catAgent.dir < 0 ? 0.72 : 2.75;
        catAgent.targetZ = (Math.random() - 0.3) * 0.95;
      } else if (current === 'zigzag_dash') {
        catAgent.phase = 'crouch_stalk';
        catAgent.phaseDuration = 1.25;
      } else if (current === 'crouch_stalk') {
        catAgent.phase = 'pounce_leap';
        catAgent.phaseDuration = 1.35;
        catAgent.dir = catAgent.x > 1.75 ? -1 : 1;
        catAgent.targetX = catAgent.dir < 0 ? 0.65 : 2.7;
        catAgent.targetZ = 0.15 + (Math.random() - 0.5) * 0.65;
        catAgent.jumpT = 0.001;
        catAgent.jumpDur = 0.62;
        catAgent.jumpPeak = 0.52;
      } else if (current === 'pounce_leap') {
        catAgent.phase = 'paw_bat';
        catAgent.phaseDuration = 2.1;
      } else {
        catAgent.phase = 'front_curious';
        catAgent.phaseDuration = 1.4;
      }
      catAgent.phaseTimer = 0;
    };

    const clock = new THREE.Clock();
    let frameId = 0;
    let disposed = false;
    let uiSyncAccumulator = 0;
    let arrivedGreets = false;
    let prevProgress = 0;

    const tick = () => {
      if (disposed) return;
      const dt = Math.min(clock.getDelta(), 0.1);
      const elapsed = clock.getElapsedTime();

      // Detect replay reset
      if (progressRef.current < prevProgress) {
        arrivedGreets = false;
        dogAgent.x = -1.25;
        dogAgent.z = 0.25;
        catAgent.x = 1.65;
        catAgent.z = 0.35;
      }

      if (progressRef.current < 1) {
        progressRef.current = Math.min(1, progressRef.current + dt / 8.0);
      } else if (!arrivedGreets) {
        arrivedGreets = true;
        dogAgent.x = -1.25;
        dogAgent.z = 0.25;
        dogAgent.headingY = 0.16;
        dogAgent.phase = 'front_greet';
        dogAgent.phaseTimer = 0;
        dogAgent.phaseDuration = 1.3;

        catAgent.x = 1.65;
        catAgent.z = 0.35;
        catAgent.headingY = -0.16;
        catAgent.phase = 'front_curious';
        catAgent.phaseTimer = 0;
        catAgent.phaseDuration = 1.1;

        triggerBubble(dogRig, 'golden_retriever', 'happy');
        triggerBubble(catRig, 'korean_shorthair', 'happy');
      }
      prevProgress = progressRef.current;

      const p = progressRef.current;
      let dogGaitSpeed = 0;
      let catGaitSpeed = 0;
      const dogExtra: PetPlayMotion = {};
      const catExtra: PetPlayMotion = {};

      if (p < 1) {
        // Growth Showcase Phase: walking/hopping left->right with distinct gaits!
        const walkPhase = Math.min(p / 0.82, 1);
        const turnPhase = p <= 0.82 ? 0 : THREE.MathUtils.smoothstep(p, 0.82, 1.0);

        // Golden Retriever: joyful bounding left->right with periodic playful hops
        const dogX = THREE.MathUtils.lerp(-3.45, -1.25, walkPhase);
        const dogZ = 0.25 + Math.sin(walkPhase * Math.PI * 3) * 0.18;
        dogRig.root.position.set(dogX, 0, dogZ);
        dogRig.root.rotation.y = THREE.MathUtils.lerp(Math.PI * 0.45, 0.16, turnPhase);

        if (p < 0.82) {
          dogGaitSpeed = 0.85;
          const hopWave = Math.sin(elapsed * 3.8);
          dogExtra.jumpY = hopWave > 0.35 ? ((hopWave - 0.35) / 0.65) * 0.24 : 0;
        } else {
          // Friendly tail-wagging greeting bounce at the end
          dogExtra.playBow = Math.sin((p - 0.82) / 0.18 * Math.PI) * 0.55;
        }

        // Korean Shorthair: nimble zig-zag weave + distinct kitty spring leaps!
        const catX = THREE.MathUtils.lerp(0.55, 1.85, walkPhase);
        const catZ = 0.35 + Math.cos(walkPhase * Math.PI * 4) * 0.26;
        catRig.root.position.set(catX, 0, catZ);
        catRig.root.rotation.y =
          p < 0.82
            ? Math.PI * 0.46 + Math.sin(walkPhase * Math.PI * 4) * 0.35
            : THREE.MathUtils.lerp(Math.PI * 0.46, -0.16, turnPhase);

        if (p < 0.82) {
          catGaitSpeed = 0.72;
          const pounceWave = Math.sin(elapsed * 2.7 + 1.4);
          catExtra.jumpY = pounceWave > 0.55 ? ((pounceWave - 0.55) / 0.45) * 0.36 : 0;
        } else {
          catExtra.pawBat = Math.sin((p - 0.82) / 0.18 * Math.PI) * 0.75;
        }
      } else {
        // --- FREE PLAY MODE (Asynchronous, distinct left/right jumping & playful tricks) ---

        // 1. Golden Retriever (Left Zone: x in [-2.95, -0.55])
        if (dogTouchGreetRef.current > 0) {
          dogTouchGreetRef.current = Math.max(0, dogTouchGreetRef.current - dt);
          // Turn happily toward user and show ecstatic welcoming jump/play-bow!
          dogAgent.headingY = shortestAngleLerp(dogAgent.headingY, 0.08, Math.min(1, dt * 10));
          dogAgent.z = THREE.MathUtils.damp(dogAgent.z, 0.55, 4, dt);
          if (dogRollRef.current === 0) {
            dogExtra.jumpY = Math.abs(Math.sin(elapsed * 6.4)) * 0.22;
            dogExtra.playBow = Math.max(0, Math.sin(elapsed * 3.5)) * 0.65;
            dogExtra.lookYaw = Math.sin(elapsed * 4.5) * 0.14;
          }
        } else {
          dogAgent.phaseTimer += dt;
          if (dogAgent.phaseTimer >= dogAgent.phaseDuration) {
            pickNextDogPhase(dogAgent.phase);
          }

          if (dogAgent.phase === 'bound_lr') {
            const dx = dogAgent.targetX - dogAgent.x;
            const dz = dogAgent.targetZ - dogAgent.z;
            const dist = Math.hypot(dx, dz);
            if (dist < 0.18) {
              dogAgent.dir *= -1;
              dogAgent.targetX = dogAgent.dir < 0 ? -2.85 : -0.6;
              dogAgent.targetZ = (Math.random() - 0.35) * 0.95;
              dogAgent.jumpT = 0.001;
            } else {
              const speed = 1.65;
              dogAgent.x += (dx / dist) * speed * dt;
              dogAgent.z += (dz / dist) * speed * dt;
              const desiredYaw = Math.atan2(dx, dz);
              dogAgent.headingY = shortestAngleLerp(dogAgent.headingY, desiredYaw, Math.min(1, dt * 8));
              dogGaitSpeed = 1.15;
            }
            if (dogAgent.jumpT > 0) {
              dogAgent.jumpT += dt / dogAgent.jumpDur;
              if (dogAgent.jumpT >= 1) {
                dogAgent.jumpT = 0;
              } else {
                dogExtra.jumpY = Math.sin(dogAgent.jumpT * Math.PI) * dogAgent.jumpPeak;
              }
            } else if (Math.random() < dt * 1.4) {
              dogAgent.jumpT = 0.001;
            }
          } else if (dogAgent.phase === 'play_bow') {
            dogAgent.headingY = shortestAngleLerp(dogAgent.headingY, 0.25, Math.min(1, dt * 6));
            const fade = Math.sin((dogAgent.phaseTimer / dogAgent.phaseDuration) * Math.PI);
            dogExtra.playBow = Math.min(1, fade * 1.35);
          } else if (dogAgent.phase === 'happy_hop') {
            dogAgent.headingY = shortestAngleLerp(dogAgent.headingY, 0.08, Math.min(1, dt * 7));
            if (dogAgent.jumpT > 0) {
              dogAgent.jumpT += dt / dogAgent.jumpDur;
              if (dogAgent.jumpT >= 1) {
                dogAgent.jumpT = 0.001;
              } else {
                dogExtra.jumpY = Math.sin(dogAgent.jumpT * Math.PI) * dogAgent.jumpPeak;
              }
            }
          } else {
            dogAgent.headingY = shortestAngleLerp(dogAgent.headingY, 0.14, Math.min(1, dt * 6));
            dogExtra.lookYaw = Math.sin(elapsed * 2.1) * 0.18;
          }
        }

        dogRig.root.position.set(dogAgent.x, 0, dogAgent.z);
        dogRig.root.rotation.y = dogAgent.headingY;

        // 2. Korean Shorthair (Right Zone: x in [0.55, 2.95])
        if (catTouchGreetRef.current > 0) {
          catTouchGreetRef.current = Math.max(0, catTouchGreetRef.current - dt);
          // Turn happily toward user, bat front paw cutely & bounce!
          catAgent.headingY = shortestAngleLerp(catAgent.headingY, -0.08, Math.min(1, dt * 10));
          catAgent.z = THREE.MathUtils.damp(catAgent.z, 0.55, 4, dt);
          if (catRollRef.current === 0) {
            catExtra.jumpY = Math.abs(Math.sin(elapsed * 5.8)) * 0.2;
            catExtra.pawBat = 0.78;
            catExtra.lookYaw = Math.sin(elapsed * 4.2) * 0.16;
          }
        } else {
          catAgent.phaseTimer += dt;
          if (catAgent.phaseTimer >= catAgent.phaseDuration) {
            pickNextCatPhase(catAgent.phase);
          }

          if (catAgent.phase === 'zigzag_dash') {
            const dx = catAgent.targetX - catAgent.x;
            const dz = catAgent.targetZ - catAgent.z;
            const dist = Math.hypot(dx, dz);
            if (dist < 0.16) {
              catAgent.dir *= -1;
              catAgent.targetX = catAgent.dir < 0 ? 0.62 : 2.85;
              catAgent.targetZ = (Math.random() - 0.3) * 0.95;
              catAgent.jumpT = 0.001;
              catAgent.jumpDur = 0.42;
              catAgent.jumpPeak = 0.34;
            } else {
              const speed = 1.9;
              catAgent.x += (dx / dist) * speed * dt;
              catAgent.z += (dz / dist) * speed * dt;
              const desiredYaw = Math.atan2(dx, dz);
              catAgent.headingY = shortestAngleLerp(catAgent.headingY, desiredYaw, Math.min(1, dt * 10));
              catGaitSpeed = 1.05;
            }
            if (catAgent.jumpT > 0) {
              catAgent.jumpT += dt / catAgent.jumpDur;
              if (catAgent.jumpT >= 1) catAgent.jumpT = 0;
              else catExtra.jumpY = Math.sin(catAgent.jumpT * Math.PI) * catAgent.jumpPeak;
            }
          } else if (catAgent.phase === 'crouch_stalk') {
            const targetYaw = catAgent.x > 1.7 ? -Math.PI * 0.45 : Math.PI * 0.45;
            catAgent.headingY = shortestAngleLerp(catAgent.headingY, targetYaw, Math.min(1, dt * 8));
            catExtra.pounceCrouch = 0.92;
          } else if (catAgent.phase === 'pounce_leap') {
            const dx = catAgent.targetX - catAgent.x;
            const dz = catAgent.targetZ - catAgent.z;
            const dist = Math.hypot(dx, dz);
            if (dist > 0.08) {
              const speed = 2.25;
              catAgent.x += (dx / dist) * speed * dt;
              catAgent.z += (dz / dist) * speed * dt;
              catAgent.headingY = shortestAngleLerp(catAgent.headingY, Math.atan2(dx, dz), Math.min(1, dt * 10));
              catGaitSpeed = 1.25;
            }
            if (catAgent.jumpT > 0) {
              catAgent.jumpT += dt / catAgent.jumpDur;
              if (catAgent.jumpT >= 1) catAgent.jumpT = 0;
              else catExtra.jumpY = Math.sin(catAgent.jumpT * Math.PI) * catAgent.jumpPeak;
            }
          } else if (catAgent.phase === 'paw_bat') {
            catAgent.headingY = shortestAngleLerp(catAgent.headingY, -0.22, Math.min(1, dt * 7));
            const fade = Math.sin((catAgent.phaseTimer / catAgent.phaseDuration) * Math.PI);
            catExtra.pawBat = Math.min(1, fade * 1.4);
          } else {
            catAgent.headingY = shortestAngleLerp(catAgent.headingY, -0.14, Math.min(1, dt * 6));
            catExtra.lookYaw = Math.sin(elapsed * 2.8) * 0.28;
          }
        }

        catRig.root.position.set(catAgent.x, 0, catAgent.z);
        catRig.root.rotation.y = catAgent.headingY;
      }

      // Barrel roll animations when touched
      if (dogRollRef.current > 0) {
        dogRollRef.current += dt * 0.95;
        if (dogRollRef.current >= 1) {
          dogRollRef.current = 0;
          dogMoodRef.current = 'happy';
          // Second joyful celebratory bark right after finishing roll!
          if (dogTouchGreetRef.current > 1.5) {
            petAudio.playVocal('golden_retriever', 'happy');
          }
        }
      }
      if (catRollRef.current > 0) {
        catRollRef.current += dt * 1.02;
        if (catRollRef.current >= 1) {
          catRollRef.current = 0;
          catMoodRef.current = 'happy';
          if (catTouchGreetRef.current > 1.5) {
            petAudio.playVocal('korean_shorthair', 'happy');
          }
        }
      }

      updatePetGrowthAndPose(
        dogRig,
        p,
        dogGaitSpeed,
        elapsed * 7.2,
        dogMoodRef.current,
        elapsed,
        dogRollRef.current,
        1.0,
        dogExtra,
      );
      updatePetGrowthAndPose(
        catRig,
        p,
        catGaitSpeed,
        elapsed * 8.4 + 1.3,
        catMoodRef.current,
        elapsed + 0.7,
        catRollRef.current,
        1.0,
        catExtra,
      );

      uiSyncAccumulator += dt;
      if (uiSyncAccumulator > 0.12) {
        uiSyncAccumulator = 0;
        setGrowthProgress(p);
        setBubbles((prev) => {
          const now = Date.now();
          const filtered = prev.filter((b) => b.expiresAt > now);
          return filtered.length === prev.length ? prev : filtered;
        });
      }

      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(renderer, tick, (id) => {
          frameId = id;
        });
      } else {
        frameId = requestAnimationFrame(tick);
      }
    };

    tick();

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('resize', handleResize);
      resizeObs?.disconnect();
      renderer.domElement.removeEventListener('pointerdown', handlePointerDown);
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  const stageText =
    growthProgress < 0.35
      ? '아기 시기 (유년기)'
      : growthProgress < 0.82
        ? '건강하게 성장하는 중'
        : '성견·성묘가 되어 신나게 뛰어놀아요!';

  return (
    <div className="relative w-full h-full overflow-hidden bg-sky-50 select-none">
      {/* Dedicated Three.js WebGL Mount */}
      <div ref={mountRef} className="absolute inset-0 w-full h-full cursor-pointer" />

      {/* Compact 3D stage HUD bar */}
      <div className="absolute top-0 left-0 right-0 z-20 flex items-center justify-between gap-3 px-4 py-3.5 pointer-events-none">
        <div className="pointer-events-auto bg-white/94 border border-stone-200/90 rounded-xl px-3.5 py-2 shadow-sm">
          <p className="text-xs font-semibold text-stone-800 tabular-nums">
            {stageText} · {Math.round(growthProgress * 100)}%
          </p>
          <p className="text-[11px] text-stone-600 mt-0.5">
            강아지나 고양이를 터치하면 반갑게 짖고 데구르르 굴러요
          </p>
        </div>

        <div className="flex items-center gap-2 pointer-events-auto">
          <button
            type="button"
            onClick={replayGrowth}
            className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-white/92 border border-stone-200 text-xs font-semibold text-stone-800 hover:bg-amber-50 transition-colors shadow-sm whitespace-nowrap shrink-0 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            성장 다시보기
          </button>
          <button
            type="button"
            onClick={() => {
              onToggleBgm();
            }}
            aria-label={bgmEnabled ? '배경음악 끄기' : '배경음악 켜기'}
            className={`flex items-center gap-1.5 px-3 py-2.5 rounded-xl border text-xs font-semibold transition-colors shadow-sm whitespace-nowrap shrink-0 cursor-pointer ${
              bgmEnabled && !muted
                ? 'bg-amber-50 border-amber-300 text-amber-900'
                : 'bg-white/92 border-stone-200 text-stone-500'
            }`}
          >
            <Music className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{bgmEnabled && !muted ? '배경음 ON' : '배경음 OFF'}</span>
          </button>
          <button
            type="button"
            onClick={onToggleMute}
            aria-label={muted ? '소리 켜기' : '소리 끄기'}
            className="p-2.5 rounded-xl bg-white/92 border border-stone-200 text-stone-800 hover:bg-stone-100 transition-colors shadow-sm cursor-pointer"
          >
            {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Korean Speech Bubbles projected over pets */}
      {bubbles.map((b) => (
        <div
          key={b.id}
          style={{left: `${b.screenX}px`, top: `${b.screenY}px`}}
          className="absolute z-20 pointer-events-none animate-bubble-pop"
        >
          <div className="relative max-w-[230px] rounded-2xl bg-white border border-amber-200 px-3.5 py-2.5 shadow-lg">
            <div className="text-[11px] font-semibold text-amber-700 mb-0.5">
              {b.species === 'golden_retriever' ? '골든 리트리버' : '코리안 숏헤어'} · {b.subLabel}
            </div>
            <div className="text-xs sm:text-sm font-medium text-stone-900 leading-snug">
              {b.text}
            </div>
            <div className="absolute left-1/2 -bottom-2 -translate-x-1/2 w-3.5 h-3.5 bg-white border-r border-b border-amber-200 rotate-45" />
          </div>
        </div>
      ))}

      {/* Bottom Left & Right Adoption Buttons (Req 3) */}
      <div className="absolute bottom-5 left-0 right-0 z-20 px-4 sm:px-8 flex items-end justify-between gap-3 pointer-events-none">
        <button
          type="button"
          onClick={() => {
            petAudio.startBgm();
            petAudio.playVocal('golden_retriever', 'happy');
            onAdopt('golden_retriever');
          }}
          className="pointer-events-auto flex-1 sm:flex-none sm:min-w-[240px] py-3.5 px-5 rounded-2xl bg-amber-600 hover:bg-amber-700 active:scale-[0.98] text-white font-display font-bold text-sm sm:text-base shadow-lg transition-all cursor-pointer flex flex-col items-center sm:items-start"
        >
          <span className="whitespace-nowrap">골든리트리버 분양하기</span>
          <span className="text-[11px] font-normal text-amber-100 mt-0.5">
            따뜻하고 다정한 아기 리트리버 키우기
          </span>
        </button>

        <button
          type="button"
          onClick={() => {
            petAudio.startBgm();
            petAudio.playVocal('korean_shorthair', 'happy');
            onAdopt('korean_shorthair');
          }}
          className="pointer-events-auto flex-1 sm:flex-none sm:min-w-[240px] py-3.5 px-5 rounded-2xl bg-stone-900 hover:bg-stone-800 active:scale-[0.98] text-white font-display font-bold text-sm sm:text-base shadow-lg transition-all cursor-pointer flex flex-col items-center sm:items-end"
        >
          <span className="whitespace-nowrap">코리안숏헤어 분양하기</span>
          <span className="text-[11px] font-normal text-stone-300 mt-0.5">
            영리하고 귀여운 아기 코숏 키우기
          </span>
        </button>
      </div>
    </div>
  );
};
