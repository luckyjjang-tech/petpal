import React, {useState} from 'react';
import {ArrowRight, CheckCircle2, Heart} from 'lucide-react';
import {PetSpecies} from '../types/pet';

interface WebsiteSectionsProps {
  bonusScore: number;
  donationCount: number;
  onAdopt: (species: PetSpecies) => void;
  onOpenDonation: () => void;
  onGoToCare: () => void;
}

interface ResilientPhotoProps {
  src: string;
  alt: string;
  fallbackTitle: string;
  aspectClass: string;
}

const ResilientPhoto: React.FC<ResilientPhotoProps> = ({
  src,
  alt,
  fallbackTitle,
  aspectClass,
}) => {
  const [failed, setFailed] = useState(false);

  if (failed) {
    return (
      <div
        className={`${aspectClass} w-full bg-gradient-to-br from-amber-100 via-stone-100 to-sky-100 flex flex-col items-center justify-center p-6 text-center`}
      >
        <span className="font-display font-bold text-stone-800 text-base">
          {fallbackTitle}
        </span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={`${aspectClass} w-full object-cover`}
    />
  );
};

export const WebsiteSections: React.FC<WebsiteSectionsProps> = ({
  bonusScore,
  donationCount,
  onAdopt,
  onOpenDonation,
  onGoToCare,
}) => {
  const [email, setEmail] = useState('');
  const [preferredSpecies, setPreferredSpecies] = useState<'golden_retriever' | 'korean_shorthair' | 'both'>('both');
  const [formError, setFormError] = useState<string | null>(null);
  const [subscribedEmail, setSubscribedEmail] = useState<string | null>(null);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = email.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed)) {
      setFormError('올바른 이메일 주소를 입력해 주세요.');
      return;
    }
    setFormError(null);
    setSubscribedEmail(trimmed);
    setEmail('');
  };

  const potentialKrw = Math.max(1000, Math.floor(bonusScore / 100) * 1000);

  return (
    <>
      {/* Section 01: Breed Profiles & Growth Timeline */}
      <section
        id="breeds"
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20 border-t border-stone-200"
      >
        <div className="max-w-2xl mb-10">
          <p className="text-xs font-semibold text-amber-700 tracking-wide">
            01. 품종 가이드 및 성장 과정
          </p>
          <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-stone-900 mt-2 text-balance">
            실제 반려동물의 성장 주기와 성격을 3D로 만나보세요
          </h2>
          <p className="text-sm sm:text-base text-stone-600 mt-3 leading-relaxed">
            생후 2개월 어린 시절부터 18개월 건강한 성견·성묘가 되기까지, 정해진 식사 시간과
            산책 약속을 지키면 활력이 넘치고 윤기 있는 털을 가진 모습으로 자랍니다.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-stretch">
          {/* Golden Retriever Card */}
          <article className="bg-white rounded-3xl border border-stone-200 overflow-hidden flex flex-col">
            <ResilientPhoto
              src="/src/assets/images/breed_golden_retriever_1795187219081.jpg"
              alt="꽃밭 옆에 앉아 반갑게 웃고 있는 골든 리트리버"
              fallbackTitle="골든 리트리버 (Golden Retriever)"
              aspectClass="aspect-[4/3]"
            />
            <div className="p-6 sm:p-8 flex-1 flex flex-col justify-between gap-6">
              <div>
                <div className="text-xs text-stone-500 flex flex-wrap items-center gap-2">
                  <span>골든 리트리버</span>
                  <span aria-hidden="true">·</span>
                  <span>유년기 2개월 → 성견 18개월</span>
                  <span aria-hidden="true">·</span>
                  <span>활발한 산책 동반자</span>
                </div>
                <h3 className="font-display text-xl sm:text-2xl font-bold text-stone-900 mt-2">
                  다정하고 씩씩한 골든 리트리버
                </h3>
                <p className="text-sm text-stone-600 mt-3 leading-relaxed">
                  사람을 무척 좋아해 터치하면 반갑게 짖고 앞발을 낮춰 놀이 자세를 취합니다.
                  정시 식사(1일 3회)와 야외 산책을 챙겨주면 튼튼한 성견으로 빠르게 성장합니다.
                </p>
                <dl className="grid grid-cols-3 gap-4 mt-6 pt-5 border-t border-stone-100 text-xs">
                  <div>
                    <dt className="text-stone-500">대표 동작</dt>
                    <dd className="font-semibold text-stone-900 mt-1">구보 · 놀이 인사</dd>
                  </div>
                  <div>
                    <dt className="text-stone-500">의사표현</dt>
                    <dd className="font-semibold text-stone-900 mt-1">4가지 짖음 반응</dd>
                  </div>
                  <div>
                    <dt className="text-stone-500">성장 보상</dt>
                    <dd className="font-semibold text-stone-900 mt-1 tabular-nums">100점 선물</dd>
                  </div>
                </dl>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => onAdopt('golden_retriever')}
                  className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-sm font-bold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <span>골든리트리버 분양하기</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </article>

          {/* Korean Shorthair Card */}
          <article className="bg-white rounded-3xl border border-stone-200 overflow-hidden flex flex-col">
            <ResilientPhoto
              src="/src/assets/images/breed_korean_shorthair_1795187218641.jpg"
              alt="원목 테라스 위에서 꽃밭을 배경으로 앉아 있는 코리안 숏헤어 치즈 태비 고양이"
              fallbackTitle="코리안 숏헤어 (Korean Shorthair)"
              aspectClass="aspect-[4/3]"
            />
            <div className="p-6 sm:p-8 flex-1 flex flex-col justify-between gap-6">
              <div>
                <div className="text-xs text-stone-500 flex flex-wrap items-center gap-2">
                  <span>코리안 숏헤어</span>
                  <span aria-hidden="true">·</span>
                  <span>아기묘 2개월 → 성묘 18개월</span>
                  <span aria-hidden="true">·</span>
                  <span>영리한 애교쟁이</span>
                </div>
                <h3 className="font-display text-xl sm:text-2xl font-bold text-stone-900 mt-2">
                  민첩하고 사랑스러운 코리안 숏헤어
                </h3>
                <p className="text-sm text-stone-600 mt-3 leading-relaxed">
                  몸을 낮추어 겨누다 높게 점프하고 앞발로 톡톡 장난치는 고양이 특유의 움직임을
                  구현했습니다. 손가락으로 쓰다듬으면 그르릉·야옹 소리와 함께 데구르르 구릅니다.
                </p>
                <dl className="grid grid-cols-3 gap-4 mt-6 pt-5 border-t border-stone-100 text-xs">
                  <div>
                    <dt className="text-stone-500">대표 동작</dt>
                    <dd className="font-semibold text-stone-900 mt-1">점프 · 냥냥펀치</dd>
                  </div>
                  <div>
                    <dt className="text-stone-500">의사표현</dt>
                    <dd className="font-semibold text-stone-900 mt-1">4가지 울음 반응</dd>
                  </div>
                  <div>
                    <dt className="text-stone-500">성장 보상</dt>
                    <dd className="font-semibold text-stone-900 mt-1 tabular-nums">의상 · 목걸이</dd>
                  </div>
                </dl>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => onAdopt('korean_shorthair')}
                  className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-stone-900 hover:bg-stone-800 text-white text-sm font-bold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <span>코리안숏헤어 분양하기</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </article>
        </div>
      </section>

      {/* Section 02: Care, Google Maps 3D Walk, Gift Box Wardrobe */}
      <section
        id="care-guide"
        className="bg-white border-t border-stone-200 py-16 sm:py-20"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch mb-12">
            <div className="lg:col-span-7 rounded-3xl overflow-hidden border border-stone-200">
              <ResilientPhoto
                src="/src/assets/images/care_walk_lifestyle_1795187220106.jpg"
                alt="화사한 꽃길 산책로를 따라 반려견과 함께 걷는 산책 풍경"
                fallbackTitle="화사한 꽃길 산책과 돌봄 경험"
                aspectClass="aspect-[16/9] lg:h-full"
              />
            </div>
            <div className="lg:col-span-5 flex flex-col justify-center">
              <p className="text-xs font-semibold text-amber-700 tracking-wide">
                02. 돌봄 및 실감 산책 시스템
              </p>
              <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-stone-900 mt-2 text-balance">
                매일의 식사와 구글 지도 3D 산책이 보너스 점수로 이어집니다
              </h2>
              <p className="text-sm sm:text-base text-stone-600 mt-3 leading-relaxed">
                분양 후 돌봄 화면에서 <strong>세팅</strong>을 눌러 1일 3회 식사 시간과 산책 시간을
                예약하세요. <strong>시작하기</strong>를 누르면 기본 10점에서 실시간 보너스 점수가
                누적됩니다.
              </p>
              <div className="mt-6">
                <button
                  type="button"
                  onClick={onGoToCare}
                  className="inline-flex items-center gap-2 px-5 py-3 rounded-xl border border-stone-300 bg-stone-50 hover:bg-stone-100 text-stone-900 text-sm font-bold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <span>내 반려동물 돌봄 방 열기</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* 4-Column Editorial System Breakdown */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="p-6 rounded-2xl bg-stone-50 border border-stone-200">
              <div className="text-xs font-semibold text-amber-700 tabular-nums">
                01. 정시 식사 · 산책 세팅
              </div>
              <h3 className="font-display text-base font-bold text-stone-900 mt-2">
                건강한 성장 타임라인
              </h3>
              <p className="text-xs sm:text-sm text-stone-600 mt-2 leading-relaxed tabular-nums">
                1일 3회 식사 시간을 지키면 +1점, 산책 약속을 지키면 +2점이 적립됩니다. 제때 밥을
                거르면 활력이 줄어들어 성장이 느려집니다.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-stone-50 border border-stone-200">
              <div className="text-xs font-semibold text-amber-700 tabular-nums">
                02. 100점 선물상자 &amp; 옷장
              </div>
              <h3 className="font-display text-base font-bold text-stone-900 mt-2">
                폭죽 축하와 손가락 입히기
              </h3>
              <p className="text-xs sm:text-sm text-stone-600 mt-2 leading-relaxed">
                보너스 100점을 달성하면 하늘에서 선물상자가 내려옵니다. 터치하면 폭죽·축하음악과
                함께 의상이 열리며 옷장에 보관하거나 직접 끌어 입힐 수 있습니다.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-stone-50 border border-stone-200">
              <div className="text-xs font-semibold text-amber-700 tabular-nums">
                03. 구글 지도 입체 산책
              </div>
              <h3 className="font-display text-base font-bold text-stone-900 mt-2">
                걸음 속도에 맞춘 3D 동행
              </h3>
              <p className="text-xs sm:text-sm text-stone-600 mt-2 leading-relaxed">
                산책 모드를 켜면 3D 구글 지도가 열리고 GPS 거리 및 보행 속도에 맞춰 강아지와 고양이가
                길 위를 걷거나 신나게 뜁니다.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-stone-50 border border-stone-200">
              <div className="text-xs font-semibold text-amber-700 tabular-nums">
                04. 4가지 한글 의사표현
              </div>
              <h3 className="font-display text-base font-bold text-stone-900 mt-2">
                짖음과 말풍선 감정 소통
              </h3>
              <p className="text-xs sm:text-sm text-stone-600 mt-2 leading-relaxed">
                배고픔, 신남, 배변 신호, 하고 싶은 것 4가지 상태를 고유한 짖는·우는 소리와 3D 포즈,
                한글 말풍선으로 정확히 알려줍니다.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Section 03: Sponsorship Campaign & Newsletter Contact */}
      <section
        id="sponsorship"
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20 border-t border-stone-200"
      >
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          <div className="lg:col-span-6 p-7 sm:p-9 rounded-3xl bg-stone-900 text-white flex flex-col justify-between gap-6">
            <div>
              <p className="text-xs font-semibold text-amber-300">
                03. 착한 반려동물 후원 연결
              </p>
              <h2 className="font-display text-2xl sm:text-3xl font-bold tracking-tight mt-2 text-balance">
                보너스 100점당 1,000원씩 따뜻한 후원에 참여하세요
              </h2>
              <p className="text-sm text-stone-300 mt-3 leading-relaxed">
                열심히 돌보며 쌓은 보너스 점수로 후원 결제를 진행하면 보호소 동물 지원과 함께
                더 화려한 로열 망토, 진주 하트 목걸이, 봄꽃 화관 등 특별 의상을 즉시 해금할 수 있습니다.
              </p>
              <div className="grid grid-cols-3 gap-4 mt-6 pt-5 border-t border-stone-800 text-xs tabular-nums">
                <div>
                  <div className="text-stone-400">현재 보너스</div>
                  <div className="font-mono-num text-lg font-bold text-white mt-1">
                    {bonusScore}점
                  </div>
                </div>
                <div>
                  <div className="text-stone-400">후원 환산액</div>
                  <div className="font-mono-num text-lg font-bold text-amber-300 mt-1">
                    {potentialKrw.toLocaleString()}원
                  </div>
                </div>
                <div>
                  <div className="text-stone-400">누적 참여</div>
                  <div className="font-mono-num text-lg font-bold text-white mt-1">
                    {donationCount}회
                  </div>
                </div>
              </div>
            </div>

            <div>
              <button
                type="button"
                onClick={onOpenDonation}
                className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-sm font-bold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Heart className="w-4 h-4" />
                <span>신용카드 후원하기</span>
              </button>
            </div>
          </div>

          <div className="lg:col-span-6 p-7 sm:p-9 rounded-3xl bg-white border border-stone-200 flex flex-col justify-between">
            <div>
              <p className="text-xs font-semibold text-amber-700">
                입양·케어 소식 신청
              </p>
              <h3 className="font-display text-xl sm:text-2xl font-bold text-stone-900 mt-2">
                새로운 의상 컬렉션과 반려동물 돌봄 가이드를 받아보세요
              </h3>
              <p className="text-sm text-stone-600 mt-2 leading-relaxed">
                관심 있는 품종과 이메일을 남기시면 계절별 의상 업데이트 및 건강한 반려생활 팁을 보내드립니다.
              </p>
            </div>

            {subscribedEmail ? (
              <div className="mt-6 p-5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div className="text-sm">
                  <div className="font-bold">소식 신청이 완료되었습니다</div>
                  <p className="text-xs text-emerald-800 mt-1">
                    {subscribedEmail} 주소로 선택하신 품종의 새 소식을 안내해 드리겠습니다.
                  </p>
                  <button
                    type="button"
                    onClick={() => setSubscribedEmail(null)}
                    className="mt-2 text-xs font-semibold underline cursor-pointer"
                  >
                    다른 이메일로 다시 신청
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="mt-6 space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label
                      htmlFor="newsletter-email"
                      className="block text-xs font-semibold text-stone-700 mb-1"
                    >
                      이메일 주소
                    </label>
                    <input
                      id="newsletter-email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="name@example.com"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-sm text-stone-900 focus:outline-none focus:border-stone-900"
                    />
                  </div>
                  <div>
                    <label
                      htmlFor="newsletter-species"
                      className="block text-xs font-semibold text-stone-700 mb-1"
                    >
                      관심 반려동물
                    </label>
                    <select
                      id="newsletter-species"
                      value={preferredSpecies}
                      onChange={(e) =>
                        setPreferredSpecies(
                          e.target.value as 'golden_retriever' | 'korean_shorthair' | 'both',
                        )
                      }
                      className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-sm text-stone-900 bg-white focus:outline-none focus:border-stone-900"
                    >
                      <option value="both">골든 리트리버 &amp; 코리안 숏헤어</option>
                      <option value="golden_retriever">골든 리트리버</option>
                      <option value="korean_shorthair">코리안 숏헤어</option>
                    </select>
                  </div>
                </div>
                {formError && (
                  <p className="text-xs font-medium text-rose-600">{formError}</p>
                )}
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-white text-sm font-bold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  안내 소식 신청하기
                </button>
              </form>
            )}
          </div>
        </div>
      </section>

      {/* Quiet Footer */}
      <footer className="border-t border-stone-200 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-500">
          <div className="font-display font-bold text-stone-900 text-sm">
            포근한 3D 반려생활
          </div>
          <nav className="flex flex-wrap items-center gap-6">
            <a href="#stage" className="hover:text-stone-900 transition-colors whitespace-nowrap">
              3D 분양관
            </a>
            <a href="#breeds" className="hover:text-stone-900 transition-colors whitespace-nowrap">
              품종 소개
            </a>
            <a href="#care-guide" className="hover:text-stone-900 transition-colors whitespace-nowrap">
              케어 시스템
            </a>
            <a href="#sponsorship" className="hover:text-stone-900 transition-colors whitespace-nowrap">
              후원 안내
            </a>
          </nav>
          <div>© 2026 포근한 3D 반려생활. All rights reserved.</div>
        </div>
      </footer>
    </>
  );
};
