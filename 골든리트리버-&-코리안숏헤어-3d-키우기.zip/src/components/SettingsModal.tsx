import React, {useState} from 'react';
import {Clock, Footprints, Utensils, X} from 'lucide-react';
import {CareSchedule} from '../types/pet';

interface SettingsModalProps {
  schedule: CareSchedule;
  timeScaleMode: 'realtime' | 'fast';
  onSave: (newSchedule: CareSchedule, timeScaleMode: 'realtime' | 'fast') => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  schedule,
  timeScaleMode,
  onSave,
  onClose,
}) => {
  const [form, setForm] = useState<CareSchedule>(schedule);
  const [scale, setScale] = useState<'realtime' | 'fast'>(timeScaleMode);

  const alignNowForTest = () => {
    const now = new Date();
    const hh = String(now.getHours()).padStart(2, '0');
    const mm = String(now.getMinutes()).padStart(2, '0');
    const nowStr = `${hh}:${mm}`;
    setForm((prev) => ({
      ...prev,
      lunchMeal: nowStr,
      walkTime: nowStr,
    }));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/60 p-4">
      <div className="w-full max-w-lg rounded-3xl bg-white border border-stone-200 shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-stone-100">
          <div>
            <h2 className="font-display text-lg font-bold text-stone-900">
              식사 및 산책 시간 세팅
            </h2>
            <p className="text-xs text-stone-500 mt-0.5">
              1일 3회 식사와 산책 시간을 정하고 보너스 점수를 획득하세요
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="닫기"
            className="p-2 rounded-xl text-stone-500 hover:bg-stone-100 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          {/* 1일 3회 식사 시간 */}
          <section className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm font-bold text-stone-800">
                <Utensils className="w-4 h-4 text-amber-600" />
                <span>밥 먹이는 시간 (1일 3회)</span>
              </div>
              <span className="text-xs font-semibold text-amber-700">
                시간 준수 시 +1점 보너스
              </span>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <label className="block rounded-2xl border border-stone-200 bg-stone-50 p-3">
                <span className="block text-[11px] font-medium text-stone-500 mb-1">
                  아침 (1회)
                </span>
                <input
                  type="time"
                  value={form.morningMeal}
                  onChange={(e) => setForm({...form, morningMeal: e.target.value})}
                  className="w-full bg-transparent text-sm font-mono-num font-semibold text-stone-900 focus:outline-none"
                />
              </label>
              <label className="block rounded-2xl border border-stone-200 bg-stone-50 p-3">
                <span className="block text-[11px] font-medium text-stone-500 mb-1">
                  점심 (2회)
                </span>
                <input
                  type="time"
                  value={form.lunchMeal}
                  onChange={(e) => setForm({...form, lunchMeal: e.target.value})}
                  className="w-full bg-transparent text-sm font-mono-num font-semibold text-stone-900 focus:outline-none"
                />
              </label>
              <label className="block rounded-2xl border border-stone-200 bg-stone-50 p-3">
                <span className="block text-[11px] font-medium text-stone-500 mb-1">
                  저녁 (3회)
                </span>
                <input
                  type="time"
                  value={form.dinnerMeal}
                  onChange={(e) => setForm({...form, dinnerMeal: e.target.value})}
                  className="w-full bg-transparent text-sm font-mono-num font-semibold text-stone-900 focus:outline-none"
                />
              </label>
            </div>
          </section>

          {/* 산책 시간 */}
          <section className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm font-bold text-stone-800">
                <Footprints className="w-4 h-4 text-emerald-600" />
                <span>산책하는 시간 (1일 1회)</span>
              </div>
              <span className="text-xs font-semibold text-emerald-700">
                시간 준수 시 +2점 보너스
              </span>
            </div>
            <label className="block rounded-2xl border border-stone-200 bg-stone-50 p-3.5">
              <span className="block text-[11px] font-medium text-stone-500 mb-1">
                목표 산책 시각
              </span>
              <input
                type="time"
                value={form.walkTime}
                onChange={(e) => setForm({...form, walkTime: e.target.value})}
                className="w-full bg-transparent text-sm font-mono-num font-semibold text-stone-900 focus:outline-none"
              />
            </label>
          </section>

          {/* 성장 시간 흐름 설정 */}
          <section className="space-y-2.5">
            <div className="flex items-center gap-2 text-sm font-bold text-stone-800">
              <Clock className="w-4 h-4 text-sky-600" />
              <span>성장 시간 모드</span>
            </div>
            <div className="grid grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => setScale('realtime')}
                className={`p-3 rounded-2xl border text-left transition-colors cursor-pointer ${
                  scale === 'realtime'
                    ? 'border-stone-900 bg-stone-900 text-white'
                    : 'border-stone-200 bg-stone-50 text-stone-800 hover:bg-stone-100'
                }`}
              >
                <div className="text-xs font-bold">실제 시간 성장</div>
                <div
                  className={`text-[11px] mt-0.5 ${
                    scale === 'realtime' ? 'text-stone-300' : 'text-stone-500'
                  }`}
                >
                  실제 개·고양이와 같은 속도로 성숙
                </div>
              </button>
              <button
                type="button"
                onClick={() => setScale('fast')}
                className={`p-3 rounded-2xl border text-left transition-colors cursor-pointer ${
                  scale === 'fast'
                    ? 'border-amber-600 bg-amber-600 text-white'
                    : 'border-stone-200 bg-stone-50 text-stone-800 hover:bg-stone-100'
                }`}
              >
                <div className="text-xs font-bold">빠른 체험 배속</div>
                <div
                  className={`text-[11px] mt-0.5 ${
                    scale === 'fast' ? 'text-amber-100' : 'text-stone-500'
                  }`}
                >
                  식사·성장·배변 변화를 빠르게 확인
                </div>
              </button>
            </div>
          </section>

          {/* Convenience button to sync one meal & walk to current minute for immediate bonus check */}
          <div className="flex items-center justify-between rounded-2xl bg-amber-50 border border-amber-200 px-4 py-3">
            <div className="text-xs text-amber-950">
              지금 바로 보너스 시간(+1점/+2점)을 테스트하고 싶다면?
            </div>
            <button
              type="button"
              onClick={alignNowForTest}
              className="px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold whitespace-nowrap shrink-0 cursor-pointer"
            >
              현재 시각 맞추기
            </button>
          </div>
        </div>

        <div className="flex items-center justify-end gap-2.5 px-6 py-4 border-t border-stone-100 bg-stone-50">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl border border-stone-200 bg-white text-sm font-semibold text-stone-700 hover:bg-stone-100 cursor-pointer"
          >
            취소
          </button>
          <button
            type="button"
            onClick={() => onSave(form, scale)}
            className="px-5 py-2.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-white text-sm font-semibold cursor-pointer"
          >
            설정 저장하기
          </button>
        </div>
      </div>
    </div>
  );
};
