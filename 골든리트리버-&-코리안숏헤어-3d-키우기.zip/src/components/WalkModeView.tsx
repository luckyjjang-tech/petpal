import React, {useEffect, useRef, useState} from 'react';
import * as THREE from 'three';
import {
  APIProvider,
  APILoadingStatus,
  useApiLoadingStatus,
} from '@vis.gl/react-google-maps';
import {Map3D, MapMode} from '@vis.gl/react-google-maps/3d';
import {ArrowLeft, CheckCircle, Footprints, MapPin, Navigation} from 'lucide-react';
import {petAudio} from '../audio/petAudio';
import {
  afterDraw,
  createConfiguredRenderer,
  detectSoftwareGl,
  setupStudioLighting,
} from '../three/environmentScene';
import {createProceduralTextureSet} from '../three/furTextures';
import {
  applyWardrobeToPet,
  createGoldenRetrieverRig,
  createKoreanShorthairRig,
  updatePetGrowthAndPose,
} from '../three/petModels';
import {PET_DISPLAY_INFO, PetSpecies} from '../types/pet';

interface WalkModeViewProps {
  species: PetSpecies;
  maturity: number;
  healthFactor: number;
  equippedClothesId: string | null;
  equippedAccessoryId: string | null;
  onFinishWalk: (distanceMeters: number) => void;
  onBack: () => void;
}

const DEFAULT_WALK_ROUTE: Array<{lat: number; lng: number; name: string}> = [
  {lat: 37.5284, lng: 126.9336, name: '여의도 한강공원 산책로'},
  {lat: 37.5512, lng: 126.9882, name: '남산 둘레길 숲속 산책로'},
  {lat: 37.5444, lng: 127.0374, name: '서울숲 공원 산책길'},
];

function haversineMeters(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number,
): number {
  const R = 6371000;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) *
      Math.cos(toRad(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

const MapsStatusMonitor: React.FC<{
  onStatusFail: () => void;
}> = ({onStatusFail}) => {
  const status = useApiLoadingStatus();
  useEffect(() => {
    if (
      status === APILoadingStatus.FAILED ||
      status === APILoadingStatus.AUTH_FAILURE
    ) {
      window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
      onStatusFail();
    }
  }, [status, onStatusFail]);
  return null;
};

export const WalkModeView: React.FC<WalkModeViewProps> = ({
  species,
  maturity,
  healthFactor,
  equippedClothesId,
  equippedAccessoryId,
  onFinishWalk,
  onBack,
}) => {
  const mapsApiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '';
  const [mapFailed, setMapFailed] = useState(!mapsApiKey);
  const [routeIdx, setRouteIdx] = useState(0);
  const [cameraCenter, setCameraCenter] = useState<{
    lat: number;
    lng: number;
    altitude: number;
  }>({
    lat: DEFAULT_WALK_ROUTE[0].lat,
    lng: DEFAULT_WALK_ROUTE[0].lng,
    altitude: 38,
  });
  const [heading, setHeading] = useState(32);

  // Walking telemetry synced between user pace & 3D pet gait
  const [paceMode, setPaceMode] = useState<'stop' | 'walk' | 'run'>('walk');
  const [gpsActive, setGpsActive] = useState(false);
  const [distanceMeters, setDistanceMeters] = useState(0);
  const [currentSpeedKmh, setCurrentSpeedKmh] = useState(3.8);

  const paceRef = useRef<'stop' | 'walk' | 'run'>('walk');
  const speedKmhRef = useRef(3.8);
  const distanceRef = useRef(0);
  const lastGpsRef = useRef<{lat: number; lng: number; time: number} | null>(null);
  const petCanvasRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    paceRef.current = paceMode;
    const targetSpeed = paceMode === 'stop' ? 0 : paceMode === 'walk' ? 3.8 : 7.6;
    speedKmhRef.current = targetSpeed;
    setCurrentSpeedKmh(targetSpeed);
  }, [paceMode]);

  // Switch scenic Google Maps 3D route
  const selectRoute = (idx: number) => {
    setRouteIdx(idx);
    setCameraCenter({
      lat: DEFAULT_WALK_ROUTE[idx].lat,
      lng: DEFAULT_WALK_ROUTE[idx].lng,
      altitude: 38,
    });
  };

  // Real smartphone GPS tracking (matches pet speed to user's actual walking distance)
  useEffect(() => {
    if (!gpsActive || !navigator.geolocation) return;
    const watchId = navigator.geolocation.watchPosition(
      (pos) => {
        const {latitude, longitude} = pos.coords;
        const now = Date.now();
        const prev = lastGpsRef.current;
        if (prev) {
          const deltaM = haversineMeters(prev.lat, prev.lng, latitude, longitude);
          const dtSec = Math.max(0.5, (now - prev.time) / 1000);
          if (deltaM >= 0.8 && deltaM < 120) {
            distanceRef.current += deltaM;
            setDistanceMeters(distanceRef.current);
            const kmh = (deltaM / dtSec) * 3.6;
            speedKmhRef.current = kmh;
            setCurrentSpeedKmh(Number(kmh.toFixed(1)));
            setPaceMode(kmh > 5.4 ? 'run' : kmh > 0.6 ? 'walk' : 'stop');
          }
        }
        lastGpsRef.current = {lat: latitude, lng: longitude, time: now};
        setCameraCenter({lat: latitude, lng: longitude, altitude: 32});
      },
      () => {
        setGpsActive(false);
      },
      {enableHighAccuracy: true, maximumAge: 1000, timeout: 8000},
    );
    return () => navigator.geolocation.clearWatch(watchId);
  }, [gpsActive]);

  // Advance distance & gently glide Google Maps 3D camera along the path when walking/running
  useEffect(() => {
    const timer = window.setInterval(() => {
      if (gpsActive) return;
      const kmh = speedKmhRef.current;
      if (kmh <= 0.05) return;

      const mps = kmh / 3.6;
      const stepMeters = mps * 0.25;
      distanceRef.current += stepMeters;
      setDistanceMeters(distanceRef.current);

      // Move 3D map coordinates forward along current heading
      const rad = (heading * Math.PI) / 180;
      const dLat = (stepMeters * Math.cos(rad)) / 111320;
      const dLng = (stepMeters * Math.sin(rad)) / 88000;
      setCameraCenter((prev) => ({
        lat: prev.lat + dLat,
        lng: prev.lng + dLng,
        altitude: prev.altitude,
      }));
    }, 250);
    return () => clearInterval(timer);
  }, [gpsActive, heading]);

  // Transparent Three.js 3D Pet Overlay walking & running happily over the Google Maps 3D road
  useEffect(() => {
    const container = petCanvasRef.current;
    if (!container) return;

    const isSoftwareGl = detectSoftwareGl();
    const renderer = createConfiguredRenderer(container, isSoftwareGl, true);
    const scene = new THREE.Scene();
    setupStudioLighting(scene, renderer, null);

    const camera = new THREE.PerspectiveCamera(
      40,
      (container.clientWidth || window.innerWidth) /
        (container.clientHeight || window.innerHeight),
      0.1,
      50,
    );
    camera.position.set(0, 1.35, 3.35);
    camera.lookAt(0, 0.35, -1.2);

    const textures = createProceduralTextureSet(
      renderer.capabilities.getMaxAnisotropy(),
    );
    const rig =
      species === 'golden_retriever'
        ? createGoldenRetrieverRig(textures, isSoftwareGl)
        : createKoreanShorthairRig(textures, isSoftwareGl);
    applyWardrobeToPet(rig, equippedClothesId, equippedAccessoryId);
    // Face slightly away/forward down the Google Maps 3D path while glancing cheerfully back at user
    rig.root.position.set(0, -0.45, 0.4);
    rig.root.rotation.y = Math.PI * 0.88;
    scene.add(rig.root);

    // Subtle fallback street ribbon visible only if Google Map3D fails to render
    const fallbackRoad = new THREE.Mesh(
      new THREE.PlaneGeometry(3.2, 40),
      new THREE.MeshStandardMaterial({color: 0x6b7280, roughness: 0.9}),
    );
    fallbackRoad.rotation.x = -Math.PI / 2;
    fallbackRoad.position.y = -0.46;
    fallbackRoad.visible = mapFailed;
    scene.add(fallbackRoad);

    const handleResize = () => {
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || window.innerHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    const clock = new THREE.Clock();
    let frameId = 0;
    let disposed = false;
    let gaitPhase = 0;

    const tick = () => {
      if (disposed) return;
      const dt = Math.min(clock.getDelta(), 0.1);
      const elapsed = clock.getElapsedTime();

      fallbackRoad.visible = mapFailed;

      const kmh = speedKmhRef.current;
      const gaitSpeed = kmh <= 0.1 ? 0 : kmh > 5.2 ? 1.2 : 0.65;
      gaitPhase += dt * (gaitSpeed > 0.9 ? 11.5 : gaitSpeed > 0.1 ? 6.5 : 0);

      // Happy bounding & turning head back toward owner during walk
      rig.root.position.x = Math.sin(elapsed * 1.4) * 0.12;
      updatePetGrowthAndPose(
        rig,
        maturity,
        gaitSpeed,
        gaitPhase,
        'walking',
        elapsed,
        0,
        healthFactor,
      );
      if (gaitSpeed > 0) {
        rig.headGroup.rotation.y = Math.sin(elapsed * 2.2) * 0.25;
      }

      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(renderer, tick, (id) => {
          frameId = id;
        });
      } else {
        frameId = requestAnimationFrame(tick);
      }
    };
    tick();

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [species, maturity, healthFactor, equippedClothesId, equippedAccessoryId, mapFailed]);

  const handleStepTap = () => {
    distanceRef.current += 12;
    setDistanceMeters(distanceRef.current);
    petAudio.playVocal(species, 'walking');
    const rad = (heading * Math.PI) / 180;
    setCameraCenter((prev) => ({
      lat: prev.lat + (12 * Math.cos(rad)) / 111320,
      lng: prev.lng + (12 * Math.sin(rad)) / 88000,
      altitude: prev.altitude,
    }));
  };

  const stepsCount = Math.round(distanceMeters / 0.72);
  const petInfo = PET_DISPLAY_INFO[species];

  return (
    <div className="relative w-full h-full overflow-hidden bg-emerald-950 select-none">
      {/* Google Maps Photorealistic 3D Layer */}
      {mapsApiKey && !mapFailed ? (
        <div className="absolute inset-0 w-full h-full">
          <APIProvider apiKey={mapsApiKey} libraries={['maps3d', 'marker']}>
            <MapsStatusMonitor onStatusFail={() => setMapFailed(true)} />
            <Map3D
              internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
              mode={MapMode.HYBRID}
              center={cameraCenter}
              range={135}
              tilt={72}
              heading={heading}
              roll={0}
              gestureHandling="GREEDY"
              style={{width: '100%', height: '100%'}}
              onError={() => setMapFailed(true)}
            />
          </APIProvider>
        </div>
      ) : (
        <div
          className="absolute inset-0 w-full h-full"
          style={{
            background:
              'linear-gradient(180deg, #bae6fd 0%, #e0f2fe 45%, #86efac 46%, #4d7c0f 100%)',
          }}
        />
      )}

      {/* Transparent Three.js 3D Pet Overlay running synchronously on the Google Maps path */}
      <div
        ref={petCanvasRef}
        className="absolute inset-0 w-full h-full pointer-events-none z-10"
      />

      {/* Top Walk Telemetry Bar */}
      <header className="absolute top-0 left-0 right-0 z-20 p-4 flex flex-wrap items-center justify-between gap-3 pointer-events-none">
        <div className="pointer-events-auto flex items-center gap-3 bg-white/95 border border-stone-200 rounded-2xl px-4 py-2.5 shadow-md">
          <button
            type="button"
            onClick={onBack}
            className="p-1.5 rounded-lg hover:bg-stone-100 text-stone-700 cursor-pointer"
            aria-label="돌아가기"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="text-sm font-bold text-stone-900">
              {petInfo.koreanName} 구글지도 3D 산책
            </div>
            <div className="text-[11px] text-stone-500">
              {DEFAULT_WALK_ROUTE[routeIdx].name} · 보행 보조 동기화
            </div>
          </div>
        </div>

        <div className="pointer-events-auto flex items-center gap-4 bg-stone-900/92 text-white rounded-2xl px-4 py-2.5 shadow-md">
          <div>
            <div className="text-[10px] text-stone-400">걷는 거리</div>
            <div className="font-mono-num text-base font-bold text-emerald-400">
              {distanceMeters >= 1000
                ? `${(distanceMeters / 1000).toFixed(2)} km`
                : `${Math.round(distanceMeters)} m`}
            </div>
          </div>
          <div className="h-6 w-px bg-stone-700" />
          <div>
            <div className="text-[10px] text-stone-400">보행 속도</div>
            <div className="font-mono-num text-base font-bold">
              {currentSpeedKmh.toFixed(1)} km/h
            </div>
          </div>
          <div className="h-6 w-px bg-stone-700" />
          <div>
            <div className="text-[10px] text-stone-400">걸음 수</div>
            <div className="font-mono-num text-base font-bold">
              {stepsCount.toLocaleString()}보
            </div>
          </div>
        </div>
      </header>

      {/* Bottom Walk Controls Dock */}
      <div className="absolute bottom-5 left-1/2 -translate-x-1/2 z-20 w-[94vw] max-w-2xl bg-white/95 border border-stone-200 rounded-3xl p-4 shadow-xl space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-1.5">
            {DEFAULT_WALK_ROUTE.map((r, i) => (
              <button
                key={r.name}
                type="button"
                onClick={() => selectRoute(i)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                  routeIdx === i
                    ? 'bg-stone-900 text-white'
                    : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                }`}
              >
                {r.name.split(' ')[0]}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={() => setGpsActive((v) => !v)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
              gpsActive
                ? 'bg-emerald-600 text-white'
                : 'bg-sky-50 text-sky-800 border border-sky-200 hover:bg-sky-100'
            }`}
          >
            <Navigation className="w-3.5 h-3.5" />
            {gpsActive ? '실시간 GPS 연동 중' : '내 GPS 걸음 연동'}
          </button>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setPaceMode('stop')}
              className={`px-3 py-2 rounded-xl text-xs font-semibold cursor-pointer ${
                paceMode === 'stop'
                  ? 'bg-stone-900 text-white'
                  : 'bg-stone-100 text-stone-700'
              }`}
            >
              잠시 멈춤
            </button>
            <button
              type="button"
              onClick={() => setPaceMode('walk')}
              className={`px-3 py-2 rounded-xl text-xs font-semibold cursor-pointer ${
                paceMode === 'walk'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-stone-100 text-stone-700'
              }`}
            >
              보통 걸음
            </button>
            <button
              type="button"
              onClick={() => setPaceMode('run')}
              className={`px-3 py-2 rounded-xl text-xs font-semibold cursor-pointer ${
                paceMode === 'run'
                  ? 'bg-amber-600 text-white'
                  : 'bg-stone-100 text-stone-700'
              }`}
            >
              신나게 뛰기
            </button>
            <button
              type="button"
              onClick={() => setHeading((h) => (h + 25) % 360)}
              className="px-3 py-2 rounded-xl text-xs font-semibold bg-stone-100 text-stone-700 hover:bg-stone-200 cursor-pointer"
              title="방향 회전"
            >
              <MapPin className="w-3.5 h-3.5 inline mr-1" />
              방향 전환
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleStepTap}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-900 text-xs font-bold cursor-pointer"
            >
              <Footprints className="w-3.5 h-3.5" />
              +12m 함께 걷기
            </button>
            <button
              type="button"
              onClick={() => onFinishWalk(Math.max(50, Math.round(distanceMeters)))}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-stone-900 hover:bg-stone-800 text-white text-xs font-bold cursor-pointer"
            >
              <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
              산책 완료
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
