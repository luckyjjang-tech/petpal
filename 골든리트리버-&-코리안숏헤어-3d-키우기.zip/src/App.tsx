import {useCallback, useEffect, useState} from 'react';
import {petAudio} from './audio/petAudio';
import {CareStage} from './components/CareStage';
import {DonationModal} from './components/DonationModal';
import {SettingsModal} from './components/SettingsModal';
import {ShowcaseStage} from './components/ShowcaseStage';
import {WalkModeView} from './components/WalkModeView';
import {WebsiteSections} from './components/WebsiteSections';
import {
  CareSchedule,
  DonationRecord,
  PetSpecies,
  WARDROBE_CATALOG,
  WardrobeItem,
} from './types/pet';

type AppPage = 'showcase' | 'care' | 'walk';

interface PersistedState {
  species: PetSpecies;
  page: AppPage;
  started: boolean;
  baseScore: number;
  bonusScore: number;
  maturity: number; // 0..1
  hunger: number;   // 0..100
  pottyNeed: number; // 0..100
  vitality: number;  // 0..100
  schedule: CareSchedule;
  timeScaleMode: 'realtime' | 'fast';
  unlockedItemIds: string[];
  equippedClothesId: string | null;
  equippedAccessoryId: string | null;
  claimedMilestones: number[];
  donations: DonationRecord[];
  lastUpdatedAt: number;
}

const STORAGE_KEY = 'pet_3d_companion_state_v1';

const DEFAULT_STATE: PersistedState = {
  species: 'golden_retriever',
  page: 'showcase',
  started: false,
  baseScore: 10,
  bonusScore: 10,
  maturity: 0.04,
  hunger: 72,
  pottyNeed: 22,
  vitality: 88,
  schedule: {
    morningMeal: '08:00',
    lunchMeal: '13:00',
    dinnerMeal: '19:00',
    walkTime: '17:30',
  },
  timeScaleMode: 'realtime',
  unlockedItemIds: [],
  equippedClothesId: null,
  equippedAccessoryId: null,
  claimedMilestones: [],
  donations: [],
  lastUpdatedAt: Date.now(),
};

function isNearScheduledTime(hhmm: string, toleranceMinutes = 45): boolean {
  const [hStr, mStr] = hhmm.split(':');
  const targetH = Number(hStr);
  const targetM = Number(mStr);
  if (Number.isNaN(targetH) || Number.isNaN(targetM)) return false;

  const now = new Date();
  const nowTotal = now.getHours() * 60 + now.getMinutes();
  const targetTotal = targetH * 60 + targetM;
  return Math.abs(nowTotal - targetTotal) <= toleranceMinutes;
}

function loadInitialState(): PersistedState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_STATE;
    const parsed = JSON.parse(raw) as Partial<PersistedState>;
    return {
      ...DEFAULT_STATE,
      ...parsed,
      page: parsed.page === 'walk' ? 'care' : parsed.page || 'showcase',
      schedule: {...DEFAULT_STATE.schedule, ...(parsed.schedule || {})},
    };
  } catch {
    return DEFAULT_STATE;
  }
}

export default function App() {
  const [state, setState] = useState<PersistedState>(loadInitialState);
  const [muted, setMuted] = useState(false);
  const [bgmEnabled, setBgmEnabled] = useState(true);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [donationOpen, setDonationOpen] = useState(false);
  const [pendingGiftItem, setPendingGiftItem] = useState<WardrobeItem | null>(null);
  const [quotaExceeded, setQuotaExceeded] = useState(false);

  // Arm cheerful background music to begin on first user interaction
  useEffect(() => {
    petAudio.armAutoBgm();
  }, []);

  // Listen for Google Maps Platform Demo Key quota errors (Section 8 Case A)
  useEffect(() => {
    const handler = () => setQuotaExceeded(true);
    window.addEventListener('gmp-quota-exceeded', handler);
    return () => window.removeEventListener('gmp-quota-exceeded', handler);
  }, []);

  // Persist to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      // Ignore storage errors
    }
  }, [state]);

  // Realistic maturation & nutrition/health simulation loop
  useEffect(() => {
    if (state.page !== 'care' && state.page !== 'walk') return;
    const interval = window.setInterval(() => {
      setState((prev) => {
        const fast = prev.timeScaleMode === 'fast';
        const hungerDrop = fast ? 1.3 : 0.08;
        const pottyRise = fast ? 1.1 : 0.07;

        const nextHunger = Math.max(0, prev.hunger - hungerDrop);
        const nextPotty = Math.min(100, prev.pottyNeed + pottyRise);

        // If meal is missed / hunger is low, pet loses vitality and does not grow well (Req 10)
        const poorlyFed = nextHunger < 28;
        const nextVitality = poorlyFed
          ? Math.max(25, prev.vitality - (fast ? 1.2 : 0.12))
          : Math.min(100, prev.vitality + (fast ? 0.45 : 0.04));

        // Healthy nutrition enables steady maturation toward adulthood
        const growthRate = poorlyFed
          ? 0
          : (fast ? 0.0045 : 0.00018) * (nextVitality / 100);
        const nextMaturity = Math.min(1, prev.maturity + growthRate);

        return {
          ...prev,
          hunger: nextHunger,
          pottyNeed: nextPotty,
          vitality: nextVitality,
          maturity: nextMaturity,
          lastUpdatedAt: Date.now(),
        };
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [state.page]);

  const toggleMute = useCallback(() => {
    setMuted((m) => {
      const next = !m;
      petAudio.setMuted(next);
      return next;
    });
  }, []);

  const toggleBgm = useCallback(() => {
    setBgmEnabled((prev) => {
      const next = !prev;
      if (next && muted) {
        setMuted(false);
        petAudio.setMuted(false);
      }
      petAudio.setBgmEnabled(next);
      return next;
    });
  }, [muted]);

  const handleAdopt = useCallback((species: PetSpecies) => {
    setState((prev) => ({
      ...prev,
      species,
      page: 'care',
      started: false,
      baseScore: 10,
      bonusScore: 10,
      maturity: 0.04,
      hunger: 75,
      pottyNeed: 20,
      vitality: 90,
      equippedClothesId: null,
      equippedAccessoryId: null,
      lastUpdatedAt: Date.now(),
    }));
  }, []);

  const addBonusPoints = useCallback((delta: number) => {
    setState((prev) => {
      const nextBonus = prev.bonusScore + delta;
      // Auto-unlock wardrobe items whose threshold is reached
      const newlyUnlocked = WARDROBE_CATALOG.filter(
        (item) => nextBonus >= item.unlockScore && !prev.unlockedItemIds.includes(item.id),
      ).map((i) => i.id);

      return {
        ...prev,
        bonusScore: nextBonus,
        unlockedItemIds:
          newlyUnlocked.length > 0
            ? [...prev.unlockedItemIds, ...newlyUnlocked]
            : prev.unlockedItemIds,
      };
    });
  }, []);

  const handleFeed = useCallback((): {onTime: boolean; pointsAdded: number} => {
    const onTime =
      isNearScheduledTime(state.schedule.morningMeal) ||
      isNearScheduledTime(state.schedule.lunchMeal) ||
      isNearScheduledTime(state.schedule.dinnerMeal);
    // Req 6: Feeding on time grants +1 bonus point
    const pointsAdded = onTime ? 1 : 0;

    setState((prev) => {
      const nextBonus = prev.started ? prev.bonusScore + pointsAdded : prev.bonusScore;
      const newlyUnlocked = WARDROBE_CATALOG.filter(
        (item) => nextBonus >= item.unlockScore && !prev.unlockedItemIds.includes(item.id),
      ).map((i) => i.id);

      return {
        ...prev,
        hunger: Math.min(100, prev.hunger + 34),
        vitality: Math.min(100, prev.vitality + 14),
        pottyNeed: Math.min(100, prev.pottyNeed + 15),
        bonusScore: nextBonus,
        unlockedItemIds:
          newlyUnlocked.length > 0
            ? [...prev.unlockedItemIds, ...newlyUnlocked]
            : prev.unlockedItemIds,
      };
    });

    return {onTime, pointsAdded};
  }, [state.schedule]);

  const handleCleanPotty = useCallback(() => {
    setState((prev) => ({
      ...prev,
      pottyNeed: 0,
      vitality: Math.min(100, prev.vitality + 8),
    }));
    if (state.started) addBonusPoints(3);
  }, [state.started, addBonusPoints]);

  const handlePlayBall = useCallback(() => {
    setState((prev) => ({
      ...prev,
      vitality: Math.min(100, prev.vitality + 6),
      hunger: Math.max(0, prev.hunger - 4),
    }));
    if (state.started) addBonusPoints(4);
  }, [state.started, addBonusPoints]);

  const handleTouchPet = useCallback(() => {
    setState((prev) => ({
      ...prev,
      vitality: Math.min(100, prev.vitality + 2),
    }));
    if (state.started) addBonusPoints(2);
  }, [state.started, addBonusPoints]);

  const handleFinishWalk = useCallback(
    (distanceMeters: number) => {
      const onWalkSchedule = isNearScheduledTime(state.schedule.walkTime);
      // Req 6: Walk on schedule grants +2 bonus points (+ distance bonus)
      const scheduleBonus = onWalkSchedule ? 2 : 0;
      const distanceBonus = Math.max(2, Math.floor(distanceMeters / 20));
      const totalWalkPoints = scheduleBonus + distanceBonus;

      setState((prev) => {
        const nextBonus = prev.started
          ? prev.bonusScore + totalWalkPoints
          : prev.bonusScore;
        const newlyUnlocked = WARDROBE_CATALOG.filter(
          (item) => nextBonus >= item.unlockScore && !prev.unlockedItemIds.includes(item.id),
        ).map((i) => i.id);

        return {
          ...prev,
          page: 'care',
          pottyNeed: Math.max(0, prev.pottyNeed - 40),
          vitality: Math.min(100, prev.vitality + 18),
          hunger: Math.max(0, prev.hunger - 8),
          maturity: Math.min(1, prev.maturity + 0.02),
          bonusScore: nextBonus,
          unlockedItemIds:
            newlyUnlocked.length > 0
              ? [...prev.unlockedItemIds, ...newlyUnlocked]
              : prev.unlockedItemIds,
        };
      });
    },
    [state.schedule.walkTime],
  );

  // Check if a 100-point milestone gift box is ready in the sky (Req 8)
  const currentMilestone = Math.floor(state.bonusScore / 100) * 100;
  const giftReadyInSky =
    state.started &&
    currentMilestone >= 100 &&
    !state.claimedMilestones.includes(currentMilestone) &&
    !pendingGiftItem;

  const handleOpenSkyGift = useCallback(() => {
    if (currentMilestone < 100) return;
    const rewardItem =
      WARDROBE_CATALOG.find((i) => !state.unlockedItemIds.includes(i.id)) ||
      WARDROBE_CATALOG[0];

    setState((prev) => ({
      ...prev,
      claimedMilestones: prev.claimedMilestones.includes(currentMilestone)
        ? prev.claimedMilestones
        : [...prev.claimedMilestones, currentMilestone],
      unlockedItemIds: prev.unlockedItemIds.includes(rewardItem.id)
        ? prev.unlockedItemIds
        : [...prev.unlockedItemIds, rewardItem.id],
    }));
    setPendingGiftItem(rewardItem);
  }, [currentMilestone, state.unlockedItemIds]);

  const handleEquipItem = useCallback((item: WardrobeItem) => {
    setState((prev) => ({
      ...prev,
      unlockedItemIds: prev.unlockedItemIds.includes(item.id)
        ? prev.unlockedItemIds
        : [...prev.unlockedItemIds, item.id],
      equippedClothesId:
        item.slot === 'clothes' ? item.id : prev.equippedClothesId,
      equippedAccessoryId:
        item.slot === 'accessory' ? item.id : prev.equippedAccessoryId,
    }));
    setPendingGiftItem(null);
  }, []);

  const handleUnequipSlot = useCallback((slot: 'clothes' | 'accessory') => {
    setState((prev) => ({
      ...prev,
      equippedClothesId: slot === 'clothes' ? null : prev.equippedClothesId,
      equippedAccessoryId:
        slot === 'accessory' ? null : prev.equippedAccessoryId,
    }));
  }, []);

  const handleCompleteDonation = useCallback(
    (record: DonationRecord, bonusBoost: number) => {
      setState((prev) => {
        const nextBonus = prev.bonusScore + bonusBoost;
        const newlyUnlocked = WARDROBE_CATALOG.filter(
          (item) => nextBonus >= item.unlockScore && !prev.unlockedItemIds.includes(item.id),
        ).map((i) => i.id);

        return {
          ...prev,
          started: true,
          bonusScore: nextBonus,
          donations: [record, ...prev.donations],
          unlockedItemIds:
            newlyUnlocked.length > 0
              ? [...prev.unlockedItemIds, ...newlyUnlocked]
              : prev.unlockedItemIds,
        };
      });
    },
    [],
  );

  const navigateToSection = useCallback((sectionId: string) => {
    setState((prev) => ({...prev, page: 'showcase'}));
    window.setTimeout(() => {
      const el = document.getElementById(sectionId);
      if (el) {
        el.scrollIntoView({behavior: 'smooth'});
      } else {
        window.scrollTo({top: 0, behavior: 'smooth'});
      }
    }, 40);
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-stone-50 text-stone-900">
      {/* Required Google Maps Platform Demo Key Quota Banner */}
      {quotaExceeded && (
        <div className="bg-amber-50 border-b border-amber-200 text-amber-900 px-4 py-2 text-xs md:text-sm text-center sticky top-0 z-50 shadow-sm">
          <span>
            Google Maps Platform quota reached. If you are the app owner, visit{' '}
            <a
              href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
              target="_blank"
              rel="noopener noreferrer"
              className="underline font-semibold text-amber-950 hover:text-amber-800"
            >
              maps developer site
            </a>{' '}
            for instructions to update your account.
          </span>
        </div>
      )}

      {/* Website Top Navigation Bar (Strict 3-zone Top Bar Contract) */}
      <header className="sticky top-0 z-40 h-16 bg-white/95 border-b border-stone-200">
        <div className="max-w-7xl mx-auto h-full px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-8">
          <a
            href="#stage"
            onClick={(e) => {
              e.preventDefault();
              navigateToSection('stage');
            }}
            className="font-display text-lg font-bold tracking-tight text-stone-900 whitespace-nowrap shrink-0"
          >
            포근한 3D 반려생활
          </a>

          <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-stone-600">
            <a
              href="#stage"
              onClick={(e) => {
                e.preventDefault();
                navigateToSection('stage');
              }}
              className="hover:text-stone-900 hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
            >
              3D 분양관
            </a>
            <a
              href="#breeds"
              onClick={(e) => {
                e.preventDefault();
                navigateToSection('breeds');
              }}
              className="hover:text-stone-900 hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
            >
              품종 소개
            </a>
            <a
              href="#care-guide"
              onClick={(e) => {
                e.preventDefault();
                navigateToSection('care-guide');
              }}
              className="hover:text-stone-900 hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
            >
              케어 시스템
            </a>
            <a
              href="#sponsorship"
              onClick={(e) => {
                e.preventDefault();
                navigateToSection('sponsorship');
              }}
              className="hover:text-stone-900 hover:underline underline-offset-4 transition-colors whitespace-nowrap shrink-0"
            >
              후원 안내
            </a>
          </nav>

          <div className="shrink-0">
            {state.page === 'showcase' ? (
              <button
                type="button"
                onClick={() => {
                  petAudio.startBgm();
                  setState((prev) => ({...prev, page: 'care'}));
                  window.scrollTo({top: 0});
                }}
                className="px-4 py-2 text-xs sm:text-sm font-bold text-white bg-stone-900 rounded-xl hover:bg-stone-800 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                돌봄 방 바로가기
              </button>
            ) : (
              <button
                type="button"
                onClick={() => {
                  setState((prev) => ({...prev, page: 'showcase'}));
                  window.scrollTo({top: 0, behavior: 'smooth'});
                }}
                className="px-4 py-2 text-xs sm:text-sm font-bold text-stone-900 bg-stone-100 border border-stone-300 rounded-xl hover:bg-stone-200 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                웹사이트 홈으로
              </button>
            )}
          </div>
        </div>
      </header>

      <main className="flex-1 w-full">
        {state.page === 'showcase' && (
          <>
            {/* Website Hero + Live Interactive 3D Stage */}
            <section
              id="stage"
              className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-7 sm:pt-10 pb-12"
            >
              <div className="max-w-3xl mb-6">
                <p className="text-xs font-semibold text-amber-700 tracking-wide">
                  실시간 인터랙티브 3D 반려동물 분양 &amp; 케어
                </p>
                <h1 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-stone-900 mt-2 leading-tight text-balance">
                  골든리트리버와 코리안숏헤어를 3D로 분양받아 키워보세요
                </h1>
                <p className="text-sm sm:text-base text-stone-600 mt-3 leading-relaxed">
                  어린 시절부터 성견·성묘로 자라며 꽃밭 위를 뛰어노는 모습을 감상하고, 손가락이나
                  마우스로 터치해 짖는 소리·한글 말풍선·애교 구르기를 체험한 뒤 분양해 보세요.
                </p>
              </div>

              <div className="relative w-full h-[64vh] min-h-[480px] max-h-[680px] rounded-3xl overflow-hidden border border-stone-200 shadow-lg bg-sky-50">
                <ShowcaseStage
                  onAdopt={(species) => {
                    handleAdopt(species);
                    window.scrollTo({top: 0});
                  }}
                  muted={muted}
                  bgmEnabled={bgmEnabled}
                  onToggleMute={toggleMute}
                  onToggleBgm={toggleBgm}
                />
              </div>
            </section>

            <WebsiteSections
              bonusScore={state.bonusScore}
              donationCount={state.donations.length}
              onAdopt={(species) => {
                petAudio.startBgm();
                petAudio.playVocal(species, 'happy');
                handleAdopt(species);
                window.scrollTo({top: 0});
              }}
              onOpenDonation={() => setDonationOpen(true)}
              onGoToCare={() => {
                petAudio.startBgm();
                setState((prev) => ({...prev, page: 'care'}));
                window.scrollTo({top: 0});
              }}
            />
          </>
        )}

        {state.page === 'care' && (
          <div className="relative w-full h-[calc(100vh-4rem)] min-h-[540px]">
            <CareStage
              species={state.species}
              started={state.started}
              bonusScore={state.bonusScore}
              baseScore={state.baseScore}
              maturity={state.maturity}
              hunger={state.hunger}
              pottyNeed={state.pottyNeed}
              vitality={state.vitality}
              schedule={state.schedule}
              timeScaleMode={state.timeScaleMode}
              unlockedItemIds={state.unlockedItemIds}
              equippedClothesId={state.equippedClothesId}
              equippedAccessoryId={state.equippedAccessoryId}
              pendingGiftItem={pendingGiftItem}
              giftReadyInSky={giftReadyInSky}
              muted={muted}
              bgmEnabled={bgmEnabled}
              onToggleMute={toggleMute}
              onToggleBgm={toggleBgm}
              onStartCare={() =>
                setState((prev) => ({
                  ...prev,
                  started: true,
                  bonusScore: Math.max(prev.bonusScore, prev.baseScore),
                }))
              }
              onOpenSettings={() => setSettingsOpen(true)}
              onOpenDonation={() => setDonationOpen(true)}
              onStartWalk={() => setState((prev) => ({...prev, page: 'walk'}))}
              onFeed={handleFeed}
              onCleanPotty={handleCleanPotty}
              onPlayBall={handlePlayBall}
              onTouchPet={handleTouchPet}
              onOpenSkyGift={handleOpenSkyGift}
              onStorePendingGift={() => setPendingGiftItem(null)}
              onEquipItem={handleEquipItem}
              onUnequipSlot={handleUnequipSlot}
              onBackToShowcase={() =>
                setState((prev) => ({...prev, page: 'showcase'}))
              }
            />
          </div>
        )}

        {state.page === 'walk' && (
          <div className="relative w-full h-[calc(100vh-4rem)] min-h-[540px]">
            <WalkModeView
              species={state.species}
              maturity={state.maturity}
              healthFactor={Math.max(0.35, state.vitality / 100)}
              equippedClothesId={state.equippedClothesId}
              equippedAccessoryId={state.equippedAccessoryId}
              onFinishWalk={handleFinishWalk}
              onBack={() => setState((prev) => ({...prev, page: 'care'}))}
            />
          </div>
        )}
      </main>

      {settingsOpen && (
        <SettingsModal
          schedule={state.schedule}
          timeScaleMode={state.timeScaleMode}
          onSave={(newSchedule, scale) => {
            setState((prev) => ({
              ...prev,
              schedule: newSchedule,
              timeScaleMode: scale,
            }));
            setSettingsOpen(false);
          }}
          onClose={() => setSettingsOpen(false)}
        />
      )}

      {donationOpen && (
        <DonationModal
          bonusScore={state.bonusScore}
          donations={state.donations}
          unlockedItemIds={state.unlockedItemIds}
          onCompleteDonation={handleCompleteDonation}
          onClose={() => setDonationOpen(false)}
        />
      )}
    </div>
  );
}
