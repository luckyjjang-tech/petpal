import * as THREE from 'three';

function createCanvas(size: number): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  return [canvas, ctx];
}

export interface FurTextureSet {
  goldenFurMap: THREE.CanvasTexture;
  goldenFurBump: THREE.CanvasTexture;
  tabbyFurMap: THREE.CanvasTexture;
  tabbyHeadMap: THREE.CanvasTexture;
  tabbyFurBump: THREE.CanvasTexture;
  dogEyeMap: THREE.CanvasTexture;
  catEyeMap: THREE.CanvasTexture;
  woodFloorMap: THREE.CanvasTexture;
  rugMap: THREE.CanvasTexture;
  grassMap: THREE.CanvasTexture;
  stonePathMap: THREE.CanvasTexture;
  giftWrapMap: THREE.CanvasTexture;
}

export function createProceduralTextureSet(maxAnisotropy: number): FurTextureSet {
  // 1. Golden Retriever realistic directional fur strands
  const [gCanvas, gCtx] = createCanvas(512);
  const gGrad = gCtx.createLinearGradient(0, 0, 0, 512);
  gGrad.addColorStop(0, '#c8832c');
  gGrad.addColorStop(0.45, '#dfa145');
  gGrad.addColorStop(0.8, '#ecc278');
  gGrad.addColorStop(1, '#f3d8a3');
  gCtx.fillStyle = gGrad;
  gCtx.fillRect(0, 0, 512, 512);

  for (let i = 0; i < 6500; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 512;
    const len = 8 + Math.random() * 18;
    const shade = Math.random();
    gCtx.strokeStyle =
      shade > 0.65
        ? 'rgba(255, 232, 185, 0.28)'
        : shade > 0.25
          ? 'rgba(186, 114, 34, 0.22)'
          : 'rgba(145, 82, 18, 0.18)';
    gCtx.lineWidth = 1.1 + Math.random() * 1.4;
    gCtx.beginPath();
    gCtx.moveTo(x, y);
    gCtx.quadraticCurveTo(x + (Math.random() - 0.5) * 3, y + len * 0.5, x + (Math.random() - 0.5) * 4, y + len);
    gCtx.stroke();
  }
  const goldenFurMap = new THREE.CanvasTexture(gCanvas);
  goldenFurMap.colorSpace = THREE.SRGBColorSpace;
  goldenFurMap.wrapS = THREE.RepeatWrapping;
  goldenFurMap.wrapT = THREE.RepeatWrapping;
  goldenFurMap.anisotropy = maxAnisotropy;

  // Fur bump texture
  const [bCanvas, bCtx] = createCanvas(256);
  bCtx.fillStyle = '#808080';
  bCtx.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 3600; i++) {
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    const v = 90 + Math.floor(Math.random() * 130);
    bCtx.strokeStyle = `rgb(${v},${v},${v})`;
    bCtx.lineWidth = 1;
    bCtx.beginPath();
    bCtx.moveTo(x, y);
    bCtx.lineTo(x + (Math.random() - 0.5) * 2, y + 6 + Math.random() * 10);
    bCtx.stroke();
  }
  const goldenFurBump = new THREE.CanvasTexture(bCanvas);
  goldenFurBump.wrapS = THREE.RepeatWrapping;
  goldenFurBump.wrapT = THREE.RepeatWrapping;

  // 2. Korean Shorthair (코리안숏헤어 치즈태비/고등어태비) body fur texture
  const [tCanvas, tCtx] = createCanvas(512);
  const tGrad = tCtx.createLinearGradient(0, 0, 0, 512);
  tGrad.addColorStop(0, '#c26d27');
  tGrad.addColorStop(0.5, '#df9346');
  tGrad.addColorStop(0.85, '#f2cfa1');
  tGrad.addColorStop(1, '#faf2e6');
  tCtx.fillStyle = tGrad;
  tCtx.fillRect(0, 0, 512, 512);

  // Mackerel tabby vertical/curved stripes
  for (let s = 0; s < 14; s++) {
    const sx = (s / 14) * 512;
    tCtx.strokeStyle = 'rgba(110, 48, 12, 0.38)';
    tCtx.lineWidth = 10 + (s % 3) * 4;
    tCtx.lineCap = 'round';
    tCtx.beginPath();
    tCtx.moveTo(sx, 20);
    tCtx.bezierCurveTo(sx + 14, 150, sx - 12, 270, sx + 6, 390);
    tCtx.stroke();
  }
  // Short dense feline hair strokes
  for (let i = 0; i < 7000; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 512;
    const len = 5 + Math.random() * 9;
    tCtx.strokeStyle =
      Math.random() > 0.5
        ? 'rgba(255, 240, 215, 0.22)'
        : 'rgba(120, 56, 18, 0.16)';
    tCtx.lineWidth = 1;
    tCtx.beginPath();
    tCtx.moveTo(x, y);
    tCtx.lineTo(x + (Math.random() - 0.5) * 2, y + len);
    tCtx.stroke();
  }
  const tabbyFurMap = new THREE.CanvasTexture(tCanvas);
  tabbyFurMap.colorSpace = THREE.SRGBColorSpace;
  tabbyFurMap.wrapS = THREE.RepeatWrapping;
  tabbyFurMap.wrapT = THREE.RepeatWrapping;
  tabbyFurMap.anisotropy = maxAnisotropy;

  // Cat head texture with classic Korean Shorthair 'M' forehead mark & cream cheeks
  const [thCanvas, thCtx] = createCanvas(512);
  thCtx.drawImage(tCanvas, 0, 0);
  // White muzzle/chin bib on front UV zone
  const cheekGrad = thCtx.createRadialGradient(256, 310, 20, 256, 310, 145);
  cheekGrad.addColorStop(0, 'rgba(252, 248, 242, 0.96)');
  cheekGrad.addColorStop(0.65, 'rgba(248, 232, 210, 0.6)');
  cheekGrad.addColorStop(1, 'rgba(248, 232, 210, 0)');
  thCtx.fillStyle = cheekGrad;
  thCtx.fillRect(0, 0, 512, 512);
  // Forehead M tabby stripes
  thCtx.strokeStyle = 'rgba(98, 42, 10, 0.55)';
  thCtx.lineWidth = 7;
  thCtx.lineCap = 'round';
  for (const offset of [-32, -10, 10, 32]) {
    thCtx.beginPath();
    thCtx.moveTo(256 + offset * 0.7, 175);
    thCtx.quadraticCurveTo(256 + offset, 125, 256 + offset * 1.25, 85);
    thCtx.stroke();
  }
  const tabbyHeadMap = new THREE.CanvasTexture(thCanvas);
  tabbyHeadMap.colorSpace = THREE.SRGBColorSpace;
  tabbyHeadMap.anisotropy = maxAnisotropy;

  const tabbyFurBump = goldenFurBump.clone();
  tabbyFurBump.needsUpdate = true;

  // 3. Realistic Dog Eye (warm deep amber-brown iris, dark pupil, wet catchlight)
  const [deCanvas, deCtx] = createCanvas(256);
  deCtx.fillStyle = '#f8f5f0';
  deCtx.fillRect(0, 0, 256, 256);
  const dIris = deCtx.createRadialGradient(128, 128, 24, 128, 128, 102);
  dIris.addColorStop(0, '#1c0f08');
  dIris.addColorStop(0.42, '#4a2511');
  dIris.addColorStop(0.85, '#6b3818');
  dIris.addColorStop(1, '#26140a');
  deCtx.fillStyle = dIris;
  deCtx.beginPath();
  deCtx.arc(128, 128, 104, 0, Math.PI * 2);
  deCtx.fill();
  // Pupil
  deCtx.fillStyle = '#070504';
  deCtx.beginPath();
  deCtx.arc(128, 128, 52, 0, Math.PI * 2);
  deCtx.fill();
  // Specular highlights
  deCtx.fillStyle = '#ffffff';
  deCtx.beginPath();
  deCtx.arc(102, 98, 18, 0, Math.PI * 2);
  deCtx.fill();
  deCtx.beginPath();
  deCtx.arc(154, 152, 7, 0, Math.PI * 2);
  deCtx.fill();
  const dogEyeMap = new THREE.CanvasTexture(deCanvas);
  dogEyeMap.colorSpace = THREE.SRGBColorSpace;

  // 4. Realistic Cat Eye (golden-emerald iris, vertical slit pupil, crisp catchlight)
  const [ceCanvas, ceCtx] = createCanvas(256);
  ceCtx.fillStyle = '#efe9dc';
  ceCtx.fillRect(0, 0, 256, 256);
  const cIris = ceCtx.createRadialGradient(128, 128, 20, 128, 128, 110);
  cIris.addColorStop(0, '#c8df66');
  cIris.addColorStop(0.55, '#8bb93a');
  cIris.addColorStop(0.88, '#4f7a24');
  cIris.addColorStop(1, '#233b11');
  ceCtx.fillStyle = cIris;
  ceCtx.beginPath();
  ceCtx.arc(128, 128, 108, 0, Math.PI * 2);
  ceCtx.fill();
  // Vertical slit pupil
  ceCtx.fillStyle = '#070806';
  ceCtx.beginPath();
  ceCtx.ellipse(128, 128, 22, 78, 0, 0, Math.PI * 2);
  ceCtx.fill();
  // Catchlights
  ceCtx.fillStyle = '#ffffff';
  ceCtx.beginPath();
  ceCtx.arc(100, 96, 19, 0, Math.PI * 2);
  ceCtx.fill();
  ceCtx.beginPath();
  ceCtx.arc(158, 155, 8, 0, Math.PI * 2);
  ceCtx.fill();
  const catEyeMap = new THREE.CanvasTexture(ceCanvas);
  catEyeMap.colorSpace = THREE.SRGBColorSpace;

  // 5. Warm Oak Wood Floor
  const [wCanvas, wCtx] = createCanvas(512);
  wCtx.fillStyle = '#dfb88d';
  wCtx.fillRect(0, 0, 512, 512);
  for (let row = 0; row < 8; row++) {
    const y = row * 64;
    wCtx.fillStyle = row % 2 === 0 ? '#d8ad7f' : '#e2be96';
    wCtx.fillRect(0, y, 512, 62);
    wCtx.fillStyle = 'rgba(130, 82, 38, 0.25)';
    wCtx.fillRect(0, y + 62, 512, 2);
    for (let g = 0; g < 22; g++) {
      wCtx.strokeStyle = 'rgba(155, 98, 48, 0.14)';
      wCtx.beginPath();
      wCtx.moveTo(0, y + Math.random() * 60);
      wCtx.lineTo(512, y + Math.random() * 60);
      wCtx.stroke();
    }
  }
  const woodFloorMap = new THREE.CanvasTexture(wCanvas);
  woodFloorMap.colorSpace = THREE.SRGBColorSpace;
  woodFloorMap.wrapS = THREE.RepeatWrapping;
  woodFloorMap.wrapT = THREE.RepeatWrapping;
  woodFloorMap.repeat.set(4, 4);
  woodFloorMap.anisotropy = maxAnisotropy;

  // 6. Soft Woven Rug
  const [rCanvas, rCtx] = createCanvas(512);
  rCtx.fillStyle = '#faf3e8';
  rCtx.fillRect(0, 0, 512, 512);
  rCtx.strokeStyle = '#e7d7c1';
  rCtx.lineWidth = 4;
  for (let i = 0; i < 512; i += 16) {
    rCtx.beginPath();
    rCtx.moveTo(i, 0);
    rCtx.lineTo(i, 512);
    rCtx.stroke();
  }
  rCtx.strokeStyle = '#d98a5f';
  rCtx.lineWidth = 18;
  rCtx.strokeRect(24, 24, 464, 464);
  const rugMap = new THREE.CanvasTexture(rCanvas);
  rugMap.colorSpace = THREE.SRGBColorSpace;
  rugMap.anisotropy = maxAnisotropy;

  // 7. Meadow Grass
  const [grCanvas, grCtx] = createCanvas(512);
  grCtx.fillStyle = '#53943c';
  grCtx.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 6500; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 512;
    grCtx.strokeStyle =
      Math.random() > 0.48
        ? 'rgba(134, 212, 82, 0.52)'
        : 'rgba(48, 102, 32, 0.4)';
    grCtx.lineWidth = 1.6;
    grCtx.beginPath();
    grCtx.moveTo(x, y);
    grCtx.lineTo(x + (Math.random() - 0.5) * 4, y - 6 - Math.random() * 8);
    grCtx.stroke();
  }
  const grassMap = new THREE.CanvasTexture(grCanvas);
  grassMap.colorSpace = THREE.SRGBColorSpace;
  grassMap.wrapS = THREE.RepeatWrapping;
  grassMap.wrapT = THREE.RepeatWrapping;
  grassMap.repeat.set(8, 8);
  grassMap.anisotropy = maxAnisotropy;

  // 8. Stone Walkway Path
  const [stCanvas, stCtx] = createCanvas(512);
  stCtx.fillStyle = '#dcd4c6';
  stCtx.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 42; i++) {
    const px = Math.random() * 512;
    const py = Math.random() * 512;
    const rx = 26 + Math.random() * 44;
    const ry = 18 + Math.random() * 32;
    stCtx.fillStyle =
      i % 2 === 0 ? 'rgba(235, 228, 216, 0.8)' : 'rgba(198, 188, 172, 0.7)';
    stCtx.beginPath();
    stCtx.ellipse(px, py, rx, ry, Math.random() * Math.PI, 0, Math.PI * 2);
    stCtx.fill();
  }
  const stonePathMap = new THREE.CanvasTexture(stCanvas);
  stonePathMap.colorSpace = THREE.SRGBColorSpace;
  stonePathMap.wrapS = THREE.RepeatWrapping;
  stonePathMap.wrapT = THREE.RepeatWrapping;
  stonePathMap.repeat.set(6, 1);
  stonePathMap.anisotropy = maxAnisotropy;

  // 9. Gift Box Wrap
  const [gfCanvas, gfCtx] = createCanvas(256);
  gfCtx.fillStyle = '#fff5f2';
  gfCtx.fillRect(0, 0, 256, 256);
  gfCtx.fillStyle = '#f43f5e';
  for (let x = 0; x < 256; x += 32) {
    for (let y = 0; y < 256; y += 32) {
      gfCtx.beginPath();
      gfCtx.arc(x + 16, y + 16, 5, 0, Math.PI * 2);
      gfCtx.fill();
    }
  }
  const giftWrapMap = new THREE.CanvasTexture(gfCanvas);
  giftWrapMap.colorSpace = THREE.SRGBColorSpace;

  return {
    goldenFurMap,
    goldenFurBump,
    tabbyFurMap,
    tabbyHeadMap,
    tabbyFurBump,
    dogEyeMap,
    catEyeMap,
    woodFloorMap,
    rugMap,
    grassMap,
    stonePathMap,
    giftWrapMap,
  };
}
