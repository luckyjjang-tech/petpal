import * as THREE from 'three';
import {RoomEnvironment} from 'three/addons/environments/RoomEnvironment.js';
import {FurTextureSet} from './furTextures';

export function detectSoftwareGl(): boolean {
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

export function createConfiguredRenderer(
  container: HTMLElement,
  isSoftwareGl: boolean,
  alpha = false,
): THREE.WebGLRenderer {
  const renderer = new THREE.WebGLRenderer({
    antialias: !isSoftwareGl,
    alpha,
    powerPreference: 'high-performance',
  });
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.08;
  renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
  renderer.setSize(container.clientWidth || window.innerWidth, container.clientHeight || window.innerHeight);
  renderer.shadowMap.enabled = !isSoftwareGl && !alpha;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  if (alpha) {
    renderer.setClearColor(0x000000, 0);
  }
  container.appendChild(renderer.domElement);
  return renderer;
}

export function setupStudioLighting(
  scene: THREE.Scene,
  renderer: THREE.WebGLRenderer,
  horizonColorHex: number | null,
): void {
  const pmrem = new THREE.PMREMGenerator(renderer);
  const envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
  scene.environment = envTex;
  pmrem.dispose();

  if (horizonColorHex !== null) {
    scene.background = new THREE.Color(horizonColorHex);
    // Keep foreground and garden trees crisp with only ultra-distant horizon softening
    scene.fog = new THREE.Fog(horizonColorHex, 20, 52);
  }

  // Crisp warm sunlight key light
  const keyLight = new THREE.DirectionalLight(0xfff7e6, 2.25);
  keyLight.position.set(4.5, 8.8, 5.8);
  keyLight.castShadow = true;
  keyLight.shadow.mapSize.width = 1024;
  keyLight.shadow.mapSize.height = 1024;
  keyLight.shadow.camera.near = 1;
  keyLight.shadow.camera.far = 26;
  const d = 6;
  keyLight.shadow.camera.left = -d;
  keyLight.shadow.camera.right = d;
  keyLight.shadow.camera.top = d;
  keyLight.shadow.camera.bottom = -d;
  keyLight.shadow.bias = -0.0005;
  keyLight.shadow.normalBias = 0.02;
  scene.add(keyLight);

  // Clear sky / rich meadow hemisphere fill
  const hemiLight = new THREE.HemisphereLight(0xdbeafe, 0x86a36b, 0.92);
  scene.add(hemiLight);

  // Subtle rim light for sharp fur & petal silhouette separation
  const rimLight = new THREE.DirectionalLight(0xffe9cc, 0.85);
  rimLight.position.set(-4, 4.5, -6);
  scene.add(rimLight);
}

export function afterDraw(
  renderer: THREE.WebGLRenderer,
  cb: () => void,
  setTimerId: (id: number) => void,
): void {
  const gl = renderer.getContext() as WebGL2RenderingContext;
  if (!gl || typeof gl.fenceSync !== 'function') {
    setTimerId(window.setTimeout(cb, 80));
    return;
  }
  const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
  gl.flush();
  const poll = () => {
    const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
    if (state === gl.UNSIGNALED) {
      setTimerId(window.setTimeout(poll, 5));
    } else {
      if (sync) gl.deleteSync(sync);
      setTimerId(window.setTimeout(cb, 80));
    }
  };
  setTimerId(window.setTimeout(poll, 5));
}

function createTreeGroup(scale: number): THREE.Group {
  const g = new THREE.Group();
  const trunk = new THREE.Mesh(
    new THREE.CylinderGeometry(0.14 * scale, 0.22 * scale, 1.4 * scale, 8),
    new THREE.MeshStandardMaterial({color: 0x7c5338, roughness: 0.9}),
  );
  trunk.position.y = 0.7 * scale;
  trunk.castShadow = true;
  g.add(trunk);

  const leafMat = new THREE.MeshStandardMaterial({color: 0x5d9444, roughness: 0.82});
  const c1 = new THREE.Mesh(new THREE.DodecahedronGeometry(0.9 * scale, 1), leafMat);
  c1.position.y = 1.65 * scale;
  c1.castShadow = true;
  const c2 = new THREE.Mesh(new THREE.DodecahedronGeometry(0.7 * scale, 1), leafMat);
  c2.position.set(0.45 * scale, 1.35 * scale, 0.2 * scale);
  const c3 = new THREE.Mesh(new THREE.DodecahedronGeometry(0.65 * scale, 1), leafMat);
  c3.position.set(-0.4 * scale, 1.4 * scale, -0.15 * scale);
  g.add(c1, c2, c3);
  return g;
}

function addVividSkyBackdrop(scene: THREE.Scene): void {
  // Crisp sunlit gradient sky dome (no murky fog)
  const skyGeo = new THREE.SphereGeometry(38, 24, 16);
  const skyMat = new THREE.ShaderMaterial({
    side: THREE.BackSide,
    depthWrite: false,
    uniforms: {
      topColor: {value: new THREE.Color(0x38bdf8)},
      midColor: {value: new THREE.Color(0xbae6fd)},
      bottomColor: {value: new THREE.Color(0xfef9c3)},
    },
    vertexShader: `
      varying vec3 vWorldPosition;
      void main() {
        vec4 wp = modelMatrix * vec4(position, 1.0);
        vWorldPosition = wp.xyz;
        gl_Position = projectionMatrix * viewMatrix * wp;
      }
    `,
    fragmentShader: `
      uniform vec3 topColor;
      uniform vec3 midColor;
      uniform vec3 bottomColor;
      varying vec3 vWorldPosition;
      void main() {
        float h = clamp(normalize(vWorldPosition).y, 0.0, 1.0);
        vec3 col = mix(bottomColor, midColor, smoothstep(0.0, 0.25, h));
        col = mix(col, topColor, smoothstep(0.25, 0.85, h));
        gl_FragColor = vec4(col, 1.0);
      }
    `,
  });
  scene.add(new THREE.Mesh(skyGeo, skyMat));

  // Crisp fluffy stylized clouds high in the sky
  const cloudMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    roughness: 0.9,
    metalness: 0.0,
  });
  const cloudSpots: Array<[number, number, number, number]> = [
    [-7.5, 5.2, -13, 1.0],
    [-1.2, 6.4, -15, 1.25],
    [6.8, 5.5, -13.5, 1.1],
  ];
  cloudSpots.forEach(([cx, cy, cz, sc]) => {
    const cg = new THREE.Group();
    cg.position.set(cx, cy, cz);
    cg.scale.setScalar(sc);
    const p1 = new THREE.Mesh(new THREE.SphereGeometry(0.9, 12, 10), cloudMat);
    const p2 = new THREE.Mesh(new THREE.SphereGeometry(0.7, 12, 10), cloudMat);
    p2.position.set(0.75, -0.15, 0.05);
    const p3 = new THREE.Mesh(new THREE.SphereGeometry(0.65, 12, 10), cloudMat);
    p3.position.set(-0.72, -0.18, 0.05);
    cg.add(p1, p2, p3);
    scene.add(cg);
  });
}

function addLushFlowerBeds(
  scene: THREE.Scene,
  spots: Array<{x: number; z: number; scale: number; paletteIdx: number}>,
): void {
  const count = spots.length;
  if (count === 0) return;

  // 1. Crisp green stems
  const stemGeo = new THREE.CylinderGeometry(0.015, 0.022, 0.28, 6);
  const stemMat = new THREE.MeshStandardMaterial({color: 0x16a34a, roughness: 0.72});
  const stems = new THREE.InstancedMesh(stemGeo, stemMat, count);

  // 2. Twin green leaves per flower
  const leafGeo = new THREE.SphereGeometry(0.055, 8, 6);
  leafGeo.scale(1.6, 0.25, 0.65);
  const leafMat = new THREE.MeshStandardMaterial({color: 0x22c55e, roughness: 0.68});
  const leaves = new THREE.InstancedMesh(leafGeo, leafMat, count * 2);

  // 3. Vivid 6-petal flower heads (6 petals per blossom for crisp, unmistakable floral silhouettes)
  const petalCountPerFlower = 6;
  const petalGeo = new THREE.SphereGeometry(0.062, 10, 8);
  petalGeo.scale(1.25, 0.34, 0.72);
  const petalMat = new THREE.MeshStandardMaterial({
    roughness: 0.42,
    metalness: 0.04,
  });
  const petals = new THREE.InstancedMesh(petalGeo, petalMat, count * petalCountPerFlower);

  // 4. Contrasting bright center pistils
  const centerGeo = new THREE.SphereGeometry(0.048, 10, 8);
  centerGeo.scale(1, 0.65, 1);
  const centerMat = new THREE.MeshStandardMaterial({
    roughness: 0.48,
  });
  const centers = new THREE.InstancedMesh(centerGeo, centerMat, count);

  const vividPalette = [
    0xff2e7a, // Vivid Rose Pink
    0xffc300, // Brilliant Marigold Yellow
    0xef233c, // Rich Tulip Crimson
    0x8b5cf6, // Crisp Royal Violet
    0xff6b1a, // Bright Tangerine Pop
    0xec4899, // Vibrant Magenta
    0x38bdf8, // Sky Delphinium Blue
    0xffffff, // Crisp Daisy White
  ];
  const centerPalette = [0xfef08a, 0xea580c, 0xfde047, 0xfef9c3];

  const dummy = new THREE.Object3D();
  const petalCol = new THREE.Color();
  const centerCol = new THREE.Color();

  spots.forEach((spot, i) => {
    const sc = spot.scale;
    const stemH = 0.28 * sc;
    const tiltX = ((i % 5) - 2) * 0.05;
    const tiltZ = (((i * 3) % 5) - 2) * 0.05;

    // Stem
    dummy.position.set(spot.x, stemH * 0.5, spot.z);
    dummy.rotation.set(tiltX, 0, tiltZ);
    dummy.scale.setScalar(sc);
    dummy.updateMatrix();
    stems.setMatrixAt(i, dummy.matrix);

    // Two leaves sprouting from mid-stem
    for (let l = 0; l < 2; l++) {
      const side = l === 0 ? 1 : -1;
      const yaw = i * 0.9 + (l === 0 ? 0.3 : Math.PI + 0.3);
      dummy.position.set(
        spot.x + Math.cos(yaw) * 0.055 * sc,
        0.085 * sc,
        spot.z + Math.sin(yaw) * 0.055 * sc,
      );
      dummy.rotation.set(0.2 * side, -yaw, 0.32 * side);
      dummy.scale.setScalar(sc);
      dummy.updateMatrix();
      leaves.setMatrixAt(i * 2 + l, dummy.matrix);
    }

    // Blossom head tilted slightly forward toward camera so colors shine brightly!
    const headY = stemH + 0.015 * sc;
    const headRotX = 0.38 + (i % 3) * 0.08;
    const headYaw = i * 0.7;

    petalCol.setHex(vividPalette[spot.paletteIdx % vividPalette.length]);
    for (let p = 0; p < petalCountPerFlower; p++) {
      const a = (p / petalCountPerFlower) * Math.PI * 2 + headYaw;
      const r = 0.068 * sc;
      dummy.position.set(
        spot.x + Math.cos(a) * r,
        headY + Math.sin(a) * r * Math.sin(headRotX) * 0.5,
        spot.z + Math.sin(a) * r,
      );
      dummy.rotation.set(headRotX * Math.sin(a), -a, -headRotX * Math.cos(a) + 0.16);
      dummy.scale.setScalar(sc);
      dummy.updateMatrix();
      const idx = i * petalCountPerFlower + p;
      petals.setMatrixAt(idx, dummy.matrix);
      petals.setColorAt(idx, petalCol);
    }

    // Center pistil
    dummy.position.set(spot.x, headY + 0.018 * sc, spot.z + 0.015 * sc);
    dummy.rotation.set(headRotX, 0, 0);
    dummy.scale.setScalar(sc);
    dummy.updateMatrix();
    centers.setMatrixAt(i, dummy.matrix);
    centerCol.setHex(
      spot.paletteIdx % vividPalette.length === 1
        ? 0xd97706
        : centerPalette[i % centerPalette.length],
    );
    centers.setColorAt(i, centerCol);
  });

  [stems, leaves, petals, centers].forEach((m) => {
    m.instanceMatrix.needsUpdate = true;
    if (m.instanceColor) m.instanceColor.needsUpdate = true;
    m.computeBoundingSphere();
    m.castShadow = true;
    scene.add(m);
  });
}

export function buildShowcaseEnvironment(
  scene: THREE.Scene,
  textures: FurTextureSet,
): void {
  addVividSkyBackdrop(scene);

  // Ground meadow extending to horizon
  const meadow = new THREE.Mesh(
    new THREE.CircleGeometry(42, 48),
    new THREE.MeshStandardMaterial({
      map: textures.grassMap,
      roughness: 0.88,
      metalness: 0.0,
    }),
  );
  meadow.rotation.x = -Math.PI / 2;
  meadow.receiveShadow = true;
  scene.add(meadow);

  // Stone promenade path where pets walk left -> right (offset +0.015 on Y to avoid Z-fighting)
  const stonePath = new THREE.Mesh(
    new THREE.BoxGeometry(10.5, 0.04, 2.5),
    new THREE.MeshStandardMaterial({
      map: textures.stonePathMap,
      roughness: 0.82,
      metalness: 0.02,
    }),
  );
  stonePath.position.set(0, 0.015, 0.25);
  stonePath.receiveShadow = true;
  scene.add(stonePath);

  // Crisp warm cream garden fence in the background
  const fenceMat = new THREE.MeshStandardMaterial({color: 0xf4e4ce, roughness: 0.72});
  const fenceGroup = new THREE.Group();
  for (let x = -7; x <= 7; x += 1.4) {
    const post = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.95, 0.11), fenceMat);
    post.position.set(x, 0.47, -2.55);
    post.castShadow = true;
    fenceGroup.add(post);
  }
  for (const railY of [0.3, 0.68]) {
    const rail = new THREE.Mesh(new THREE.BoxGeometry(14.5, 0.08, 0.06), fenceMat);
    rail.position.set(0, railY, -2.55);
    rail.castShadow = true;
    fenceGroup.add(rail);
  }
  scene.add(fenceGroup);

  // Surrounding crisp green trees
  const treePositions: Array<[number, number, number]> = [
    [-5.8, -4.5, 1.15],
    [-2.5, -5.8, 1.3],
    [2.8, -5.4, 1.25],
    [6.1, -4.2, 1.1],
    [-7.2, -1.8, 0.95],
    [7.4, -1.6, 0.95],
  ];
  treePositions.forEach(([tx, tz, sc]) => {
    const t = createTreeGroup(sc);
    t.position.set(tx, 0, tz);
    scene.add(t);
  });

  // Lush, vivid sculpted 3D flower borders framing the path & fence!
  const flowerSpots: Array<{x: number; z: number; scale: number; paletteIdx: number}> = [];
  for (let i = 0; i < 120; i++) {
    const lane = i % 3;
    const fx = -5.6 + (i / 119) * 11.2 + Math.sin(i * 2.1) * 0.28;
    let fz: number;
    if (lane === 0) {
      // Directly behind promenade path (super crisp & prominent)
      fz = -1.15 - Math.abs(Math.cos(i * 1.7)) * 0.55;
    } else if (lane === 1) {
      // Along the wooden fence flowerbed
      fz = -1.95 - Math.abs(Math.sin(i * 2.3)) * 0.45;
    } else {
      // Foreground border along bottom edge of path
      fz = 1.62 + Math.abs(Math.sin(i * 1.3)) * 0.52;
    }
    flowerSpots.push({
      x: fx,
      z: fz,
      scale: 0.95 + (i % 4) * 0.18,
      paletteIdx: i,
    });
  }
  addLushFlowerBeds(scene, flowerSpots);
}

export interface GiftBoxRig {
  group: THREE.Group;
  parachute: THREE.Group;
  lid: THREE.Group;
  hitProxy: THREE.Mesh;
}

export interface FireworkSystem {
  points: THREE.Points;
  velocities: Float32Array;
  active: boolean;
  timer: number;
  burst: (origin: THREE.Vector3) => void;
  update: (dt: number) => void;
}

export interface CareEnvironmentHandles {
  foodBowlGroup: THREE.Group;
  kibbleGroup: THREE.Group;
  ballMesh: THREE.Mesh;
  giftBox: GiftBoxRig;
  fireworks: FireworkSystem;
  poopMarker: THREE.Group;
}

export function buildCareEnvironment(
  scene: THREE.Scene,
  textures: FurTextureSet,
): CareEnvironmentHandles {
  addVividSkyBackdrop(scene);

  // Outer sunlit lawn beyond patio
  const lawn = new THREE.Mesh(
    new THREE.CircleGeometry(35, 48),
    new THREE.MeshStandardMaterial({map: textures.grassMap, roughness: 0.88}),
  );
  lawn.rotation.x = -Math.PI / 2;
  lawn.position.y = -0.02;
  lawn.receiveShadow = true;
  scene.add(lawn);

  // Cozy sunlit oak patio floor
  const floor = new THREE.Mesh(
    new THREE.CylinderGeometry(5.6, 5.8, 0.06, 48),
    new THREE.MeshStandardMaterial({
      map: textures.woodFloorMap,
      roughness: 0.62,
      metalness: 0.04,
    }),
  );
  floor.position.y = -0.01;
  floor.receiveShadow = true;
  scene.add(floor);

  // Soft woven center rug (+0.024 offset above floor)
  const rug = new THREE.Mesh(
    new THREE.BoxGeometry(3.4, 0.025, 2.6),
    new THREE.MeshStandardMaterial({
      map: textures.rugMap,
      roughness: 0.94,
    }),
  );
  rug.position.set(0, 0.024, 0.15);
  rug.receiveShadow = true;
  scene.add(rug);

  // Sunlit backdrop wall with wide garden window arch
  const wallMat = new THREE.MeshStandardMaterial({color: 0xfdf7ee, roughness: 0.85});
  const backWallL = new THREE.Mesh(new THREE.BoxGeometry(2.8, 3.2, 0.16), wallMat);
  backWallL.position.set(-2.9, 1.6, -3.2);
  backWallL.receiveShadow = true;
  const backWallR = new THREE.Mesh(new THREE.BoxGeometry(2.8, 3.2, 0.16), wallMat);
  backWallR.position.set(2.9, 1.6, -3.2);
  backWallR.receiveShadow = true;
  const backWallTop = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.7, 0.16), wallMat);
  backWallTop.position.set(0, 2.85, -3.2);
  scene.add(backWallL, backWallR, backWallTop);

  // Trees & vivid garden flowerbed visible through the garden arch!
  for (const [tx, tz, sc] of [
    [-1.4, -5.4, 1.05],
    [1.3, -5.8, 1.15],
    [-4.8, -4.5, 1.2],
    [4.6, -4.2, 1.1],
  ]) {
    const t = createTreeGroup(sc);
    t.position.set(tx, 0, tz);
    scene.add(t);
  }

  const gardenFlowerSpots: Array<{x: number; z: number; scale: number; paletteIdx: number}> = [];
  for (let i = 0; i < 48; i++) {
    const fx = -2.2 + (i / 47) * 4.4;
    const fz = -3.65 - (i % 3) * 0.42;
    gardenFlowerSpots.push({
      x: fx,
      z: fz,
      scale: 1.05 + (i % 3) * 0.18,
      paletteIdx: i * 2,
    });
  }
  addLushFlowerBeds(scene, gardenFlowerSpots);

  // Cozy plush pet cushion bed on left-back
  const bedGroup = new THREE.Group();
  bedGroup.position.set(-1.65, 0.02, -1.25);
  const bedRim = new THREE.Mesh(
    new THREE.TorusGeometry(0.55, 0.14, 12, 24),
    new THREE.MeshStandardMaterial({color: 0xf5b971, roughness: 0.88}),
  );
  bedRim.rotation.x = Math.PI / 2;
  bedRim.position.y = 0.12;
  bedRim.castShadow = true;
  const bedCenter = new THREE.Mesh(
    new THREE.CylinderGeometry(0.5, 0.5, 0.1, 20),
    new THREE.MeshStandardMaterial({color: 0xfff3e0, roughness: 0.92}),
  );
  bedCenter.position.y = 0.06;
  bedGroup.add(bedRim, bedCenter);
  scene.add(bedGroup);

  // Wooden Wardrobe Cabinet prop on right-back
  const closet = new THREE.Group();
  closet.position.set(2.2, 0.02, -1.85);
  closet.rotation.y = -0.32;
  const cabinetBody = new THREE.Mesh(
    new THREE.BoxGeometry(0.95, 1.45, 0.45),
    new THREE.MeshStandardMaterial({color: 0xdcb488, roughness: 0.65}),
  );
  cabinetBody.position.y = 0.725;
  cabinetBody.castShadow = true;
  const cabinetTrim = new THREE.Mesh(
    new THREE.BoxGeometry(1.02, 0.08, 0.5),
    new THREE.MeshStandardMaterial({color: 0xc49566, roughness: 0.6}),
  );
  cabinetTrim.position.y = 1.47;
  closet.add(cabinetBody, cabinetTrim);
  scene.add(closet);

  // Ceramic Food & Water Bowls in front-right
  const foodBowlGroup = new THREE.Group();
  foodBowlGroup.position.set(1.15, 0.02, 0.85);
  const bowlGeo = new THREE.CylinderGeometry(0.24, 0.28, 0.12, 20, 1, true);
  const bowlMat = new THREE.MeshStandardMaterial({
    color: 0xf97316,
    roughness: 0.25,
    side: THREE.DoubleSide,
  });
  const bowlRim = new THREE.Mesh(bowlGeo, bowlMat);
  bowlRim.position.y = 0.06;
  bowlRim.castShadow = true;
  const bowlBase = new THREE.Mesh(
    new THREE.CylinderGeometry(0.24, 0.26, 0.04, 20),
    new THREE.MeshStandardMaterial({color: 0xfff7ed, roughness: 0.3}),
  );
  bowlBase.position.y = 0.02;
  foodBowlGroup.add(bowlRim, bowlBase);

  const kibbleGroup = new THREE.Group();
  const kibbleMat = new THREE.MeshStandardMaterial({color: 0x7c461f, roughness: 0.75});
  for (let i = 0; i < 14; i++) {
    const k = new THREE.Mesh(new THREE.SphereGeometry(0.032, 6, 6), kibbleMat);
    const ang = (i / 14) * Math.PI * 2;
    const rad = (i % 3) * 0.055 + 0.03;
    k.position.set(Math.cos(ang) * rad, 0.06 + (i % 2) * 0.015, Math.sin(ang) * rad);
    kibbleGroup.add(k);
  }
  foodBowlGroup.add(kibbleGroup);
  scene.add(foodBowlGroup);

  // Water bowl
  const waterBowl = new THREE.Group();
  waterBowl.position.set(1.75, 0.02, 0.78);
  const wRim = new THREE.Mesh(
    bowlGeo,
    new THREE.MeshStandardMaterial({color: 0x38bdf8, roughness: 0.22, side: THREE.DoubleSide}),
  );
  wRim.position.y = 0.06;
  const wSurface = new THREE.Mesh(
    new THREE.CircleGeometry(0.22, 20),
    new THREE.MeshStandardMaterial({color: 0xbae6fd, roughness: 0.1, metalness: 0.2}),
  );
  wSurface.rotation.x = -Math.PI / 2;
  wSurface.position.y = 0.075;
  waterBowl.add(wRim, wSurface);
  scene.add(waterBowl);

  // Playful colorful ball toy
  const ballMesh = new THREE.Mesh(
    new THREE.SphereGeometry(0.14, 18, 16),
    new THREE.MeshStandardMaterial({color: 0xef4444, roughness: 0.35}),
  );
  ballMesh.position.set(-1.1, 0.16, 0.9);
  ballMesh.castShadow = true;
  scene.add(ballMesh);

  // Potty indicator cushion/pad (appears when pet needs potty)
  const poopMarker = new THREE.Group();
  poopMarker.position.set(-1.25, 0.025, 0.2);
  const padMat = new THREE.MeshStandardMaterial({color: 0xe0f2fe, roughness: 0.8});
  const pad = new THREE.Mesh(new THREE.BoxGeometry(0.65, 0.015, 0.65), padMat);
  const padRing = new THREE.Mesh(
    new THREE.BoxGeometry(0.7, 0.01, 0.7),
    new THREE.MeshStandardMaterial({color: 0x38bdf8, roughness: 0.7}),
  );
  padRing.position.y = -0.004;
  poopMarker.add(pad, padRing);
  poopMarker.visible = false;
  scene.add(poopMarker);

  // Sky Gift Box (descends at 100 pts!)
  const giftGroup = new THREE.Group();
  giftGroup.position.set(0.65, 4.5, 0.65);
  giftGroup.visible = false;

  const boxMesh = new THREE.Mesh(
    new THREE.BoxGeometry(0.52, 0.44, 0.52),
    new THREE.MeshStandardMaterial({map: textures.giftWrapMap, roughness: 0.35}),
  );
  boxMesh.position.y = 0.22;
  boxMesh.castShadow = true;
  giftGroup.add(boxMesh);

  const ribbonMat = new THREE.MeshStandardMaterial({color: 0xe11d48, roughness: 0.3});
  const rib1 = new THREE.Mesh(new THREE.BoxGeometry(0.54, 0.45, 0.09), ribbonMat);
  rib1.position.y = 0.22;
  const rib2 = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.45, 0.54), ribbonMat);
  rib2.position.y = 0.22;
  giftGroup.add(rib1, rib2);

  const lid = new THREE.Group();
  lid.position.y = 0.44;
  const lidMesh = new THREE.Mesh(
    new THREE.BoxGeometry(0.56, 0.1, 0.56),
    new THREE.MeshStandardMaterial({color: 0xfda4af, roughness: 0.35}),
  );
  const bow = new THREE.Mesh(new THREE.TorusKnotGeometry(0.09, 0.025, 36, 8), ribbonMat);
  bow.position.y = 0.09;
  lid.add(lidMesh, bow);
  giftGroup.add(lid);

  const parachute = new THREE.Group();
  parachute.position.y = 0.9;
  const canopy = new THREE.Mesh(
    new THREE.SphereGeometry(0.45, 16, 12, 0, Math.PI * 2, 0, Math.PI * 0.5),
    new THREE.MeshStandardMaterial({color: 0xfef08a, roughness: 0.6, side: THREE.DoubleSide}),
  );
  parachute.add(canopy);
  for (const sx of [-0.3, 0.3]) {
    for (const sz of [-0.3, 0.3]) {
      const cord = new THREE.Mesh(
        new THREE.CylinderGeometry(0.006, 0.006, 0.55, 4),
        new THREE.MeshBasicMaterial({color: 0xfefefe}),
      );
      cord.position.set(sx * 0.5, -0.22, sz * 0.5);
      cord.rotation.z = sx * 0.45;
      cord.rotation.x = -sz * 0.45;
      parachute.add(cord);
    }
  }
  giftGroup.add(parachute);

  const giftHitProxy = new THREE.Mesh(
    new THREE.BoxGeometry(0.75, 0.85, 0.75),
    new THREE.MeshBasicMaterial({visible: false}),
  );
  giftHitProxy.position.y = 0.35;
  giftHitProxy.userData = {isGiftBox: true};
  giftGroup.add(giftHitProxy);
  scene.add(giftGroup);

  // 3D Fireworks Particle System
  const particleCount = 180;
  const positions = new Float32Array(particleCount * 3);
  const colors = new Float32Array(particleCount * 3);
  const velocities = new Float32Array(particleCount * 3);
  const fwGeo = new THREE.BufferGeometry();
  fwGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  fwGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  const fwMat = new THREE.PointsMaterial({
    size: 0.14,
    vertexColors: true,
    transparent: true,
    opacity: 0,
    depthWrite: false,
  });
  const fwPoints = new THREE.Points(fwGeo, fwMat);
  fwPoints.frustumCulled = false;
  scene.add(fwPoints);

  const fwColors = [0xf43f5e, 0xfbbf24, 0x38bdf8, 0xa855f7, 0x34d399];
  const tempCol = new THREE.Color();

  const fireworks: FireworkSystem = {
    points: fwPoints,
    velocities,
    active: false,
    timer: 0,
    burst(origin: THREE.Vector3) {
      this.active = true;
      this.timer = 0;
      fwMat.opacity = 1;
      const posAttr = fwGeo.attributes.position as THREE.BufferAttribute;
      const colAttr = fwGeo.attributes.color as THREE.BufferAttribute;
      for (let i = 0; i < particleCount; i++) {
        posAttr.setXYZ(i, origin.x, origin.y, origin.z);
        const theta = Math.random() * Math.PI * 2;
        const phi = Math.acos(2 * Math.random() - 1);
        const spd = 2.2 + Math.random() * 3.8;
        velocities[i * 3] = Math.sin(phi) * Math.cos(theta) * spd;
        velocities[i * 3 + 1] = Math.cos(phi) * spd + 1.8;
        velocities[i * 3 + 2] = Math.sin(phi) * Math.sin(theta) * spd;

        tempCol.setHex(fwColors[i % fwColors.length]);
        colAttr.setXYZ(i, tempCol.r, tempCol.g, tempCol.b);
      }
      posAttr.needsUpdate = true;
      colAttr.needsUpdate = true;
    },
    update(dt: number) {
      if (!this.active) return;
      this.timer += dt;
      const posAttr = fwGeo.attributes.position as THREE.BufferAttribute;
      for (let i = 0; i < particleCount; i++) {
        const vx = velocities[i * 3];
        const vy = velocities[i * 3 + 1] - 4.2 * dt;
        const vz = velocities[i * 3 + 2];
        velocities[i * 3 + 1] = vy;
        posAttr.setXYZ(
          i,
          posAttr.getX(i) + vx * dt,
          Math.max(0.05, posAttr.getY(i) + vy * dt),
          posAttr.getZ(i) + vz * dt,
        );
      }
      posAttr.needsUpdate = true;
      fwMat.opacity = Math.max(0, 1 - this.timer / 2.2);
      if (this.timer >= 2.2) {
        this.active = false;
      }
    },
  };

  return {
    foodBowlGroup,
    kibbleGroup,
    ballMesh,
    giftBox: {
      group: giftGroup,
      parachute,
      lid,
      hitProxy: giftHitProxy,
    },
    fireworks,
    poopMarker,
  };
}
