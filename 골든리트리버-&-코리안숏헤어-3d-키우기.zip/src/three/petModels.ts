import * as THREE from 'three';
import {PetExpressionMood, PetSpecies, WARDROBE_CATALOG} from '../types/pet';
import {FurTextureSet} from './furTextures';

export interface PetRig {
  species: PetSpecies;
  root: THREE.Group;        // Grounded at y = 0; controls world X/Z & heading Y
  rollGroup: THREE.Group;   // Centered around torso center for 360-degree barrel roll
  bodyGroup: THREE.Group;   // Spine/torso container
  neckPivot: THREE.Group;
  headGroup: THREE.Group;
  jawPivot: THREE.Group;
  earL: THREE.Group;
  earR: THREE.Group;
  tail1: THREE.Group;
  tail2: THREE.Group;
  tail3: THREE.Group;
  legFL: {hip: THREE.Group; knee: THREE.Group; paw: THREE.Group};
  legFR: {hip: THREE.Group; knee: THREE.Group; paw: THREE.Group};
  legBL: {hip: THREE.Group; knee: THREE.Group; paw: THREE.Group};
  legBR: {hip: THREE.Group; knee: THREE.Group; paw: THREE.Group};
  collarAnchor: THREE.Group;
  vestAnchor: THREE.Group;
  hatAnchor: THREE.Group;
  contactShadow: THREE.Mesh;
  coatMaterials: THREE.MeshStandardMaterial[];
  baseLegHeight: number;
  hitProxy: THREE.Mesh;
}

function createContactShadowTexture(): THREE.CanvasTexture {
  const c = document.createElement('canvas');
  c.width = 128;
  c.height = 128;
  const ctx = c.getContext('2d')!;
  const grad = ctx.createRadialGradient(64, 64, 6, 64, 64, 60);
  grad.addColorStop(0, 'rgba(20, 14, 8, 0.42)');
  grad.addColorStop(0.55, 'rgba(20, 14, 8, 0.18)');
  grad.addColorStop(1, 'rgba(20, 14, 8, 0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 128, 128);
  return new THREE.CanvasTexture(c);
}

let sharedShadowTex: THREE.CanvasTexture | null = null;
function getShadowTex(): THREE.CanvasTexture {
  if (!sharedShadowTex) sharedShadowTex = createContactShadowTexture();
  return sharedShadowTex;
}

function makeLatheTorso(
  radii: Array<[number, number]>,
  radialSegments = 20,
): THREE.BufferGeometry {
  const points = radii.map(([r, y]) => new THREE.Vector2(r, y));
  const geo = new THREE.LatheGeometry(points, radialSegments);
  // Rotate so length axis is along Z (+Z chest/front, -Z rump)
  geo.rotateX(Math.PI / 2);
  return geo;
}

function createLegRig(
  upperLen: number,
  upperRad: number,
  lowerLen: number,
  lowerRad: number,
  pawSize: THREE.Vector3,
  upperMat: THREE.Material,
  lowerMat: THREE.Material,
  pawMat: THREE.Material,
  padMat: THREE.Material,
): {hip: THREE.Group; knee: THREE.Group; paw: THREE.Group} {
  const hip = new THREE.Group();

  const upperGeo = new THREE.CapsuleGeometry(upperRad, Math.max(0.05, upperLen - upperRad * 1.4), 6, 12);
  const upperMesh = new THREE.Mesh(upperGeo, upperMat);
  upperMesh.position.y = -upperLen * 0.5;
  upperMesh.castShadow = true;
  upperMesh.receiveShadow = true;
  hip.add(upperMesh);

  const knee = new THREE.Group();
  knee.position.y = -upperLen;
  hip.add(knee);

  const lowerGeo = new THREE.CapsuleGeometry(lowerRad, Math.max(0.04, lowerLen - lowerRad * 1.2), 6, 12);
  const lowerMesh = new THREE.Mesh(lowerGeo, lowerMat);
  lowerMesh.position.y = -lowerLen * 0.5;
  lowerMesh.castShadow = true;
  lowerMesh.receiveShadow = true;
  knee.add(lowerMesh);

  const paw = new THREE.Group();
  paw.position.y = -lowerLen;
  knee.add(paw);

  const pawGeo = new THREE.SphereGeometry(1, 12, 10);
  pawGeo.scale(pawSize.x, pawSize.y, pawSize.z);
  const pawMesh = new THREE.Mesh(pawGeo, pawMat);
  pawMesh.position.set(0, pawSize.y * 0.45, pawSize.z * 0.28);
  pawMesh.castShadow = true;
  paw.add(pawMesh);

  // Sculpted toes & pink/dark paw pad underneath
  for (let t = -1; t <= 1; t++) {
    const toe = new THREE.Mesh(new THREE.SphereGeometry(pawSize.x * 0.34, 8, 8), pawMat);
    toe.scale.set(0.9, 0.75, 1.25);
    toe.position.set(t * pawSize.x * 0.48, pawSize.y * 0.35, pawSize.z * 0.95);
    paw.add(toe);
  }
  const pad = new THREE.Mesh(new THREE.SphereGeometry(pawSize.x * 0.55, 8, 6), padMat);
  pad.scale.set(1, 0.25, 1.1);
  pad.position.set(0, pawSize.y * 0.08, pawSize.z * 0.3);
  paw.add(pad);

  return {hip, knee, paw};
}

export function createGoldenRetrieverRig(
  textures: FurTextureSet,
  isSoftwareGl: boolean,
): PetRig {
  const root = new THREE.Group();
  const coatMaterials: THREE.MeshStandardMaterial[] = [];

  const mainFurMat = new THREE.MeshStandardMaterial({
    map: textures.goldenFurMap,
    bumpMap: textures.goldenFurBump,
    bumpScale: 0.015,
    color: new THREE.Color('#f4c474'),
    roughness: 0.78,
    metalness: 0.02,
  });
  const creamFurMat = new THREE.MeshStandardMaterial({
    map: textures.goldenFurMap,
    bumpMap: textures.goldenFurBump,
    bumpScale: 0.012,
    color: new THREE.Color('#fae0ad'),
    roughness: 0.82,
    metalness: 0.01,
  });
  const earFurMat = new THREE.MeshStandardMaterial({
    map: textures.goldenFurMap,
    color: new THREE.Color('#cf8a34'),
    roughness: 0.74,
    metalness: 0.02,
  });
  coatMaterials.push(mainFurMat, creamFurMat, earFurMat);

  const noseMat = isSoftwareGl
    ? new THREE.MeshStandardMaterial({color: 0x1b1614, roughness: 0.16, metalness: 0.05})
    : new THREE.MeshPhysicalMaterial({
        color: 0x1b1614,
        roughness: 0.16,
        metalness: 0.05,
        clearcoat: 0.9,
        clearcoatRoughness: 0.12,
      });
  const eyeMat = new THREE.MeshPhysicalMaterial({
    map: textures.dogEyeMap,
    roughness: 0.08,
    metalness: 0.0,
    clearcoat: isSoftwareGl ? 0.2 : 1.0,
    clearcoatRoughness: 0.05,
  });
  const mouthInnerMat = new THREE.MeshStandardMaterial({color: 0xd96b78, roughness: 0.45});
  const padMat = new THREE.MeshStandardMaterial({color: 0x3b2c25, roughness: 0.65});

  // Ground contact shadow
  const contactShadow = new THREE.Mesh(
    new THREE.PlaneGeometry(1.15, 1.45),
    new THREE.MeshBasicMaterial({
      map: getShadowTex(),
      transparent: true,
      depthWrite: false,
      opacity: 0.65,
    }),
  );
  contactShadow.rotation.x = -Math.PI / 2;
  contactShadow.position.y = 0.008;
  root.add(contactShadow);

  const baseLegHeight = 0.44;
  const rollGroup = new THREE.Group();
  rollGroup.position.y = baseLegHeight + 0.18;
  root.add(rollGroup);

  const bodyGroup = new THREE.Group();
  rollGroup.add(bodyGroup);

  // Sculpted Golden Retriever torso (chest -> waist -> haunches)
  const torsoGeo = makeLatheTorso(
    [
      [0.01, -0.46],
      [0.14, -0.4],
      [0.21, -0.22],
      [0.195, 0.0],
      [0.245, 0.22],
      [0.21, 0.38],
      [0.08, 0.45],
      [0.01, 0.46],
    ],
    22,
  );
  torsoGeo.scale(0.92, 1.05, 1.0);
  const torsoMesh = new THREE.Mesh(torsoGeo, mainFurMat);
  torsoMesh.castShadow = true;
  torsoMesh.receiveShadow = true;
  bodyGroup.add(torsoMesh);

  // Feathered cream chest ruff
  const chestRuffGeo = new THREE.SphereGeometry(0.21, 16, 14);
  chestRuffGeo.scale(0.9, 1.05, 0.85);
  const chestRuff = new THREE.Mesh(chestRuffGeo, creamFurMat);
  chestRuff.position.set(0, -0.02, 0.29);
  chestRuff.castShadow = true;
  bodyGroup.add(chestRuff);

  // Vest / Clothes wearable anchor on torso
  const vestAnchor = new THREE.Group();
  bodyGroup.add(vestAnchor);

  // Neck & Head
  const neckPivot = new THREE.Group();
  neckPivot.position.set(0, 0.12, 0.34);
  bodyGroup.add(neckPivot);

  const neckGeo = new THREE.CylinderGeometry(0.135, 0.175, 0.24, 16);
  const neckMesh = new THREE.Mesh(neckGeo, mainFurMat);
  neckMesh.position.set(0, 0.08, 0.05);
  neckMesh.rotation.x = 0.38;
  neckMesh.castShadow = true;
  neckPivot.add(neckMesh);

  // Collar wearable anchor on neck
  const collarAnchor = new THREE.Group();
  collarAnchor.position.set(0, 0.05, 0.04);
  collarAnchor.rotation.x = 0.35;
  neckPivot.add(collarAnchor);

  const headGroup = new THREE.Group();
  headGroup.position.set(0, 0.2, 0.12);
  neckPivot.add(headGroup);

  // Cranium (broad friendly Golden skull)
  const skullGeo = new THREE.SphereGeometry(0.195, 20, 16);
  skullGeo.scale(0.98, 0.94, 1.08);
  const skullMesh = new THREE.Mesh(skullGeo, mainFurMat);
  skullMesh.castShadow = true;
  headGroup.add(skullMesh);

  // Cheek fluff
  for (const side of [-1, 1]) {
    const cheek = new THREE.Mesh(new THREE.SphereGeometry(0.105, 12, 10), creamFurMat);
    cheek.scale.set(0.85, 0.8, 0.95);
    cheek.position.set(side * 0.11, -0.04, 0.04);
    headGroup.add(cheek);
  }

  // Upper muzzle (tapered snout)
  const muzzleGeo = new THREE.CylinderGeometry(0.072, 0.112, 0.2, 14);
  muzzleGeo.rotateX(Math.PI / 2);
  muzzleGeo.scale(1.0, 0.78, 1.0);
  const muzzleMesh = new THREE.Mesh(muzzleGeo, creamFurMat);
  muzzleMesh.position.set(0, -0.035, 0.2);
  muzzleMesh.castShadow = true;
  headGroup.add(muzzleMesh);

  // Soft brow stop
  const stopMesh = new THREE.Mesh(new THREE.SphereGeometry(0.088, 12, 10), mainFurMat);
  stopMesh.scale.set(1.05, 0.65, 0.9);
  stopMesh.position.set(0, 0.045, 0.155);
  headGroup.add(stopMesh);

  // Wet black nose
  const noseGeo = new THREE.SphereGeometry(0.046, 14, 12);
  noseGeo.scale(1.15, 0.85, 0.85);
  const noseMesh = new THREE.Mesh(noseGeo, noseMat);
  noseMesh.position.set(0, -0.005, 0.305);
  headGroup.add(noseMesh);

  // Animated lower jaw + tongue
  const jawPivot = new THREE.Group();
  jawPivot.position.set(0, -0.078, 0.09);
  headGroup.add(jawPivot);

  const lowerJawGeo = new THREE.CylinderGeometry(0.056, 0.085, 0.175, 12);
  lowerJawGeo.rotateX(Math.PI / 2);
  lowerJawGeo.scale(0.95, 0.55, 1.0);
  const lowerJaw = new THREE.Mesh(lowerJawGeo, creamFurMat);
  lowerJaw.position.set(0, -0.01, 0.095);
  jawPivot.add(lowerJaw);

  const tongueGeo = new THREE.CapsuleGeometry(0.028, 0.055, 6, 8);
  tongueGeo.rotateX(Math.PI / 2);
  tongueGeo.scale(1.15, 0.38, 1.0);
  const tongue = new THREE.Mesh(tongueGeo, mouthInnerMat);
  tongue.position.set(0, 0.012, 0.12);
  jawPivot.add(tongue);

  // Expressive eyes facing forward (+Z)
  for (const side of [-1, 1]) {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.035, 14, 12), eyeMat);
    eye.position.set(side * 0.078, 0.042, 0.168);
    // Rotate sphere so front of canvas texture faces +Z
    eye.rotation.y = -Math.PI / 2 + side * 0.12;
    headGroup.add(eye);
  }

  // Floppy feathered Golden Retriever ears
  const earShape = new THREE.Shape();
  earShape.moveTo(0, 0);
  earShape.quadraticCurveTo(0.11, -0.03, 0.12, -0.15);
  earShape.quadraticCurveTo(0.1, -0.25, 0.02, -0.24);
  earShape.quadraticCurveTo(-0.06, -0.2, -0.05, -0.06);
  earShape.closePath();

  const earGeo = new THREE.ExtrudeGeometry(earShape, {
    depth: 0.028,
    bevelEnabled: true,
    bevelSegments: 3,
    steps: 1,
    bevelSize: 0.014,
    bevelThickness: 0.014,
  });
  earGeo.center();

  const earL = new THREE.Group();
  earL.position.set(0.165, 0.085, -0.01);
  const earLMesh = new THREE.Mesh(earGeo, earFurMat);
  earLMesh.position.set(0.02, -0.1, 0.01);
  earLMesh.rotation.y = Math.PI / 2;
  earLMesh.rotation.z = -0.15;
  earLMesh.castShadow = true;
  earL.add(earLMesh);
  headGroup.add(earL);

  const earR = new THREE.Group();
  earR.position.set(-0.165, 0.085, -0.01);
  const earRMesh = new THREE.Mesh(earGeo, earFurMat);
  earRMesh.position.set(-0.02, -0.1, 0.01);
  earRMesh.rotation.y = -Math.PI / 2;
  earRMesh.rotation.z = 0.15;
  earRMesh.castShadow = true;
  earR.add(earRMesh);
  headGroup.add(earR);

  // Hat wearable anchor on top of head
  const hatAnchor = new THREE.Group();
  hatAnchor.position.set(0, 0.175, 0.0);
  headGroup.add(hatAnchor);

  // Feathered 3-segment tail
  const tail1 = new THREE.Group();
  tail1.position.set(0, 0.09, -0.41);
  bodyGroup.add(tail1);

  const t1Mesh = new THREE.Mesh(new THREE.CapsuleGeometry(0.05, 0.15, 6, 10), mainFurMat);
  t1Mesh.rotation.x = -Math.PI / 2.4;
  t1Mesh.position.set(0, 0.03, -0.09);
  t1Mesh.castShadow = true;
  tail1.add(t1Mesh);

  const tail2 = new THREE.Group();
  tail2.position.set(0, 0.06, -0.18);
  tail1.add(tail2);
  const t2Mesh = new THREE.Mesh(new THREE.CapsuleGeometry(0.044, 0.16, 6, 10), creamFurMat);
  t2Mesh.rotation.x = -Math.PI / 2.6;
  t2Mesh.position.set(0, 0.04, -0.09);
  t2Mesh.castShadow = true;
  tail2.add(t2Mesh);

  const tail3 = new THREE.Group();
  tail3.position.set(0, 0.07, -0.17);
  tail2.add(tail3);
  const t3Mesh = new THREE.Mesh(new THREE.CapsuleGeometry(0.034, 0.14, 6, 10), creamFurMat);
  t3Mesh.rotation.x = -Math.PI / 3;
  t3Mesh.position.set(0, 0.05, -0.07);
  t3Mesh.castShadow = true;
  tail3.add(t3Mesh);

  // 4 Articulated legs
  const legFL = createLegRig(0.22, 0.062, 0.21, 0.046, new THREE.Vector3(0.055, 0.038, 0.072), mainFurMat, creamFurMat, creamFurMat, padMat);
  legFL.hip.position.set(0.13, -0.04, 0.25);
  bodyGroup.add(legFL.hip);

  const legFR = createLegRig(0.22, 0.062, 0.21, 0.046, new THREE.Vector3(0.055, 0.038, 0.072), mainFurMat, creamFurMat, creamFurMat, padMat);
  legFR.hip.position.set(-0.13, -0.04, 0.25);
  bodyGroup.add(legFR.hip);

  const legBL = createLegRig(0.23, 0.072, 0.21, 0.046, new THREE.Vector3(0.055, 0.038, 0.074), mainFurMat, creamFurMat, creamFurMat, padMat);
  legBL.hip.position.set(0.135, -0.03, -0.26);
  bodyGroup.add(legBL.hip);

  const legBR = createLegRig(0.23, 0.072, 0.21, 0.046, new THREE.Vector3(0.055, 0.038, 0.074), mainFurMat, creamFurMat, creamFurMat, padMat);
  legBR.hip.position.set(-0.135, -0.03, -0.26);
  bodyGroup.add(legBR.hip);

  // Invisible hit proxy for smooth pointer/touch raycasting
  const hitProxy = new THREE.Mesh(
    new THREE.BoxGeometry(0.68, 0.95, 1.18),
    new THREE.MeshBasicMaterial({visible: false}),
  );
  hitProxy.position.set(0, 0.48, 0.04);
  hitProxy.userData = {petSpecies: 'golden_retriever'};
  root.add(hitProxy);

  return {
    species: 'golden_retriever',
    root,
    rollGroup,
    bodyGroup,
    neckPivot,
    headGroup,
    jawPivot,
    earL,
    earR,
    tail1,
    tail2,
    tail3,
    legFL,
    legFR,
    legBL,
    legBR,
    collarAnchor,
    vestAnchor,
    hatAnchor,
    contactShadow,
    coatMaterials,
    baseLegHeight,
    hitProxy,
  };
}

export function createKoreanShorthairRig(
  textures: FurTextureSet,
  isSoftwareGl: boolean,
): PetRig {
  const root = new THREE.Group();
  const coatMaterials: THREE.MeshStandardMaterial[] = [];

  const tabbyMat = new THREE.MeshStandardMaterial({
    map: textures.tabbyFurMap,
    bumpMap: textures.tabbyFurBump,
    bumpScale: 0.008,
    color: new THREE.Color('#f4c48a'),
    roughness: 0.68,
    metalness: 0.02,
  });
  const headTabbyMat = new THREE.MeshStandardMaterial({
    map: textures.tabbyHeadMap,
    bumpMap: textures.tabbyFurBump,
    bumpScale: 0.008,
    color: new THREE.Color('#f7cca0'),
    roughness: 0.66,
    metalness: 0.02,
  });
  const whiteFurMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#fbf7f0'),
    roughness: 0.72,
    metalness: 0.01,
  });
  coatMaterials.push(tabbyMat, headTabbyMat, whiteFurMat);

  const pinkNoseMat = isSoftwareGl
    ? new THREE.MeshStandardMaterial({color: 0xe68894, roughness: 0.25})
    : new THREE.MeshPhysicalMaterial({
        color: 0xe68894,
        roughness: 0.22,
        clearcoat: 0.75,
        clearcoatRoughness: 0.18,
      });
  const innerEarMat = new THREE.MeshStandardMaterial({color: 0xf0b2b8, roughness: 0.7});
  const eyeMat = new THREE.MeshPhysicalMaterial({
    map: textures.catEyeMap,
    roughness: 0.06,
    metalness: 0.0,
    clearcoat: isSoftwareGl ? 0.2 : 1.0,
    clearcoatRoughness: 0.04,
  });
  const padMat = new THREE.MeshStandardMaterial({color: 0xec9ca4, roughness: 0.55});

  const contactShadow = new THREE.Mesh(
    new THREE.PlaneGeometry(0.85, 1.05),
    new THREE.MeshBasicMaterial({
      map: getShadowTex(),
      transparent: true,
      depthWrite: false,
      opacity: 0.6,
    }),
  );
  contactShadow.rotation.x = -Math.PI / 2;
  contactShadow.position.y = 0.008;
  root.add(contactShadow);

  const baseLegHeight = 0.34;
  const rollGroup = new THREE.Group();
  rollGroup.position.y = baseLegHeight + 0.13;
  root.add(rollGroup);

  const bodyGroup = new THREE.Group();
  rollGroup.add(bodyGroup);

  // Lithe Korean Shorthair feline torso
  const torsoGeo = makeLatheTorso(
    [
      [0.01, -0.36],
      [0.105, -0.3],
      [0.145, -0.14],
      [0.13, 0.04],
      [0.145, 0.2],
      [0.125, 0.31],
      [0.05, 0.35],
      [0.01, 0.36],
    ],
    20,
  );
  torsoGeo.scale(0.88, 1.02, 1.0);
  const torsoMesh = new THREE.Mesh(torsoGeo, tabbyMat);
  torsoMesh.castShadow = true;
  torsoMesh.receiveShadow = true;
  bodyGroup.add(torsoMesh);

  // White chest bib
  const bibMesh = new THREE.Mesh(new THREE.SphereGeometry(0.115, 14, 12), whiteFurMat);
  bibMesh.scale.set(0.82, 1.08, 0.75);
  bibMesh.position.set(0, -0.02, 0.25);
  bodyGroup.add(bibMesh);

  const vestAnchor = new THREE.Group();
  vestAnchor.scale.setScalar(0.68);
  bodyGroup.add(vestAnchor);

  // Graceful neck & feline head
  const neckPivot = new THREE.Group();
  neckPivot.position.set(0, 0.09, 0.27);
  bodyGroup.add(neckPivot);

  const neckMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.088, 0.115, 0.17, 14), tabbyMat);
  neckMesh.position.set(0, 0.06, 0.03);
  neckMesh.rotation.x = 0.3;
  neckMesh.castShadow = true;
  neckPivot.add(neckMesh);

  const collarAnchor = new THREE.Group();
  collarAnchor.position.set(0, 0.035, 0.025);
  collarAnchor.rotation.x = 0.28;
  collarAnchor.scale.setScalar(0.68);
  neckPivot.add(collarAnchor);

  const headGroup = new THREE.Group();
  headGroup.position.set(0, 0.155, 0.085);
  neckPivot.add(headGroup);

  const skullGeo = new THREE.SphereGeometry(0.145, 20, 16);
  skullGeo.scale(1.06, 0.94, 0.98);
  const skullMesh = new THREE.Mesh(skullGeo, headTabbyMat);
  skullMesh.rotation.y = Math.PI / 2; // Align forehead 'M' canvas zone to +Z
  skullMesh.castShadow = true;
  headGroup.add(skullMesh);

  // Fluffy whisker pads & short delicate feline muzzle
  for (const side of [-1, 1]) {
    const pad = new THREE.Mesh(new THREE.SphereGeometry(0.044, 10, 10), whiteFurMat);
    pad.scale.set(1.0, 0.85, 0.9);
    pad.position.set(side * 0.035, -0.042, 0.122);
    headGroup.add(pad);

    // 3 fine 3D whiskers per side
    const whiskerMat = new THREE.MeshBasicMaterial({color: 0xfefcf8});
    for (let w = -1; w <= 1; w++) {
      const whisker = new THREE.Mesh(new THREE.CylinderGeometry(0.0022, 0.001, 0.13, 4), whiskerMat);
      whisker.rotation.z = side * (Math.PI / 2 - 0.14 + w * 0.12);
      whisker.rotation.y = side * 0.22;
      whisker.position.set(side * 0.088, -0.038 + w * 0.012, 0.12);
      headGroup.add(whisker);
    }
  }

  // Pink triangular cat nose
  const noseMesh = new THREE.Mesh(new THREE.SphereGeometry(0.022, 10, 10), pinkNoseMat);
  noseMesh.scale.set(1.15, 0.85, 0.75);
  noseMesh.position.set(0, -0.018, 0.156);
  headGroup.add(noseMesh);

  // Animated lower chin/jaw
  const jawPivot = new THREE.Group();
  jawPivot.position.set(0, -0.065, 0.075);
  headGroup.add(jawPivot);
  const chinMesh = new THREE.Mesh(new THREE.SphereGeometry(0.042, 10, 8), whiteFurMat);
  chinMesh.scale.set(1.1, 0.55, 1.0);
  chinMesh.position.set(0, -0.005, 0.042);
  jawPivot.add(chinMesh);

  // Large vivid feline eyes
  for (const side of [-1, 1]) {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.033, 14, 12), eyeMat);
    eye.scale.set(1.05, 0.96, 0.85);
    eye.position.set(side * 0.064, 0.02, 0.124);
    eye.rotation.y = -Math.PI / 2 + side * 0.18;
    headGroup.add(eye);
  }

  // Pointed upright Korean Shorthair ears with pink inner pinna
  const catEarGeo = new THREE.ConeGeometry(0.062, 0.135, 4);
  catEarGeo.rotateY(Math.PI / 4);
  catEarGeo.scale(1.0, 1.0, 0.55);

  const innerEarGeo = new THREE.ConeGeometry(0.04, 0.095, 4);
  innerEarGeo.rotateY(Math.PI / 4);
  innerEarGeo.scale(1.0, 1.0, 0.45);

  const earL = new THREE.Group();
  earL.position.set(0.088, 0.115, 0.0);
  earL.rotation.z = -0.24;
  earL.rotation.x = 0.08;
  const earLOuter = new THREE.Mesh(catEarGeo, tabbyMat);
  earLOuter.position.y = 0.055;
  earLOuter.castShadow = true;
  const earLInner = new THREE.Mesh(innerEarGeo, innerEarMat);
  earLInner.position.set(0, 0.045, 0.012);
  earL.add(earLOuter, earLInner);
  headGroup.add(earL);

  const earR = new THREE.Group();
  earR.position.set(-0.088, 0.115, 0.0);
  earR.rotation.z = 0.24;
  earR.rotation.x = 0.08;
  const earROuter = new THREE.Mesh(catEarGeo, tabbyMat);
  earROuter.position.y = 0.055;
  earROuter.castShadow = true;
  const earRInner = new THREE.Mesh(innerEarGeo, innerEarMat);
  earRInner.position.set(0, 0.045, 0.012);
  earR.add(earROuter, earRInner);
  headGroup.add(earR);

  const hatAnchor = new THREE.Group();
  hatAnchor.position.set(0, 0.13, 0.0);
  hatAnchor.scale.setScalar(0.75);
  headGroup.add(hatAnchor);

  // Long expressive 3-segment feline tail
  const tail1 = new THREE.Group();
  tail1.position.set(0, 0.06, -0.32);
  bodyGroup.add(tail1);
  const t1 = new THREE.Mesh(new THREE.CapsuleGeometry(0.032, 0.15, 6, 10), tabbyMat);
  t1.rotation.x = -Math.PI / 4;
  t1.position.set(0, 0.06, -0.06);
  t1.castShadow = true;
  tail1.add(t1);

  const tail2 = new THREE.Group();
  tail2.position.set(0, 0.12, -0.12);
  tail1.add(tail2);
  const t2 = new THREE.Mesh(new THREE.CapsuleGeometry(0.028, 0.15, 6, 10), tabbyMat);
  t2.rotation.x = -Math.PI / 8;
  t2.position.set(0, 0.08, -0.02);
  t2.castShadow = true;
  tail2.add(t2);

  const tail3 = new THREE.Group();
  tail3.position.set(0, 0.16, -0.04);
  tail2.add(tail3);
  const t3 = new THREE.Mesh(new THREE.CapsuleGeometry(0.024, 0.12, 6, 10), whiteFurMat);
  t3.rotation.x = 0.25;
  t3.position.set(0, 0.06, 0.02);
  t3.castShadow = true;
  tail3.add(t3);

  // 4 Sleek feline legs with white socks
  const legFL = createLegRig(0.17, 0.042, 0.16, 0.032, new THREE.Vector3(0.04, 0.028, 0.052), tabbyMat, whiteFurMat, whiteFurMat, padMat);
  legFL.hip.position.set(0.09, -0.025, 0.2);
  bodyGroup.add(legFL.hip);

  const legFR = createLegRig(0.17, 0.042, 0.16, 0.032, new THREE.Vector3(0.04, 0.028, 0.052), tabbyMat, whiteFurMat, whiteFurMat, padMat);
  legFR.hip.position.set(-0.09, -0.025, 0.2);
  bodyGroup.add(legFR.hip);

  const legBL = createLegRig(0.18, 0.052, 0.16, 0.034, new THREE.Vector3(0.04, 0.028, 0.055), tabbyMat, whiteFurMat, whiteFurMat, padMat);
  legBL.hip.position.set(0.095, -0.02, -0.2);
  bodyGroup.add(legBL.hip);

  const legBR = createLegRig(0.18, 0.052, 0.16, 0.034, new THREE.Vector3(0.04, 0.028, 0.055), tabbyMat, whiteFurMat, whiteFurMat, padMat);
  legBR.hip.position.set(-0.095, -0.02, -0.2);
  bodyGroup.add(legBR.hip);

  const hitProxy = new THREE.Mesh(
    new THREE.BoxGeometry(0.55, 0.78, 0.96),
    new THREE.MeshBasicMaterial({visible: false}),
  );
  hitProxy.position.set(0, 0.39, 0.02);
  hitProxy.userData = {petSpecies: 'korean_shorthair'};
  root.add(hitProxy);

  return {
    species: 'korean_shorthair',
    root,
    rollGroup,
    bodyGroup,
    neckPivot,
    headGroup,
    jawPivot,
    earL,
    earR,
    tail1,
    tail2,
    tail3,
    legFL,
    legFR,
    legBL,
    legBR,
    collarAnchor,
    vestAnchor,
    hatAnchor,
    contactShadow,
    coatMaterials,
    baseLegHeight,
    hitProxy,
  };
}

function clearGroup(group: THREE.Group) {
  while (group.children.length > 0) {
    const child = group.children[0];
    group.remove(child);
    child.traverse((obj) => {
      if ((obj as THREE.Mesh).isMesh) {
        (obj as THREE.Mesh).geometry?.dispose();
        const mat = (obj as THREE.Mesh).material;
        if (Array.isArray(mat)) mat.forEach((m) => m.dispose());
        else mat?.dispose();
      }
    });
  }
}

export function applyWardrobeToPet(
  rig: PetRig,
  clothesId: string | null,
  accessoryId: string | null,
): void {
  clearGroup(rig.vestAnchor);
  clearGroup(rig.collarAnchor);
  clearGroup(rig.hatAnchor);

  const clothes = WARDROBE_CATALOG.find((i) => i.id === clothesId);
  const accessory = WARDROBE_CATALOG.find((i) => i.id === accessoryId);

  if (clothes) {
    const cMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(clothes.primaryColor),
      roughness: 0.65,
      metalness: 0.05,
    });
    const trimMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(clothes.secondaryColor),
      roughness: 0.45,
      metalness: 0.15,
    });

    if (clothes.styleType === 'ribbon_scarf') {
      const band = new THREE.Mesh(new THREE.TorusGeometry(0.185, 0.032, 10, 24), cMat);
      band.position.set(0, 0.11, 0.34);
      band.rotation.x = Math.PI / 2 - 0.35;
      rig.vestAnchor.add(band);

      const knot = new THREE.Mesh(new THREE.SphereGeometry(0.042, 10, 10), trimMat);
      knot.position.set(0, 0.01, 0.51);
      rig.vestAnchor.add(knot);

      for (const side of [-1, 1]) {
        const loop = new THREE.Mesh(new THREE.ConeGeometry(0.042, 0.09, 8), cMat);
        loop.position.set(side * 0.05, 0.0, 0.51);
        loop.rotation.z = side * (Math.PI / 2 - 0.2);
        rig.vestAnchor.add(loop);
      }
    } else if (clothes.styleType === 'yellow_raincoat' || clothes.styleType === 'denim_vest') {
      const vestGeo = new THREE.CylinderGeometry(0.242, 0.215, 0.44, 18, 1, true, -Math.PI * 0.72, Math.PI * 1.44);
      vestGeo.rotateX(Math.PI / 2);
      const vest = new THREE.Mesh(vestGeo, cMat);
      vest.material.side = THREE.DoubleSide;
      vest.position.set(0, 0.03, 0.02);
      vest.castShadow = true;
      rig.vestAnchor.add(vest);

      // Collar trim & back pocket / stripe
      const trim = new THREE.Mesh(new THREE.TorusGeometry(0.215, 0.02, 8, 22), trimMat);
      trim.position.set(0, 0.04, 0.24);
      rig.vestAnchor.add(trim);

      const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.02, 0.24), trimMat);
      stripe.position.set(0, 0.24, 0.0);
      rig.vestAnchor.add(stripe);
    } else if (clothes.styleType === 'royal_cape') {
      const capeGeo = new THREE.CylinderGeometry(0.18, 0.32, 0.56, 18, 1, true, Math.PI * 0.55, Math.PI * 0.9);
      capeGeo.rotateX(Math.PI / 2);
      const cape = new THREE.Mesh(capeGeo, cMat);
      cape.material.side = THREE.DoubleSide;
      cape.position.set(0, 0.08, -0.03);
      cape.castShadow = true;
      rig.vestAnchor.add(cape);

      const goldClasp = new THREE.Mesh(new THREE.TorusGeometry(0.185, 0.026, 8, 22), trimMat);
      goldClasp.position.set(0, 0.09, 0.26);
      goldClasp.rotation.x = Math.PI / 2 - 0.3;
      rig.vestAnchor.add(goldClasp);
    }
  }

  if (accessory) {
    const aMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(accessory.primaryColor),
      roughness: 0.42,
      metalness: 0.25,
    });
    const gemMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(accessory.secondaryColor),
      roughness: 0.15,
      metalness: 0.85,
    });

    if (accessory.styleType === 'flower_crown') {
      const ring = new THREE.Mesh(
        new THREE.TorusGeometry(0.125, 0.015, 8, 24),
        new THREE.MeshStandardMaterial({color: 0x3f8f4e, roughness: 0.65}),
      );
      ring.rotation.x = Math.PI / 2;
      rig.hatAnchor.add(ring);

      for (let i = 0; i < 6; i++) {
        const ang = (i / 6) * Math.PI * 2;
        const flower = new THREE.Mesh(
          new THREE.DodecahedronGeometry(0.032, 0),
          i % 2 === 0 ? aMat : gemMat,
        );
        flower.position.set(Math.cos(ang) * 0.125, 0.015, Math.sin(ang) * 0.125);
        rig.hatAnchor.add(flower);
      }
    } else if (accessory.styleType === 'pearl_necklace') {
      for (let i = 0; i < 12; i++) {
        const ang = (i / 12) * Math.PI * 2;
        const pearl = new THREE.Mesh(
          new THREE.SphereGeometry(0.024, 10, 10),
          new THREE.MeshStandardMaterial({color: 0xfefcf9, roughness: 0.18, metalness: 0.2}),
        );
        pearl.position.set(Math.cos(ang) * 0.168, 0, Math.sin(ang) * 0.168);
        rig.collarAnchor.add(pearl);
      }
      const heart = new THREE.Mesh(new THREE.OctahedronGeometry(0.036, 0), gemMat);
      heart.position.set(0, -0.03, 0.185);
      rig.collarAnchor.add(heart);
    } else {
      // bell_collar or leather_tag
      const strap = new THREE.Mesh(new THREE.TorusGeometry(0.165, 0.022, 8, 24), aMat);
      strap.rotation.x = Math.PI / 2;
      rig.collarAnchor.add(strap);

      const pendant = new THREE.Mesh(
        accessory.styleType === 'bell_collar'
          ? new THREE.SphereGeometry(0.038, 12, 12)
          : new THREE.CylinderGeometry(0.036, 0.036, 0.012, 16),
        gemMat,
      );
      pendant.position.set(0, -0.025, 0.175);
      if (accessory.styleType === 'leather_tag') {
        pendant.rotation.x = Math.PI / 2;
      }
      rig.collarAnchor.add(pendant);
    }
  }
}

export interface PetPlayMotion {
  jumpY?: number;        // Vertical jump arc height (0..)
  playBow?: number;      // 0..1 Golden Retriever playful bow
  pounceCrouch?: number; // 0..1 Korean Shorthair agile crouch before leap
  pawBat?: number;       // 0..1 Playful front paw swatting/batting
  lookYaw?: number;      // Curious head turn offset
  spinRoll?: number;     // Playful torso tilt/lean while turning
}

export function updatePetGrowthAndPose(
  rig: PetRig,
  maturity: number, // 0 (puppy/kitten) -> 1 (adult)
  gaitSpeed: number, // 0 = standing, 0.5 = walk, 1.0+ = run
  gaitPhase: number,
  mood: PetExpressionMood,
  time: number,
  rollProgress: number, // 0 = none, 0..1 = barrel roll progress
  healthFactor: number, // 0.3..1.0 (low if meals missed!)
  extraMotion?: PetPlayMotion,
): void {
  const m = THREE.MathUtils.clamp(maturity, 0, 1);

  // Puppy/Kitten -> Adult morphological scaling:
  // Young animals have smaller bodies, shorter legs, and proportionally larger heads!
  const overallScale = THREE.MathUtils.lerp(0.56, 1.04, m) * THREE.MathUtils.lerp(0.86, 1.0, healthFactor);
  const headGrowthCompensation = THREE.MathUtils.lerp(1.26, 1.0, m);

  rig.root.scale.setScalar(overallScale);
  rig.headGroup.scale.setScalar(headGrowthCompensation);

  // Coat luster responds to nutrition/health
  rig.coatMaterials.forEach((mat) => {
    mat.roughness = THREE.MathUtils.lerp(0.92, rig.species === 'golden_retriever' ? 0.76 : 0.66, healthFactor);
  });

  const jumpY = Math.max(0, extraMotion?.jumpY ?? 0);
  const playBow = THREE.MathUtils.clamp(extraMotion?.playBow ?? 0, 0, 1);
  const pounceCrouch = THREE.MathUtils.clamp(extraMotion?.pounceCrouch ?? 0, 0, 1);
  const pawBat = THREE.MathUtils.clamp(extraMotion?.pawBat ?? 0, 0, 1);
  const lookYaw = extraMotion?.lookYaw ?? 0;
  const spinRoll = extraMotion?.spinRoll ?? 0;

  // Dynamic ground contact shadow shrinks/fades as pet jumps higher
  const shadowScale = Math.max(0.45, 1 - jumpY * 0.42);
  rig.contactShadow.scale.setScalar(shadowScale);
  const shadowMat = rig.contactShadow.material as THREE.MeshBasicMaterial;
  shadowMat.opacity = Math.max(0.18, (rig.species === 'golden_retriever' ? 0.65 : 0.6) - jumpY * 0.35);

  // Reset base transforms
  rig.rollGroup.rotation.set(0, 0, spinRoll);
  rig.rollGroup.position.y = rig.baseLegHeight + 0.16 + jumpY;
  rig.bodyGroup.position.set(0, 0, 0);
  rig.bodyGroup.rotation.set(0, 0, 0);
  rig.neckPivot.rotation.set(0, 0, 0);
  rig.headGroup.rotation.set(0, 0, 0);
  rig.jawPivot.rotation.set(0, 0, 0);
  rig.earL.rotation.set(0, 0, rig.species === 'korean_shorthair' ? -0.24 : 0);
  rig.earR.rotation.set(0, 0, rig.species === 'korean_shorthair' ? 0.24 : 0);
  rig.tail1.rotation.set(0, 0, 0);
  rig.tail2.rotation.set(0, 0, 0);
  rig.tail3.rotation.set(0, 0, 0);

  // 1. Barrel Roll animation when touched! (Req 4)
  if (rollProgress > 0 && rollProgress < 1) {
    const arch = Math.sin(rollProgress * Math.PI);
    rig.rollGroup.position.y = rig.baseLegHeight * 0.42 + arch * 0.32;
    rig.rollGroup.rotation.z = rollProgress * Math.PI * 2;
    rig.rollGroup.rotation.x = Math.sin(rollProgress * Math.PI * 2) * 0.22;

    // Playful curled paws while rolling
    rig.legFL.hip.rotation.x = -0.8;
    rig.legFR.hip.rotation.x = -0.7;
    rig.legBL.hip.rotation.x = 0.7;
    rig.legBR.hip.rotation.x = 0.8;
    rig.legFL.knee.rotation.x = 1.1;
    rig.legFR.knee.rotation.x = 1.1;
    rig.legBL.knee.rotation.x = -0.9;
    rig.legBR.knee.rotation.x = -0.9;
    rig.jawPivot.rotation.x = 0.28;
    rig.tail1.rotation.y = Math.sin(time * 18) * 0.5;
    return;
  }

  // 2. Locomotion gait (Dog: bounding gallop/trot; Cat: sleek agile trot/spring)
  const strideAmp = THREE.MathUtils.clamp(gaitSpeed, 0, 1.4) * 0.52;
  const bounce = Math.abs(Math.sin(gaitPhase)) * strideAmp * 0.14;
  rig.bodyGroup.position.y = bounce;

  if (jumpY > 0.06) {
    // Mid-air joyful leap pose!
    const airFactor = Math.min(1, jumpY * 1.8);
    if (rig.species === 'golden_retriever') {
      // Dog bounds with outstretched happy front paws & trailing hind legs
      rig.legFL.hip.rotation.x = -0.68 * airFactor;
      rig.legFR.hip.rotation.x = -0.56 * airFactor;
      rig.legBL.hip.rotation.x = 0.62 * airFactor;
      rig.legBR.hip.rotation.x = 0.52 * airFactor;
      rig.legFL.knee.rotation.x = 0.35 * airFactor;
      rig.legFR.knee.rotation.x = 0.35 * airFactor;
      rig.legBL.knee.rotation.x = -0.25 * airFactor;
      rig.legBR.knee.rotation.x = -0.25 * airFactor;
      rig.bodyGroup.rotation.x = -0.18 * airFactor;
      rig.earL.rotation.z = -0.35 * airFactor;
      rig.earR.rotation.z = 0.35 * airFactor;
    } else {
      // Cat springs with arched back & tucked nimble paws
      rig.legFL.hip.rotation.x = -0.82 * airFactor;
      rig.legFR.hip.rotation.x = -0.78 * airFactor;
      rig.legBL.hip.rotation.x = 0.72 * airFactor;
      rig.legBR.hip.rotation.x = 0.68 * airFactor;
      rig.legFL.knee.rotation.x = 0.95 * airFactor;
      rig.legFR.knee.rotation.x = 0.95 * airFactor;
      rig.legBL.knee.rotation.x = -0.8 * airFactor;
      rig.legBR.knee.rotation.x = -0.8 * airFactor;
      rig.bodyGroup.rotation.x = -0.14 * airFactor;
      rig.tail1.rotation.x = 0.45 * airFactor;
    }
  } else if (gaitSpeed > 0.04) {
    if (rig.species === 'golden_retriever' && gaitSpeed > 0.8) {
      // Energetic canine bounding gallop (front pair together, back pair together)
      const f = Math.sin(gaitPhase) * strideAmp;
      const b = Math.sin(gaitPhase + Math.PI * 0.72) * strideAmp;
      rig.legFL.hip.rotation.x = f;
      rig.legFR.hip.rotation.x = f * 0.92 + 0.08;
      rig.legBL.hip.rotation.x = b;
      rig.legBR.hip.rotation.x = b * 0.92 - 0.08;

      rig.legFL.knee.rotation.x = Math.max(0, -f) * 0.95;
      rig.legFR.knee.rotation.x = Math.max(0, -f) * 0.9;
      rig.legBL.knee.rotation.x = -Math.max(0, b) * 0.8;
      rig.legBR.knee.rotation.x = -Math.max(0, b) * 0.75;

      rig.bodyGroup.rotation.x = Math.sin(gaitPhase) * 0.11;
      rig.earL.rotation.z = -Math.max(0, Math.sin(gaitPhase)) * 0.28;
      rig.earR.rotation.z = Math.max(0, Math.sin(gaitPhase)) * 0.28;
    } else {
      const fl = Math.sin(gaitPhase) * strideAmp;
      const fr = Math.sin(gaitPhase + Math.PI) * strideAmp;
      const bl = Math.sin(gaitPhase + Math.PI * 0.85) * strideAmp;
      const br = Math.sin(gaitPhase - Math.PI * 0.15) * strideAmp;

      rig.legFL.hip.rotation.x = fl;
      rig.legFR.hip.rotation.x = fr;
      rig.legBL.hip.rotation.x = bl;
      rig.legBR.hip.rotation.x = br;

      rig.legFL.knee.rotation.x = Math.max(0, -fl) * 0.9;
      rig.legFR.knee.rotation.x = Math.max(0, -fr) * 0.9;
      rig.legBL.knee.rotation.x = -Math.max(0, bl) * 0.75;
      rig.legBR.knee.rotation.x = -Math.max(0, br) * 0.75;

      rig.bodyGroup.rotation.x = Math.sin(gaitPhase * 2) * 0.045 * gaitSpeed;
      rig.headGroup.rotation.x = -Math.sin(gaitPhase * 2) * 0.045;
      rig.earL.rotation.x = Math.sin(gaitPhase * 2) * 0.09;
      rig.earR.rotation.x = Math.sin(gaitPhase * 2) * 0.09;
    }
  } else {
    rig.legFL.hip.rotation.x = 0;
    rig.legFR.hip.rotation.x = 0;
    rig.legBL.hip.rotation.x = 0;
    rig.legBR.hip.rotation.x = 0;
    rig.legFL.knee.rotation.x = 0;
    rig.legFR.knee.rotation.x = 0;
    rig.legBL.knee.rotation.x = 0;
    rig.legBR.knee.rotation.x = 0;
  }

  // Subtle breathing
  const breath = Math.sin(time * 2.4) * 0.018;
  rig.bodyGroup.scale.set(1 + breath, 1 + breath * 0.6, 1);

  // 3. Species-Distinct Play Tricks (Play-Bow / Pounce-Crouch / Paw-Bat)
  if (playBow > 0.02) {
    // Golden Retriever Play Bow: chest down low, rear high, super excited wag!
    rig.bodyGroup.position.y -= 0.1 * playBow;
    rig.bodyGroup.rotation.x += 0.34 * playBow;
    rig.neckPivot.rotation.x -= 0.28 * playBow;
    rig.headGroup.rotation.z += Math.sin(time * 4) * 0.14 * playBow;
    rig.legFL.hip.rotation.x = -0.95 * playBow;
    rig.legFR.hip.rotation.x = -0.95 * playBow;
    rig.legFL.knee.rotation.x = 0.25 * playBow;
    rig.legFR.knee.rotation.x = 0.25 * playBow;
    rig.legBL.hip.rotation.x = -0.22 * playBow;
    rig.legBR.hip.rotation.x = -0.22 * playBow;
    rig.jawPivot.rotation.x = 0.25 * playBow;
    rig.tail1.rotation.y = Math.sin(time * 16) * 0.65;
    rig.tail2.rotation.y = Math.cos(time * 16) * 0.4;
  } else if (pounceCrouch > 0.02) {
    // Korean Shorthair Pounce Crouch: low stalker belly + wiggling hindquarters!
    rig.bodyGroup.position.y -= 0.13 * pounceCrouch;
    rig.bodyGroup.rotation.z += Math.sin(time * 15) * 0.09 * pounceCrouch;
    rig.legFL.hip.rotation.x = -0.55 * pounceCrouch;
    rig.legFR.hip.rotation.x = -0.55 * pounceCrouch;
    rig.legFL.knee.rotation.x = 1.05 * pounceCrouch;
    rig.legFR.knee.rotation.x = 1.05 * pounceCrouch;
    rig.legBL.hip.rotation.x = -0.6 * pounceCrouch;
    rig.legBR.hip.rotation.x = -0.6 * pounceCrouch;
    rig.legBL.knee.rotation.x = 1.0 * pounceCrouch;
    rig.legBR.knee.rotation.x = 1.0 * pounceCrouch;
    rig.neckPivot.rotation.x = -0.15 * pounceCrouch;
    rig.earL.rotation.z = -0.45 * pounceCrouch;
    rig.earR.rotation.z = 0.45 * pounceCrouch;
    rig.tail1.rotation.y = Math.sin(time * 11) * 0.48;
  } else if (pawBat > 0.02) {
    // Korean Shorthair Paw-Bat: cute upright swatting at butterflies/air
    const swipe = Math.sin(time * 11);
    rig.bodyGroup.rotation.x -= 0.18 * pawBat;
    rig.legFR.hip.rotation.x = (-1.1 + swipe * 0.45) * pawBat;
    rig.legFR.knee.rotation.x = (0.45 + Math.max(0, swipe) * 0.4) * pawBat;
    rig.legFR.hip.rotation.z = -0.18 * pawBat;
    rig.headGroup.rotation.z = 0.24 * pawBat;
    rig.headGroup.rotation.x = -0.18 * pawBat;
  }

  // 4. Expressive Mood Poses (Req 10 & Req 12)
  const lowEnergyDroop = (1 - healthFactor) * 0.32;

  if (mood === 'hungry') {
    rig.neckPivot.rotation.x = 0.35 + lowEnergyDroop;
    rig.headGroup.rotation.x = 0.22;
    rig.headGroup.rotation.z = Math.sin(time * 3) * 0.08;
    rig.jawPivot.rotation.x = (Math.sin(time * 7) * 0.5 + 0.5) * 0.24;
    rig.tail1.rotation.x = -0.55;
    rig.tail1.rotation.y = Math.sin(time * 2) * 0.1;
    rig.legFL.hip.rotation.x = -0.35 + Math.sin(time * 5) * 0.18;
    rig.legFL.knee.rotation.x = 0.55;
  } else if (mood === 'potty') {
    rig.bodyGroup.position.y -= 0.08;
    rig.legBL.hip.rotation.x = -0.45;
    rig.legBR.hip.rotation.x = -0.45;
    rig.legBL.knee.rotation.x = 0.7;
    rig.legBR.knee.rotation.x = 0.7;
    rig.neckPivot.rotation.x = 0.48;
    rig.headGroup.rotation.y = Math.sin(time * 5.2) * 0.32 + lookYaw;
    rig.jawPivot.rotation.x = (Math.sin(time * 10) * 0.5 + 0.5) * 0.25;
    rig.tail1.rotation.x = 0.35;
  } else if (mood === 'want_something') {
    rig.headGroup.rotation.z = 0.28 + Math.sin(time * 2.2) * 0.06;
    rig.headGroup.rotation.x = -0.14;
    rig.headGroup.rotation.y = lookYaw;
    rig.jawPivot.rotation.x = (Math.sin(time * 6.5) * 0.5 + 0.5) * 0.22;
    if (gaitSpeed < 0.05 && pawBat < 0.05) {
      rig.legFR.hip.rotation.x = -0.55;
      rig.legFR.knee.rotation.x = 0.85;
    }
    rig.tail1.rotation.y = Math.sin(time * 7) * 0.35;
  } else if (mood === 'eating') {
    rig.neckPivot.rotation.x = 0.62 + Math.sin(time * 9) * 0.08;
    rig.headGroup.rotation.x = 0.32;
    rig.jawPivot.rotation.x = (Math.sin(time * 12) * 0.5 + 0.5) * 0.26;
    rig.tail1.rotation.y = Math.sin(time * 9) * 0.4;
  } else if (mood === 'happy' || mood === 'walking') {
    if (gaitSpeed < 0.05 && jumpY < 0.02 && playBow < 0.05 && pawBat < 0.05) {
      rig.bodyGroup.position.y += Math.abs(Math.sin(time * 5.5)) * 0.05;
    }
    if (playBow < 0.05) {
      rig.neckPivot.rotation.x -= 0.08;
    }
    rig.headGroup.rotation.y += Math.sin(time * 2.5) * 0.14 + lookYaw;
    rig.jawPivot.rotation.x = Math.max(rig.jawPivot.rotation.x, 0.16 + Math.sin(time * 8) * 0.07);

    if (rig.species === 'golden_retriever') {
      // Enthusiastic wide golden retriever wag
      rig.tail1.rotation.y = Math.sin(time * 12) * 0.56;
      rig.tail2.rotation.y = Math.sin(time * 12 - 0.45) * 0.38;
      rig.tail3.rotation.y = Math.sin(time * 12 - 0.9) * 0.28;
    } else {
      // Graceful S-curve feline tail swish + curious ear flicks!
      rig.tail1.rotation.y = Math.sin(time * 5.2) * 0.42;
      rig.tail2.rotation.y = Math.sin(time * 5.2 - 1.1) * 0.45;
      rig.tail3.rotation.y = Math.sin(time * 5.2 - 2.2) * 0.4;
      rig.earL.rotation.z += Math.max(0, Math.sin(time * 3.7)) * 0.14;
      rig.earR.rotation.z -= Math.max(0, Math.cos(time * 4.3)) * 0.14;
    }
  } else {
    rig.neckPivot.rotation.x = lowEnergyDroop * 0.7;
    rig.headGroup.rotation.y += Math.sin(time * 0.9) * 0.16 + lookYaw;
    rig.headGroup.rotation.z += Math.sin(time * 0.6) * 0.06;
    rig.jawPivot.rotation.x = Math.max(0, Math.sin(time * 2.5) * 0.07);
    const wagSpeed = (rig.species === 'golden_retriever' ? 4.8 : 2.8) * healthFactor;
    rig.tail1.rotation.y = Math.sin(time * wagSpeed) * 0.34 * healthFactor;
    rig.tail2.rotation.y = Math.sin(time * wagSpeed - 0.5) * 0.24 * healthFactor;
    if (rig.species === 'korean_shorthair') {
      rig.earL.rotation.z += Math.max(0, Math.sin(time * 2.9)) * 0.12;
      rig.earR.rotation.z -= Math.max(0, Math.cos(time * 3.3)) * 0.12;
    }
  }
}
