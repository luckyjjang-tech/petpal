export type PetSpecies = 'golden_retriever' | 'korean_shorthair';

export type PetExpressionMood =
  | 'idle'
  | 'happy'
  | 'hungry'
  | 'potty'
  | 'want_something'
  | 'rolling'
  | 'eating'
  | 'walking';

export type WardrobeSlot = 'clothes' | 'accessory';

export interface WardrobeItem {
  id: string;
  name: string;
  slot: WardrobeSlot;
  unlockScore: number;
  primaryColor: string;
  secondaryColor: string;
  description: string;
  styleType:
    | 'ribbon_scarf'
    | 'yellow_raincoat'
    | 'denim_vest'
    | 'royal_cape'
    | 'bell_collar'
    | 'leather_tag'
    | 'pearl_necklace'
    | 'flower_crown';
}

export interface CareSchedule {
  morningMeal: string; // HH:mm
  lunchMeal: string;   // HH:mm
  dinnerMeal: string;  // HH:mm
  walkTime: string;    // HH:mm
}

export interface DonationRecord {
  id: string;
  amountKrw: number;
  bonusPointsUsed: number;
  cardLast4: string;
  timestamp: number;
  unlockedItemName?: string;
}

export interface SpeechBubbleState {
  id: number;
  species: PetSpecies;
  mood: PetExpressionMood;
  text: string;
  subLabel: string;
  screenX: number;
  screenY: number;
  expiresAt: number;
}

export const WARDROBE_CATALOG: WardrobeItem[] = [
  {
    id: 'ribbon_scarf',
    name: '코랄 리본 스카프',
    slot: 'clothes',
    unlockScore: 100,
    primaryColor: '#e86a58',
    secondaryColor: '#fff4ec',
    description: '100점 선물상자에서 만나는 산뜻한 코튼 리본 스카프',
    styleType: 'ribbon_scarf',
  },
  {
    id: 'bell_collar',
    name: '황금 방울 목걸이',
    slot: 'accessory',
    unlockScore: 100,
    primaryColor: '#d97706',
    secondaryColor: '#fde68a',
    description: '걸을 때마다 은은하게 빛나는 브라스 방울 목걸이',
    styleType: 'bell_collar',
  },
  {
    id: 'yellow_raincoat',
    name: '병아리 산책 우비',
    slot: 'clothes',
    unlockScore: 120,
    primaryColor: '#f59e0b',
    secondaryColor: '#fef3c7',
    description: '비 오는 날 산책도 즐거운 포근한 노란색 우비 조끼',
    styleType: 'yellow_raincoat',
  },
  {
    id: 'leather_tag',
    name: '네임택 가죽 목걸이',
    slot: 'accessory',
    unlockScore: 150,
    primaryColor: '#78350f',
    secondaryColor: '#fbbf24',
    description: '천연 가죽 스트랩과 황금 하트 펜던트 인식표',
    styleType: 'leather_tag',
  },
  {
    id: 'denim_vest',
    name: '클래식 데님 멜빵 조끼',
    slot: 'clothes',
    unlockScore: 180,
    primaryColor: '#2563eb',
    secondaryColor: '#dbeafe',
    description: '단단한 인디고 데님과 골드 스티치가 돋보이는 조끼',
    styleType: 'denim_vest',
  },
  {
    id: 'pearl_necklace',
    name: '진주 하트 목걸이',
    slot: 'accessory',
    unlockScore: 220,
    primaryColor: '#fafaf9',
    secondaryColor: '#f43f5e',
    description: '보너스 220점 이상에서 해금되는 고급 진주 목걸이',
    styleType: 'pearl_necklace',
  },
  {
    id: 'royal_cape',
    name: '로열 벨벳 망토',
    slot: 'clothes',
    unlockScore: 260,
    primaryColor: '#881337',
    secondaryColor: '#fcd34d',
    description: '금색 트리밍이 더해진 우아한 프리미엄 벨벳 케이프',
    styleType: 'royal_cape',
  },
  {
    id: 'flower_crown',
    name: '봄꽃 화관 장식',
    slot: 'accessory',
    unlockScore: 300,
    primaryColor: '#fb7185',
    secondaryColor: '#a7f3d0',
    description: '300점 명예 보너스로 완성하는 생화 화관 액세서리',
    styleType: 'flower_crown',
  },
];

export const PET_DISPLAY_INFO: Record<
  PetSpecies,
  {
    koreanName: string;
    breedLabel: string;
    puppyLabel: string;
    adultLabel: string;
    accentHex: string;
  }
> = {
  golden_retriever: {
    koreanName: '골든 리트리버',
    breedLabel: 'Golden Retriever',
    puppyLabel: '아기 골든 리트리버',
    adultLabel: '성견 골든 리트리버',
    accentHex: '#d97706',
  },
  korean_shorthair: {
    koreanName: '코리안 숏헤어',
    breedLabel: 'Korean Shorthair',
    puppyLabel: '아기 코리안 숏헤어',
    adultLabel: '성묘 코리안 숏헤어',
    accentHex: '#c2410c',
  },
};

export function getSpeechForMood(
  species: PetSpecies,
  mood: PetExpressionMood,
): {text: string; subLabel: string} {
  const isDog = species === 'golden_retriever';

  switch (mood) {
    case 'hungry':
      return isDog
        ? {
            text: '멍멍! 배가 고파요! 밥 먹을 시간이 됐어요!',
            subLabel: '배고픔 의사표현',
          }
        : {
            text: '야옹~ 배고파요! 맛있는 사료 챙겨주세요!',
            subLabel: '배고픔 의사표현',
          };
    case 'potty':
      return isDog
        ? {
            text: '낑낑! 배변이 급해요! 패드나 산책 나가요!',
            subLabel: '배변 의사표현',
          }
        : {
            text: '애옹! 화장실 가고 싶어요! 모래 치워주세요!',
            subLabel: '배변 의사표현',
          };
    case 'want_something':
      return isDog
        ? {
            text: '왈왈! 주인님, 나랑 산책 가거나 공놀이 하고 싶어요!',
            subLabel: '요구 의사표현',
          }
        : {
            text: '야옹! 주인님, 나 좀 쓰다듬어 주고 산책 가요!',
            subLabel: '요구 의사표현',
          };
    case 'rolling':
      return isDog
        ? {
            text: '멍멍! 왈왈! 주인님 너무 반가워요! 데구르르 애교 발사~',
            subLabel: '터치 짖음 · 반가운 애교',
          }
        : {
            text: '야옹~ 야옹! 주인님 반가워요! 데굴데굴 반갑다냥~',
            subLabel: '터치 울음 · 반가운 애교',
          };
    case 'eating':
      return isDog
        ? {
            text: '냠냠! 제때 주신 밥이라 너무 맛있어요 멍!',
            subLabel: '식사 중',
          }
        : {
            text: '오독오독! 신선한 밥 최고예요 야옹~',
            subLabel: '식사 중',
          };
    case 'walking':
      return isDog
        ? {
            text: '멍멍! 주인님 발걸음에 맞춰 같이 뛰니까 신나요!',
            subLabel: '산책 동행 중',
          }
        : {
            text: '야옹! 바깥 바람 맞으며 함께 걸으니 최고예요!',
            subLabel: '산책 동행 중',
          };
    case 'happy':
    default:
      return isDog
        ? {
            text: '멍멍! 반가워요 주인님! 오늘도 신나게 놀아요!',
            subLabel: '기쁨·반가움 의사표현',
          }
        : {
            text: '야옹~ 주인님 봐서 너무 기뻐요! 골골골~',
            subLabel: '기쁨·반가움 의사표현',
          };
  }
}

export function getLifeStageLabel(
  species: PetSpecies,
  maturity: number,
): {stage: string; monthsText: string} {
  // Realistic growth timeline mapped across 0..1 -> 2 months to 18 months
  const months = Math.round(2 + maturity * 16);
  const isDog = species === 'golden_retriever';
  if (maturity < 0.28) {
    return {
      stage: isDog ? '어린 강아지 (유년기)' : '어린 아기 고양이 (유년기)',
      monthsText: `생후 ${months}개월`,
    };
  }
  if (maturity < 0.65) {
    return {
      stage: isDog ? '쑥쑥 자라는 성장기' : '호기심 많은 성장기',
      monthsText: `생후 ${months}개월`,
    };
  }
  if (maturity < 0.9) {
    return {
      stage: isDog ? '씩씩한 청소년기' : '날렵한 청소년기',
      monthsText: `생후 ${months}개월`,
    };
  }
  return {
    stage: isDog ? '건강한 성견' : '우아한 성묘',
    monthsText: `생후 ${months}개월`,
  };
}
