import {PetExpressionMood, PetSpecies} from '../types/pet';

interface BgmStep {
  melody: number | null;
  harmony: number | null;
  bass: number | null;
  durBeats: number;
}

// Cheerful, warm 16-beat marimba/music-box loop in C major
const BGM_PATTERN: BgmStep[] = [
  // Bar 1 (C major)
  {melody: 523.25, harmony: 329.63, bass: 130.81, durBeats: 1},   // C5
  {melody: 659.25, harmony: null, bass: null, durBeats: 0.5},     // E5
  {melody: 783.99, harmony: 392.0, bass: 196.0, durBeats: 0.5},   // G5
  {melody: 880.0, harmony: 329.63, bass: 130.81, durBeats: 1},    // A5
  {melody: 783.99, harmony: null, bass: 196.0, durBeats: 1},      // G5

  // Bar 2 (F major -> G7)
  {melody: 698.46, harmony: 440.0, bass: 174.61, durBeats: 1},    // F5
  {melody: 659.25, harmony: null, bass: null, durBeats: 0.5},     // E5
  {melody: 587.33, harmony: 349.23, bass: 174.61, durBeats: 0.5}, // D5
  {melody: 659.25, harmony: 392.0, bass: 196.0, durBeats: 1},     // E5
  {melody: 523.25, harmony: null, bass: 146.83, durBeats: 1},     // C5

  // Bar 3 (Am -> F)
  {melody: 587.33, harmony: 349.23, bass: 220.0, durBeats: 1},    // D5
  {melody: 659.25, harmony: null, bass: null, durBeats: 0.5},     // E5
  {melody: 698.46, harmony: 440.0, bass: 174.61, durBeats: 0.5},  // F5
  {melody: 783.99, harmony: 523.25, bass: 130.81, durBeats: 1},   // G5
  {melody: 659.25, harmony: null, bass: 196.0, durBeats: 1},      // E5

  // Bar 4 (G7 -> C resolve)
  {melody: 587.33, harmony: 392.0, bass: 196.0, durBeats: 0.75},  // D5
  {melody: 659.25, harmony: null, bass: null, durBeats: 0.25},    // E5
  {melody: 587.33, harmony: 349.23, bass: 146.83, durBeats: 1},   // D5
  {melody: 523.25, harmony: 392.0, bass: 130.81, durBeats: 1.5},  // C5
  {melody: null, harmony: null, bass: 196.0, durBeats: 0.5},      // breath
];

class PetAudioEngine {
  private ctx: AudioContext | null = null;
  private bgmGain: GainNode | null = null;
  private bgmTimer: number | null = null;
  private bgmStepIdx = 0;
  private nextNoteTime = 0;
  private autoArmed = false;

  public muted = false;
  public bgmEnabled = true;

  private ensureContext(): AudioContext | null {
    if (this.muted) return null;
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as {webkitAudioContext: typeof AudioContext})
          .webkitAudioContext;
      if (!AudioCtx) return null;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      void this.ctx.resume();
    }
    return this.ctx;
  }

  private ensureBgmGain(ctx: AudioContext): GainNode {
    if (!this.bgmGain) {
      this.bgmGain = ctx.createGain();
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.value = 2600;
      filter.Q.value = 0.6;
      this.bgmGain.connect(filter);
      filter.connect(ctx.destination);
      this.bgmGain.gain.value = this.muted || !this.bgmEnabled ? 0.0001 : 0.45;
    }
    return this.bgmGain;
  }

  public armAutoBgm(): void {
    if (this.autoArmed || typeof window === 'undefined') return;
    this.autoArmed = true;

    const unlock = () => {
      if (!this.muted && this.bgmEnabled) {
        this.startBgm();
      }
      if (this.ctx && this.ctx.state === 'running') {
        window.removeEventListener('pointerdown', unlock, true);
        window.removeEventListener('keydown', unlock, true);
        window.removeEventListener('touchstart', unlock, true);
      }
    };

    window.addEventListener('pointerdown', unlock, true);
    window.addEventListener('keydown', unlock, true);
    window.addEventListener('touchstart', unlock, true);
  }

  public setMuted(muted: boolean): void {
    this.muted = muted;
    if (this.ctx && this.bgmGain) {
      const now = this.ctx.currentTime;
      this.bgmGain.gain.cancelScheduledValues(now);
      this.bgmGain.gain.linearRampToValueAtTime(
        !muted && this.bgmEnabled ? 0.45 : 0.0001,
        now + 0.08,
      );
    }
    if (muted) {
      this.stopBgmLoop();
    } else if (this.bgmEnabled) {
      this.startBgm();
    }
  }

  public setBgmEnabled(enabled: boolean): void {
    this.bgmEnabled = enabled;
    if (this.ctx && this.bgmGain) {
      const now = this.ctx.currentTime;
      this.bgmGain.gain.cancelScheduledValues(now);
      this.bgmGain.gain.linearRampToValueAtTime(
        !this.muted && enabled ? 0.45 : 0.0001,
        now + 0.1,
      );
    }
    if (enabled && !this.muted) {
      this.startBgm();
    } else {
      this.stopBgmLoop();
    }
  }

  public startBgm(): void {
    if (this.muted || !this.bgmEnabled) return;
    const ctx = this.ensureContext();
    if (!ctx) return;

    const gain = this.ensureBgmGain(ctx);
    const now = ctx.currentTime;
    gain.gain.cancelScheduledValues(now);
    gain.gain.linearRampToValueAtTime(0.45, now + 0.12);

    if (this.bgmTimer !== null) return;

    this.nextNoteTime = Math.max(now + 0.05, this.nextNoteTime);
    const beatSeconds = 60 / 114; // Cheerful 114 BPM

    const scheduleAhead = () => {
      if (!this.ctx || this.muted || !this.bgmEnabled) return;
      if (this.ctx.state === 'suspended') {
        this.nextNoteTime = this.ctx.currentTime + 0.05;
        return;
      }

      while (this.nextNoteTime < this.ctx.currentTime + 0.25) {
        const step = BGM_PATTERN[this.bgmStepIdx];
        const stepDur = step.durBeats * beatSeconds;

        if (step.melody) {
          this.playBgmVoice(
            this.ctx,
            gain,
            step.melody,
            this.nextNoteTime,
            Math.min(stepDur * 1.15, 0.45),
            0.095,
            'triangle',
          );
        }
        if (step.harmony) {
          this.playBgmVoice(
            this.ctx,
            gain,
            step.harmony,
            this.nextNoteTime,
            Math.min(stepDur * 1.25, 0.5),
            0.045,
            'sine',
          );
        }
        if (step.bass) {
          this.playBgmVoice(
            this.ctx,
            gain,
            step.bass,
            this.nextNoteTime,
            Math.min(stepDur * 1.35, 0.55),
            0.065,
            'sine',
          );
        }

        this.nextNoteTime += stepDur;
        this.bgmStepIdx = (this.bgmStepIdx + 1) % BGM_PATTERN.length;
      }
    };

    this.bgmTimer = window.setInterval(scheduleAhead, 80);
    scheduleAhead();
  }

  private stopBgmLoop(): void {
    if (this.bgmTimer !== null) {
      window.clearInterval(this.bgmTimer);
      this.bgmTimer = null;
    }
  }

  private playBgmVoice(
    ctx: AudioContext,
    dest: AudioNode,
    freq: number,
    startTime: number,
    duration: number,
    peakGain: number,
    type: OscillatorType,
  ): void {
    const osc = ctx.createOscillator();
    const env = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, startTime);

    env.gain.setValueAtTime(0.0001, startTime);
    env.gain.linearRampToValueAtTime(peakGain, startTime + 0.018);
    env.gain.exponentialRampToValueAtTime(0.0001, startTime + duration);

    osc.connect(env);
    env.connect(dest);
    osc.start(startTime);
    osc.stop(startTime + duration + 0.02);
  }

  public playVocal(species: PetSpecies, mood: PetExpressionMood): void {
    const ctx = this.ensureContext();
    if (!ctx) return;
    if (this.bgmEnabled && this.bgmTimer === null) {
      this.startBgm();
    }

    if (species === 'golden_retriever') {
      this.playDogBark(ctx, mood);
    } else {
      this.playCatMeow(ctx, mood);
    }
  }

  private playDogBark(ctx: AudioContext, mood: PetExpressionMood): void {
    const now = ctx.currentTime;

    const triggerWoof = (
      startOffset: number,
      baseFreq: number,
      endFreq: number,
      dur: number,
      gainVal: number,
    ) => {
      const t0 = now + startOffset;
      const osc = ctx.createOscillator();
      const subOsc = ctx.createOscillator();
      const filter = ctx.createBiquadFilter();
      const gain = ctx.createGain();

      osc.type = 'sawtooth';
      subOsc.type = 'triangle';

      osc.frequency.setValueAtTime(baseFreq * 0.85, t0);
      osc.frequency.exponentialRampToValueAtTime(baseFreq * 1.25, t0 + dur * 0.28);
      osc.frequency.exponentialRampToValueAtTime(endFreq, t0 + dur);

      subOsc.frequency.setValueAtTime(baseFreq * 0.5, t0);
      subOsc.frequency.exponentialRampToValueAtTime(endFreq * 0.5, t0 + dur);

      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(650, t0);
      filter.frequency.exponentialRampToValueAtTime(380, t0 + dur);
      filter.Q.value = 2.4;

      gain.gain.setValueAtTime(0.001, t0);
      gain.gain.linearRampToValueAtTime(gainVal, t0 + 0.025);
      gain.gain.exponentialRampToValueAtTime(0.001, t0 + dur);

      osc.connect(filter);
      subOsc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      osc.start(t0);
      subOsc.start(t0);
      osc.stop(t0 + dur + 0.02);
      subOsc.stop(t0 + dur + 0.02);
    };

    if (mood === 'hungry' || mood === 'want_something') {
      triggerWoof(0, 340, 260, 0.24, 0.16);
      triggerWoof(0.28, 250, 175, 0.16, 0.19);
    } else if (mood === 'potty') {
      triggerWoof(0, 310, 210, 0.12, 0.18);
      triggerWoof(0.16, 330, 220, 0.12, 0.2);
      triggerWoof(0.32, 350, 230, 0.14, 0.2);
    } else {
      triggerWoof(0, 240, 150, 0.14, 0.24);
      triggerWoof(0.19, 270, 165, 0.17, 0.26);
    }
  }

  private playCatMeow(ctx: AudioContext, mood: PetExpressionMood): void {
    const now = ctx.currentTime;

    const triggerMeow = (
      startOffset: number,
      fStart: number,
      fPeak: number,
      fEnd: number,
      dur: number,
      gainVal: number,
    ) => {
      const t0 = now + startOffset;
      const osc = ctx.createOscillator();
      const harmonic = ctx.createOscillator();
      const filter = ctx.createBiquadFilter();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      harmonic.type = 'sine';

      osc.frequency.setValueAtTime(fStart, t0);
      osc.frequency.exponentialRampToValueAtTime(fPeak, t0 + dur * 0.35);
      osc.frequency.exponentialRampToValueAtTime(fEnd, t0 + dur);

      harmonic.frequency.setValueAtTime(fStart * 2.02, t0);
      harmonic.frequency.exponentialRampToValueAtTime(fPeak * 2.02, t0 + dur * 0.35);
      harmonic.frequency.exponentialRampToValueAtTime(fEnd * 2.02, t0 + dur);

      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(1250, t0);
      filter.frequency.exponentialRampToValueAtTime(920, t0 + dur);
      filter.Q.value = 1.9;

      gain.gain.setValueAtTime(0.001, t0);
      gain.gain.linearRampToValueAtTime(gainVal, t0 + 0.06);
      gain.gain.setValueAtTime(gainVal * 0.85, t0 + dur * 0.55);
      gain.gain.exponentialRampToValueAtTime(0.001, t0 + dur);

      osc.connect(filter);
      harmonic.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      osc.start(t0);
      harmonic.start(t0);
      osc.stop(t0 + dur + 0.02);
      harmonic.stop(t0 + dur + 0.02);
    };

    if (mood === 'hungry') {
      triggerMeow(0, 520, 740, 440, 0.45, 0.18);
    } else if (mood === 'potty') {
      triggerMeow(0, 620, 860, 560, 0.22, 0.18);
      triggerMeow(0.26, 650, 900, 580, 0.24, 0.18);
    } else if (mood === 'rolling') {
      triggerMeow(0, 480, 690, 520, 0.32, 0.16);
    } else {
      triggerMeow(0, 540, 780, 510, 0.34, 0.18);
    }
  }

  public playChime(): void {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const notes = [523.25, 659.25, 783.99];
    notes.forEach((freq, idx) => {
      const t = now + idx * 0.07;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t);
      gain.gain.setValueAtTime(0.001, t);
      gain.gain.linearRampToValueAtTime(0.12, t + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.26);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.28);
    });
  }

  public playCelebrationFanfare(): void {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const melody: Array<{f: number; t: number; d: number}> = [
      {f: 523.25, t: 0.0, d: 0.16},
      {f: 659.25, t: 0.14, d: 0.16},
      {f: 783.99, t: 0.28, d: 0.16},
      {f: 1046.5, t: 0.44, d: 0.28},
      {f: 783.99, t: 0.72, d: 0.16},
      {f: 1046.5, t: 0.9, d: 0.55},
    ];

    melody.forEach((n) => {
      const t0 = now + n.t;
      const osc = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc2.type = 'sine';
      osc.frequency.setValueAtTime(n.f, t0);
      osc2.frequency.setValueAtTime(n.f * 1.5, t0);
      gain.gain.setValueAtTime(0.001, t0);
      gain.gain.linearRampToValueAtTime(0.16, t0 + 0.025);
      gain.gain.exponentialRampToValueAtTime(0.001, t0 + n.d);
      osc.connect(gain);
      osc2.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t0);
      osc2.start(t0);
      osc.stop(t0 + n.d + 0.03);
      osc2.stop(t0 + n.d + 0.03);
    });

    [0.1, 0.45, 0.85].forEach((offset) => {
      this.triggerNoiseBurst(ctx, now + offset, 0.18, 0.12);
    });
  }

  private triggerNoiseBurst(
    ctx: AudioContext,
    startTime: number,
    duration: number,
    level: number,
  ): void {
    const bufferSize = Math.floor(ctx.sampleRate * duration);
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.3));
    }
    const source = ctx.createBufferSource();
    source.buffer = buffer;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(1400, startTime);
    filter.Q.value = 0.8;

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(level, startTime);
    gain.gain.exponentialRampToValueAtTime(0.001, startTime + duration);

    source.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);
    source.start(startTime);
  }
}

export const petAudio = new PetAudioEngine();
